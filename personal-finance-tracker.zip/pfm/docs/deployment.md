# Deployment

The application is configured only through environment variables and has no cloud SDK dependency, so the same
images run everywhere. Three packaging levels are provided: Docker Compose, plain Kubernetes manifests, and a
Helm chart (which the Terraform examples install).

## Configuration reference

| Variable | Used by | Default | Purpose |
|---|---|---|---|
| `DATABASE_URL` | every service except the gateway | - | `postgresql://user:pass@host:5432/db` for the service's own database |
| `RABBITMQ_URL` | services with a database | `amqp://guest:guest@rabbitmq:5672/` | Event bus |
| `REDIS_URL` | gateway, analytics | empty (disabled) | Rate-limit counters, dashboard cache |
| `JWT_SECRET` | all | development value | Token signing key, 32+ characters |
| `ENVIRONMENT` | all | `development` | `production` enforces a strong secret |
| `LOG_LEVEL` | all | `INFO` | |
| `ACCESS_TOKEN_TTL_MINUTES`, `REFRESH_TOKEN_TTL_DAYS` | auth | 30, 7 | |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | auth | empty | Optional bootstrap administrator |
| `<NAME>_SERVICE_URL` | gateway | `http://<name>-service:8000` | Upstreams |
| `RATE_LIMIT_PER_MINUTE`, `AUTH_RATE_LIMIT_PER_MINUTE` | gateway | 600, 20 | |
| `BUDGET_SERVICE_URL`, `CACHE_TTL_SECONDS`, `REPORT_JOB_INTERVAL_SECONDS` | analytics | budget-service, 30, 300 | |
| `REMINDER_JOB_INTERVAL_SECONDS` | notification | 60 | |
| `API_GATEWAY_URL` | frontend (nginx) | `http://api-gateway:8000` | Where `/api` is proxied |

## 1. Docker Compose (local or a single host)

```bash
cp .env.example .env        # optional for local use; required (with real secrets) anywhere shared
docker compose up --build   # http://localhost:3000   demo@example.com / Demo@12345
```

* Data persists in named volumes (`postgres-data`, `rabbitmq-data`). `docker compose down -v` deletes it.
* Monitoring: `docker compose --profile monitoring up -d` -> Grafana on http://localhost:3001 (admin / `GRAFANA_ADMIN_PASSWORD`).
* HTTPS on a public host: `DOMAIN=finance.example.com docker compose -f docker-compose.yml -f infrastructure/docker/docker-compose.tls.yml up -d`.
* Scale a service: `docker compose up -d --scale expense-service=3`.

## 2. Images

```bash
REGISTRY=ghcr.io/your-org TAG=1.0.0 ./scripts/build-images.sh --push
```

Produces `pfm-<service>`, `pfm-frontend` and `pfm-seed`. The release workflow does the same for `linux/amd64` and `linux/arm64`.

## 3. Kubernetes with Helm (any cluster)

Prerequisites: Kubernetes 1.25+, an ingress controller, a default StorageClass, metrics-server (for HPAs).

```bash
helm upgrade --install pfm infrastructure/helm/pfm --namespace pfm --create-namespace \
  --set image.registry=ghcr.io/your-org --set image.tag=1.0.0 \
  --set ingress.host=finance.example.com \
  --set secrets.jwtSecret="$(openssl rand -hex 32)" \
  --set postgresql.adminPassword="$(openssl rand -hex 16)" \
  --set rabbitmq.password="$(openssl rand -hex 16)" \
  $(for s in auth user income expense budget savings analytics notification; do
      printf -- '--set postgresql.servicePasswords.%s=%s ' "$s" "$(openssl rand -hex 16)"; done)
```

Keep the generated values (or use a values file from your secret store): PostgreSQL only applies the passwords
on first initialisation, so later upgrades must pass the same ones (`--reuse-values`).

Common variations:

| Goal | Values |
|---|---|
| Managed PostgreSQL (RDS, Azure Database, Cloud SQL, on-prem cluster) | `postgresql.enabled=false`, `externalDatabase.urls.<service>=postgresql://...` for each of the 8 services |
| Managed RabbitMQ / Redis | `rabbitmq.enabled=false` + `externalRabbitmqUrl`; `redis.enabled=false` + `externalRedisUrl` |
| Secrets from Vault / External Secrets | `secrets.existingSecret=<name>` with the keys shown in `infrastructure/kubernetes/secret.example.yaml` |
| cert-manager TLS | `ingress.annotations."cert-manager\.io/cluster-issuer"=letsencrypt` |
| Prometheus Operator | `serviceMonitor.enabled=true` |
| Demo data | `seed.enabled=true` |
| Laptop cluster (kind, minikube, k3d) | `-f infrastructure/helm/pfm/values-dev.yaml` after loading locally built `pfm/pfm-*:dev` images |

What the chart creates: a Deployment, Service, HPA and PodDisruptionBudget per service; ConfigMap and Secret;
liveness, readiness and start-up probes; Ingress (`/api` -> gateway, `/` -> frontend); NetworkPolicies; and,
unless disabled, PostgreSQL and RabbitMQ StatefulSets with persistent volumes plus Redis.

## 4. Kubernetes with plain manifests

```bash
cd infrastructure/kubernetes
kubectl apply -f namespace.yaml
cp secret.example.yaml secret.yaml && $EDITOR secret.yaml && kubectl apply -f secret.yaml
kubectl apply -k .          # edit images / host through kustomization.yaml or re-render (below)
```

`pfm.yaml` is generated from the chart; regenerate it for your registry and host with
`IMAGE_REGISTRY=... IMAGE_TAG=... INGRESS_HOST=... ./scripts/render-k8s.sh`.

## 5. Cloud and on-premises examples (Terraform)

Each folder provisions a cluster (where applicable), installs ingress-nginx and installs the chart through the
shared, provider-neutral module `modules/pfm-release`, generating all secrets.

| Target | Folder | Run |
|---|---|---|
| AWS EKS | `infrastructure/terraform/aws-eks` | `terraform init && terraform apply -var hostname=finance.example.com -var image_registry=ghcr.io/your-org` |
| Azure AKS | `infrastructure/terraform/azure-aks` | same, plus `-var subscription_id=...` |
| GCP GKE | `infrastructure/terraform/gcp-gke` | same, plus `-var project=...` |
| On-premises / existing cluster | `infrastructure/terraform/on-premises` | same, plus `-var kubeconfig=~/.kube/config` |

Afterwards point DNS for `hostname` at the ingress controller's load balancer
(`kubectl -n ingress-nginx get svc`). These are starting points: add remote state, private endpoints, managed
databases and your organisation's network layout before production use.

**AWS ECS** is not scripted. The images run unchanged on ECS/Fargate: create one task definition per service
with the environment variables above, an ALB routing `/api/*` to the gateway and `/*` to the frontend, RDS for
PostgreSQL, Amazon MQ for RabbitMQ and ElastiCache for Redis, with Service Connect for the
`http://<name>-service:8000` names.

## 6. Monitoring and logging on Kubernetes

Every pod exposes Prometheus metrics at `/metrics` (annotated for scraping; a `ServiceMonitor` is available) and
writes JSON logs to stdout. Install `kube-prometheus-stack` and a log collector of your choice
(Loki + Promtail/Alloy, or your platform's logging), then import
`monitoring/grafana/dashboards/pfm-overview.json` and `monitoring/prometheus/alerts.yml`.

## 7. Upgrades and rollback

Deployments roll with `maxUnavailable: 0`. Migrations are additive SQL files applied at start-up, so write them
backward compatible (add columns/tables first, remove in a later release) to keep `helm rollback pfm` safe.
