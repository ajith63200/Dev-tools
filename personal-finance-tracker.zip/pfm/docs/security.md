# Security

| Requirement | Implementation |
|---|---|
| JWT authentication | HS256 access tokens (30 min) and refresh tokens (7 days) issued by auth-service; token `type` is checked so a refresh token cannot be used as an access token. Validated at the gateway **and** again in every service. |
| Password hashing | bcrypt, cost 12, per-password salt. Minimum 8 characters with a letter and a digit. Login compares against a dummy hash for unknown emails to avoid timing-based account discovery. |
| Authorisation | Every SQL statement that touches user data filters on the `user_id` from the verified token; another user's record id returns 404. Roles (`user`, `admin`) gate the admin endpoints. Verified by `test_users_cannot_see_or_change_each_others_records`. |
| Input validation | Pydantic models on every request (types, ranges, lengths, enumerations, two-decimal positive amounts). All SQL is parameterised. |
| Rate limiting | Gateway: 600 requests/min per user, 20/min per IP on login/register/refresh; Redis-backed, in-memory fallback. |
| HTTPS | TLS terminates at the ingress (Kubernetes) or the Caddy overlay (`infrastructure/docker/docker-compose.tls.yml`). Internal traffic stays on the private network. |
| Secrets | Only environment variables; nothing is baked into images. Compose reads `.env`; Kubernetes uses a Secret (chart-created or `existingSecret` from Vault / External Secrets / Sealed Secrets). With `ENVIRONMENT=production` services refuse to start with a weak `JWT_SECRET`. |
| Database access | One role per service, `CONNECT` revoked from `PUBLIC`; each pod receives only its own database URL. Databases, broker and services are not published outside the cluster / Compose network; NetworkPolicies enforce edge -> backend -> data. |
| Logs | Structured JSON with method, route template, status, duration, request id and user id. Bodies, query strings, amounts, emails, tokens and passwords are never logged; the formatter also masks sensitive keys. |
| Containers | Non-root users, read-only root filesystem, all capabilities dropped, no privilege escalation, seccomp `RuntimeDefault`, no service-account token mounted. |
| Browser | Same-origin API (no CORS surface), CSP, `X-Frame-Options: DENY`, `nosniff`. |

## Things to know before going to production

* **Token storage.** The SPA keeps tokens in `localStorage`, protected by the CSP. If your threat model requires
  it, move the refresh token to an `HttpOnly` cookie set by the gateway.
* **Symmetric signing.** All services share `JWT_SECRET`. Moving to RS256/EdDSA (auth-service signs, the others
  hold only the public key) removes the ability of other services to mint tokens; `pfm_common/auth.py` is the
  single place to change.
* **No token revocation list.** Logging out discards tokens on the client; a stolen access token is valid until
  it expires. Deactivating a user blocks refresh immediately.
* **Client IP.** The gateway trusts `X-Forwarded-For`, so it must sit behind a proxy you control (it does in both
  provided deployments).
* **Not included:** email verification, password reset, MFA, audit log, encryption at rest (use your platform's
  volume/database encryption).
