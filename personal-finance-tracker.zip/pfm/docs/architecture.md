# Architecture

## 1. System overview

```mermaid
flowchart LR
    user([Browser]) -->|HTTPS| edge[Ingress / TLS proxy]
    edge -->|/| fe[Frontend<br/>React + nginx]
    edge -->|/api| gw[API Gateway<br/>routing, JWT check, rate limit]
    fe -. same-origin /api .-> gw

    subgraph services [Backend services - FastAPI]
        auth[Auth]
        usr[User]
        inc[Income]
        exp[Expense]
        bud[Budget]
        sav[Savings]
        ana[Analytics & Reporting]
        notif[Notification]
    end

    gw --> auth & usr & inc & exp & bud & sav & ana & notif
    ana -->|REST: budgets for a month| bud

    subgraph data [Data stores]
        pg[(PostgreSQL<br/>one database per service)]
        mq{{RabbitMQ<br/>topic exchange pfm.events}}
        rd[(Redis<br/>cache + rate limits)]
    end

    auth & usr & inc & exp & bud & sav & ana & notif --- pg
    auth & inc & exp & bud & ana -->|publish| mq
    mq -->|consume| usr & bud & sav & ana & notif
    gw & ana --- rd
```

## 2. Service responsibilities

| Service | Owns | Publishes | Consumes |
|---|---|---|---|
| **api-gateway** | Nothing (stateless). Single entry point, route table, JWT validation, rate limiting, upstream status | - | - |
| **auth-service** | `users` (credentials, roles). Registration, login, refresh, password change, admin role management | `user.registered` | - |
| **user-service** | `profiles` (name, currency, timezone, theme, notification preferences) | - | `user.registered` |
| **income-service** | `income_sources`, `incomes`. CRUD, filters, monthly/yearly totals | `income.created/updated/deleted` | - |
| **expense-service** | `expense_categories`, `expenses`. CRUD, filters, spending aggregation | `expense.created/updated/deleted` | - |
| **budget-service** | `budgets`, `category_spend` (projection), `budget_alerts`. Limits, utilisation, 80/90/100% thresholds | `budget.threshold_reached`, `budget.changed` | `expense.*` |
| **savings-service** | `monthly_totals` (projection), `savings_goals`. Savings = income - expenses, history, goal progress | - | `income.*`, `expense.*` |
| **analytics-service** | `transactions` (read model), `report_notices`. Dashboard, trends, monthly/quarterly/yearly reports, PDF/Excel | `report.monthly_ready` | `income.*`, `expense.*`, `budget.*` |
| **notification-service** | `notifications`, `reminders`. In-app alerts, report notices, due reminders | - | `budget.threshold_reached`, `report.monthly_ready`, `user.registered` |

## 3. Communication patterns

**Synchronous (REST/JSON)** - only where the caller needs an answer now:

* Browser -> gateway -> service for every user action.
* analytics-service -> budget-service to include budget utilisation in the dashboard and reports. The user's
  token is forwarded, the call has a 3 s timeout, and the report is still returned (without budget figures) if
  budget-service is down.

**Asynchronous (events over RabbitMQ)** - for everything that reacts to a change:

```mermaid
sequenceDiagram
    participant C as Client
    participant E as expense-service
    participant Q as RabbitMQ
    participant B as budget-service
    participant S as savings-service
    participant A as analytics-service
    participant N as notification-service

    C->>E: POST /api/v1/expenses
    Note over E: one transaction:<br/>INSERT expense + INSERT outbox row
    E-->>C: 201 Created
    E->>Q: expense.created (outbox relay)
    par fan-out
        Q->>B: update category_spend, check thresholds
        Q->>S: update monthly_totals
        Q->>A: upsert read model, invalidate cache
    end
    B->>Q: budget.threshold_reached (via its own outbox)
    Q->>N: create in-app notification
```

Reliability rules implemented in `services/common/pfm_common/events.py`:

* **Transactional outbox.** A service writes its state change and the event in the same database transaction.
  A relay thread publishes outbox rows in order with publisher confirms. If RabbitMQ is down, writes still
  succeed and events are delivered when it returns.
* **Idempotent consumers.** Delivery is at-least-once, so each consumer records processed event ids
  (`processed_events`) in the same transaction as its own update. Redelivery is a no-op.
* **Dead-letter queues.** A message whose handler fails is moved to `<service>.events.dlq` instead of blocking
  the queue.
* **Self-describing events.** Transaction events carry `before` and `after`, so projections apply exact deltas
  for updates and deletes without calling back to the owner.

Event envelope:

```json
{ "id": "uuid", "type": "expense.updated", "user_id": "uuid", "occurred_at": "2026-11-14T06:20:12Z",
  "data": { "before": { "id": "...", "amount": 1200.0, "date": "2026-11-03", "category_id": "...",
                        "category_name": "Shopping", "payment_method": "upi", "description": "..." },
            "after":  { "...": "same shape" } } }
```

Consequence to be aware of: dashboards, savings and budgets are **eventually consistent** with the transaction
services, typically within about a second.

## 4. Technology choices

| Concern | Choice | Why |
|---|---|---|
| Backend | Python 3.12, FastAPI, Pydantic v2 | Typed validation and OpenAPI for free; small services |
| Data access | psycopg 3 + plain SQL, SQL migration files | The queries are aggregation-heavy; SQL is the clearest expression and has no ORM layer to tune |
| Messaging | RabbitMQ (topic exchange) | Routing keys and per-service durable queues fit this workload; far lighter to run than Kafka |
| Cache / limits | Redis (optional) | Dashboard cache and shared rate-limit counters; the system works without it |
| Frontend | React 18, TypeScript, Vite, Tailwind, Recharts | As requested |
| Packaging | Docker multi-stage images, Compose, Helm, plain manifests | One artefact set for every platform |

Deliberately left out to avoid unnecessary complexity: service mesh, Kafka, an ORM, a separate BFF,
distributed tracing (request ids are propagated and logged instead).

## 5. Shared code without shared deployment

`services/common` (`pfm_common`) holds configuration, the database helper and migration runner, JWT helpers,
the outbox/consumer code and the app factory (health, metrics, logging, error handling). Each image copies it
at build time, so every service is still built, versioned, deployed and scaled on its own.

## 6. Scaling and failure behaviour

* All services are stateless and run N replicas; HPAs scale on CPU. Migrations take a PostgreSQL advisory lock,
  so replicas can start concurrently. Outbox relays and periodic jobs use `FOR UPDATE SKIP LOCKED` /
  `ON CONFLICT` so replicas never double-publish or double-notify.
* RabbitMQ down: writes continue, projections catch up later. Redis down: no cache, rate limiting falls back to
  per-replica counters. budget-service down: reports omit budget figures. A consumer bug: message goes to the DLQ.
* The bundled PostgreSQL and RabbitMQ are single instances. For production availability point the chart at
  managed or operator-run clusters (`externalDatabase.urls`, `externalRabbitmqUrl`).
