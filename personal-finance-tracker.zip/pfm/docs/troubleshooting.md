# Troubleshooting

Start with `docker compose ps` (or `kubectl -n pfm get pods`) and `curl localhost:8080/api/v1/status`, which
reports each service as `ok`, `degraded` or `down`.

| Symptom | Likely cause | Fix |
|---|---|---|
| A service restarts with `password authentication failed` or `database "x_db" does not exist` | The PostgreSQL volume was initialised earlier with different passwords; the init script only runs on an empty volume | Development: `docker compose down -v` and start again. Otherwise `ALTER ROLE <svc>_svc PASSWORD '...'` to match the configured value |
| `JWT_SECRET must be set to a strong value` at start-up | `ENVIRONMENT=production` with the default or a short secret | Set `JWT_SECRET` to 32+ random characters (`openssl rand -hex 32`) |
| Logging in works, every other call returns 401 | Services have different `JWT_SECRET` values | Use one value for the gateway and all services |
| Dashboard, savings or budgets do not reflect a new transaction | Events are not flowing | `docker compose logs rabbitmq`; look for `event bus unavailable` in service logs. Pending events sit in each service's `outbox` table and are delivered automatically once RabbitMQ is reachable |
| A projection is wrong after a bug fix | A handler failed and the message was dead-lettered | Inspect `<service>.events.dlq` in the RabbitMQ UI (`docker compose exec rabbitmq rabbitmqctl list_queues`), fix, then move messages back with the shovel plugin |
| Dashboard shows "Budget data is temporarily unavailable" | analytics-service cannot reach budget-service | Check budget-service health and `BUDGET_SERVICE_URL` |
| HTTP 429 | Rate limit reached | Wait for `Retry-After`; tune `RATE_LIMIT_PER_MINUTE` / `AUTH_RATE_LIMIT_PER_MINUTE` on the gateway |
| Frontend loads, API calls return 502 | nginx cannot reach the gateway | Check `API_GATEWAY_URL` on the frontend container and that the gateway is healthy |
| Port already in use | 3000 or 8080 is taken | Set `FRONTEND_PORT` / `GATEWAY_PORT` in `.env` |
| No demo data | Seeding disabled, or it ran before | `docker compose logs seed`; `docker compose run --rm seed` (it does nothing if the demo account exists) |
| No "monthly report is ready" notification after seeding | The announcer runs every 5 minutes | Wait, or lower `REPORT_JOB_INTERVAL_SECONDS` on analytics-service |
| Kubernetes pods `Pending` | No default StorageClass, or not enough CPU/memory | Set `postgresql.storage.storageClassName`; lower `serviceDefaults.resources` or replicas |
| Kubernetes pods `ImagePullBackOff` | Images are not in the configured registry | Push them (`scripts/build-images.sh --push`) and set `image.registry`, `image.tag`, `image.pullSecrets` |
| Ingress answers 404 | Host or ingress class mismatch | Set `ingress.host` and `ingress.className` to match your controller |
| Services cannot reach each other on Kubernetes | NetworkPolicy and a CNI with different label expectations | Temporarily `--set networkPolicy.enabled=false` to confirm, then adjust `networkPolicy.ingressNamespaceSelector` |

Useful commands:

```bash
docker compose logs -f expense-service                 # JSON logs; filter by request_id to follow one request
docker compose exec postgres psql -U postgres -d expense_db -c "SELECT count(*) FROM outbox WHERE published_at IS NULL"
docker compose exec rabbitmq rabbitmqctl list_queues name messages consumers
kubectl -n pfm logs deploy/analytics-service --tail 100
kubectl -n pfm describe hpa
```
