# Database design

One PostgreSQL **database per service**, each with its own login role that can connect to that database only
(`database/init/01-create-service-databases.sh`). There are no cross-database foreign keys and no shared
tables: ids that belong to another service (`user_id`, a budget's `category_id`) are stored as plain UUIDs and
kept consistent through events.

Migrations are numbered SQL files in `services/<name>/migrations/`. Each service applies its pending files at
start-up inside a transaction guarded by an advisory lock, and records them in `schema_migrations`. To change a
schema, add `002_<description>.sql`; never edit an applied file.

```mermaid
erDiagram
    %% auth_db
    users { uuid id PK
            text email UK
            text password_hash
            text role
            bool is_active
            timestamptz created_at
            timestamptz updated_at }

    %% user_db
    profiles { uuid user_id PK
               text full_name
               char3 currency
               text timezone
               text theme
               timestamptz updated_at }

    %% income_db
    income_sources { uuid id PK
                     uuid user_id "NULL = built-in"
                     text name }
    incomes { uuid id PK
              uuid user_id
              uuid source_id FK
              numeric amount
              date txn_date
              text description }
    income_sources ||--o{ incomes : classifies

    %% expense_db
    expense_categories { uuid id PK
                         uuid user_id "NULL = built-in"
                         text name
                         text color }
    expenses { uuid id PK
               uuid user_id
               uuid category_id FK
               numeric amount
               date txn_date
               text payment_method
               text description
               text notes }
    expense_categories ||--o{ expenses : classifies

    %% budget_db
    budgets { uuid id PK
              uuid user_id
              int year
              int month
              uuid category_id "NULL = overall limit"
              text category_name
              numeric limit_amount }
    category_spend { uuid user_id PK
                     int year PK
                     int month PK
                     uuid category_id PK
                     numeric spent }
    budget_alerts { uuid budget_id PK
                    int threshold PK }
    budgets ||--o{ budget_alerts : announced

    %% savings_db
    monthly_totals { uuid user_id PK
                     int year PK
                     int month PK
                     numeric income
                     numeric expense }
    savings_goals { uuid id PK
                    uuid user_id
                    text name
                    text period
                    int year
                    int month
                    numeric target_amount }

    %% analytics_db
    transactions { uuid id PK
                   uuid user_id
                   text kind
                   numeric amount
                   date txn_date
                   text category_name
                   text payment_method }
    report_notices { uuid user_id PK
                     int year PK
                     int month PK }

    %% notification_db
    notifications { uuid id PK
                    uuid user_id
                    text type
                    text severity
                    text title
                    text message
                    jsonb metadata
                    bool is_read }
    reminders { uuid id PK
                uuid user_id
                text title
                date due_date
                text recurrence }
```

Every table has `created_at` / `updated_at` (projections: `updated_at`). Every service database additionally
contains `schema_migrations`, `outbox` and `processed_events` (created by the shared library).

## Indexes

| Table | Index | Serves |
|---|---|---|
| `users` | unique `lower(email)` | case-insensitive login, duplicate prevention |
| `incomes` | `(user_id, txn_date DESC)`, `(user_id, source_id)` | list by date, filter by source |
| `expenses` | `(user_id, txn_date DESC)`, `(user_id, category_id, txn_date)`, `(user_id, payment_method)` | list and the three filters |
| `income_sources`, `expense_categories` | unique `(owner, lower(name))` | no duplicate names per user |
| `budgets` | unique `(user_id, year, month, category)` | one budget per scope; upsert target |
| `savings_goals` | `(user_id, year, month)` | goals for a period |
| `transactions` | `(user_id, kind, txn_date)`, `(user_id, txn_date DESC)` | every dashboard and report aggregate |
| `notifications` | `(user_id, created_at DESC)`, partial `(user_id) WHERE NOT is_read` | inbox, unread badge |
| `reminders` | partial `(due_date) WHERE last_notified_on IS NULL` | due-reminder job |
| `outbox` | partial `(id) WHERE published_at IS NULL` | relay polling |

## Integrity rules enforced in the database

* Amounts are `NUMERIC(14,2)` with `CHECK (amount > 0)`; payment method, role, period and severity use `CHECK` lists.
* A category or source that is in use cannot be deleted (`ON DELETE RESTRICT`, surfaced as HTTP 409).
* Monthly goals must have a month and yearly goals must not (`CHECK`).

## Seed data

`database/seed/seed.py` creates `demo@example.com` / `Demo@12345` with eight months of income, expenses,
budgets, goals and a reminder **through the public API**, so the demo data exercises the same validation and
event flow as real usage. It runs automatically with Docker Compose (`SEED_DEMO_DATA=false` disables it).

## Backup

Back up PostgreSQL as usual (`pg_dump` per database, or volume snapshots / managed-database backups). The
projections (`category_spend`, `monthly_totals`, `transactions`) can always be rebuilt from the income and
expense databases, which are the systems of record.
