# API reference

All requests go through the gateway: `http://localhost:8080` (Compose) or `https://<host>` (Kubernetes ingress).
Every route except register, login and refresh needs `Authorization: Bearer <access_token>`.

* Interactive OpenAPI documents per service: `GET /api/v1/openapi/{service}` on the gateway
  (`auth`, `user`, `income`, `expense`, `budget`, `savings`, `analytics`, `notification`); static copies are in
  [`docs/openapi/`](openapi/). Each service also serves Swagger UI at `/docs` on its own port.
* Errors: `{"detail": "..."}` with 400/401/403/404/409/422/429; validation errors (422) list the offending fields.
* Money is sent and returned as JSON numbers with two decimals; dates are `YYYY-MM-DD`.
* Gateway extras: `GET /api/v1/status` (readiness of every service), rate limits of 600 requests/min per user and
  20/min per IP on the public auth routes (HTTP 429 with `Retry-After`).

```bash
# Log in, then call any endpoint
TOKEN=$(curl -s localhost:8080/api/v1/auth/login -H 'Content-Type: application/json' \
  -d '{"email":"demo@example.com","password":"Demo@12345"}' | python3 -c 'import sys,json; print(json.load(sys.stdin)["tokens"]["access_token"])')
curl -s "localhost:8080/api/v1/analytics/dashboard?year=2026&month=11" -H "Authorization: Bearer $TOKEN"
curl -s localhost:8080/api/v1/expenses -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"category_id":"<id from /api/v1/categories>","amount":450.00,"txn_date":"2026-11-14","payment_method":"upi","description":"Lunch"}'
```


## Authentication Service

Registration, login, JWT issuance and role management.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| POST | `/api/v1/auth/register` | Register |  |
| POST | `/api/v1/auth/login` | Login |  |
| POST | `/api/v1/auth/refresh` | Refresh |  |
| GET | `/api/v1/auth/me` | Me |  |
| POST | `/api/v1/auth/change-password` | Change Password |  |
| GET | `/api/v1/auth/users` | List Users | `limit`, `offset` |
| PATCH | `/api/v1/auth/users/{user_id}/role` | Set Role |  |

## User Service

User profiles and financial preferences (currency, timezone, theme).

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/users/me` | Get Profile |  |
| PUT | `/api/v1/users/me` | Update Profile |  |

## Income Service

Income transactions, income sources and income aggregation.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/income-sources` | List Sources |  |
| POST | `/api/v1/income-sources` | Create Source |  |
| DELETE | `/api/v1/income-sources/{source_id}` | Delete Source |  |
| GET | `/api/v1/incomes` | List Incomes | `date_from`, `date_to`, `source_id`, `search`, `limit`, `offset` |
| POST | `/api/v1/incomes` | Create Income |  |
| GET | `/api/v1/incomes/summary` | Monthly and yearly income totals, plus the split by source. | `year`* |
| GET | `/api/v1/incomes/{income_id}` | Get Income |  |
| PUT | `/api/v1/incomes/{income_id}` | Update Income |  |
| DELETE | `/api/v1/incomes/{income_id}` | Delete Income |  |

## Expense Service

Expense transactions, categories and spending aggregation.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/categories` | List Categories |  |
| POST | `/api/v1/categories` | Create Category |  |
| DELETE | `/api/v1/categories/{category_id}` | Delete Category |  |
| GET | `/api/v1/expenses` | List Expenses | `date_from`, `date_to`, `category_id`, `payment_method`, `search`, `limit`, `offset` |
| POST | `/api/v1/expenses` | Create Expense |  |
| GET | `/api/v1/expenses/summary` | Spending aggregation for a year (or a single month): totals by month, category and payment method. | `year`*, `month` |
| GET | `/api/v1/expenses/{expense_id}` | Get Expense |  |
| PUT | `/api/v1/expenses/{expense_id}` | Update Expense |  |
| DELETE | `/api/v1/expenses/{expense_id}` | Delete Expense |  |

## Budget Service

Monthly and category budgets, utilisation tracking and threshold alerts.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/budgets` | Budgets for a month with actual spending, utilisation percentages and status. | `year`*, `month`* |
| PUT | `/api/v1/budgets` | Create or replace the overall limit or one category budget for a month. |  |
| POST | `/api/v1/budgets/copy` | Copy every budget of one month into another month (existing budgets are kept). |  |
| DELETE | `/api/v1/budgets/{budget_id}` | Delete Budget |  |

## Savings Service

Automatic savings calculation, savings history and financial goals.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/savings/summary` | Savings and savings rate for one month. | `year`*, `month`* |
| GET | `/api/v1/savings/history` | Month-by-month savings trend for a year, with yearly totals. | `year`* |
| GET | `/api/v1/savings/goals` | Goals for a year with progress computed from recorded transactions. | `year`* |
| POST | `/api/v1/savings/goals` | Create Goal |  |
| PUT | `/api/v1/savings/goals/{goal_id}` | Update Goal |  |
| DELETE | `/api/v1/savings/goals/{goal_id}` | Delete Goal |  |

## Analytics and Reporting Service

Dashboard aggregates, trends, monthly/quarterly/yearly reports and PDF/Excel exports.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/analytics/dashboard` | Everything the landing dashboard needs for one month, in a single call. | `year`*, `month`* |
| GET | `/api/v1/analytics/reports/monthly` | Automated monthly report: totals, extremes, daily average, month-over-month comparison and insights. | `year`*, `month`* |
| GET | `/api/v1/analytics/reports/monthly/export` | Download the monthly report as PDF or Excel. | `year`*, `month`*, `format`, `currency` |
| GET | `/api/v1/analytics/reports/quarterly` | Quarterly | `year`*, `quarter`* |
| GET | `/api/v1/analytics/reports/yearly` | Yearly | `year`* |
| GET | `/api/v1/analytics/trends/spending` | Income, expenses and savings for the trailing N months (ending with the current month). | `months` |

## Notification Service

Budget threshold alerts, monthly report notifications and financial reminders.

| Method | Path | Description | Query parameters |
|---|---|---|---|
| GET | `/api/v1/notifications` | List Notifications | `unread_only`, `limit` |
| POST | `/api/v1/notifications/read-all` | Mark All Read |  |
| POST | `/api/v1/notifications/{notification_id}/read` | Mark Read |  |
| DELETE | `/api/v1/notifications/{notification_id}` | Delete Notification |  |
| GET | `/api/v1/reminders` | List Reminders |  |
| POST | `/api/v1/reminders` | Create Reminder |  |
| DELETE | `/api/v1/reminders/{reminder_id}` | Delete Reminder |  |

`*` = required. Request and response schemas are in the OpenAPI documents.
