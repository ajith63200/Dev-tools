# Testing

| Level | Where | What it covers | Needs |
|---|---|---|---|
| Unit | `services/<name>/tests/` | Pure rules: budget thresholds, savings formula, insights, password policy, token handling, rate limiter, routing, exports | nothing |
| Integration | `tests/integration/` | All nine services in one process against real PostgreSQL (one database each): migrations, CRUD, validation, outbox and consumers, projections, alerts, reports, exports, tenant isolation, idempotent redelivery, gateway auth and rate limiting | PostgreSQL |
| End-to-end / container | `tests/e2e/smoke_test.py` | A running stack through the gateway, including RabbitMQ delivery and PDF/Excel downloads | running stack |
| Frontend | `frontend/src/**/*.test.ts` | Formatting and query helpers; `npm run build` typechecks the whole app | Node |
| Security | inside the suites above | 401 without/with forged token on every service, refresh-token misuse, RBAC 403, cross-user 404, weak passwords, forged signatures, expired tokens, 429 on login flooding | - |
| Static | CI | ruff, `tsc`, `helm lint`, `docker compose config`, `terraform validate`, dependency scan | - |

```bash
pip install -r requirements-dev.txt
docker run -d --name pfm-test-pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres:16-alpine
./scripts/run-tests.sh                       # unit + integration

docker compose up --build -d                 # then, against the real stack:
python3 tests/e2e/smoke_test.py
cd frontend && npm ci && npm test && npm run build
```

The integration suite uses the in-memory event bus so it is fast and deterministic; the RabbitMQ driver is
covered by the end-to-end smoke test.
