from app.service import budget_alert_text

BASE = {"scope": "category", "category_name": "Shopping", "year": 2026, "month": 5, "utilization_pct": 83.4}


def test_eighty_percent_is_informational():
    severity, title, message = budget_alert_text({**BASE, "threshold": 80})
    assert severity == "info" and title == "80% of Shopping budget used" and "83%" in message and "May 2026" in message


def test_ninety_percent_is_a_warning():
    assert budget_alert_text({**BASE, "threshold": 90})[0] == "warning"


def test_overall_budget_exceeded_is_critical():
    severity, title, _ = budget_alert_text({**BASE, "scope": "overall", "category_name": None, "threshold": 100,
                                            "utilization_pct": 104})
    assert severity == "critical" and title == "Monthly budget limit reached"


def test_category_name_keeps_its_capitalisation():
    assert budget_alert_text({**BASE, "category_name": "EMI and loans", "threshold": 100})[1] == \
        "EMI and loans budget limit reached"
