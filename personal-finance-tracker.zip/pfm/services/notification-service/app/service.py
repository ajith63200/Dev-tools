"""Turning platform events and due reminders into in-app notifications."""
import calendar
from datetime import datetime, timezone

from psycopg.types.json import Jsonb


def notify(conn, user_id, type_: str, severity: str, title: str, message: str, metadata: dict | None = None) -> None:
    conn.execute("INSERT INTO notifications (user_id, type, severity, title, message, metadata) "
                 "VALUES (%s, %s, %s, %s, %s, %s)", (user_id, type_, severity, title, message, Jsonb(metadata or {})))


def budget_alert_text(data: dict) -> tuple[str, str, str]:
    """(severity, title, message) for a budget.threshold_reached event."""
    scope = f"{data['category_name']} budget" if data["scope"] == "category" else "monthly budget"
    period = f"{calendar.month_name[data['month']]} {data['year']}"
    threshold = data["threshold"]
    if threshold >= 100:
        return "critical", f"{scope[0].upper()}{scope[1:]} limit reached", (
            f"You have used {data['utilization_pct']:.0f}% of your {scope} for {period}.")
    severity = "warning" if threshold >= 90 else "info"
    return severity, f"{threshold}% of {scope} used", (
        f"Spending has reached {data['utilization_pct']:.0f}% of your {scope} for {period}.")


def on_budget_threshold(conn, event: dict) -> None:
    data = event["data"]
    severity, title, message = budget_alert_text(data)
    notify(conn, event["user_id"], "budget_alert", severity, title, message,
           {k: data[k] for k in ("budget_id", "scope", "category_name", "threshold", "year", "month")})


def on_monthly_report(conn, event: dict) -> None:
    data = event["data"]
    period = f"{calendar.month_name[data['month']]} {data['year']}"
    notify(conn, event["user_id"], "monthly_report", "info", f"Your {period} report is ready",
           "Open Reports to review income, spending, savings and recommendations for the month.",
           {"year": data["year"], "month": data["month"]})


def on_user_registered(conn, event: dict) -> None:
    notify(conn, event["user_id"], "system", "info", "Welcome to your finance tracker",
           "Start by adding this month's income and expenses, then set a budget to receive alerts.")


def dispatch_due_reminders(app) -> None:
    """Runs periodically. `FOR UPDATE SKIP LOCKED` keeps multiple replicas from double-sending."""
    today = datetime.now(timezone.utc).date()
    with app.state.db.tx() as conn:
        due = conn.execute("SELECT * FROM reminders WHERE due_date <= %s AND last_notified_on IS NULL "
                           "ORDER BY due_date LIMIT 200 FOR UPDATE SKIP LOCKED", (today,)).fetchall()
        for r in due:
            notify(conn, r["user_id"], "reminder", "info", r["title"],
                   r["note"] or f"Reminder due {r['due_date'].isoformat()}.", {"reminder_id": str(r["id"])})
            if r["recurrence"] == "monthly":
                conn.execute("UPDATE reminders SET due_date = (due_date + INTERVAL '1 month')::date, "
                             "updated_at = now() WHERE id = %s", (r["id"],))
            else:
                conn.execute("UPDATE reminders SET last_notified_on = %s, updated_at = now() WHERE id = %s",
                             (today, r["id"]))
