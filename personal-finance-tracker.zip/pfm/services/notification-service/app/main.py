from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings

from . import routes, service


class NotificationSettings(Settings):
    service_name: str = "notification-service"
    reminder_job_interval_seconds: int = 60


def build(settings: Settings | None = None) -> FastAPI:
    settings = settings or NotificationSettings()
    return create_app(
        title="PFM Notification Service",
        description="Budget threshold alerts, monthly report notifications and financial reminders.",
        settings=settings,
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.router, routes.reminders],
        subscriptions={"budget.threshold_reached": service.on_budget_threshold,
                       "report.monthly_ready": service.on_monthly_report,
                       "user.registered": service.on_user_registered},
        jobs=[("reminder-dispatcher", settings.reminder_job_interval_seconds, service.dispatch_due_reminders)],
    )


app = build()
