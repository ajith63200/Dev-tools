from datetime import date
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])
reminders = APIRouter(prefix="/api/v1/reminders", tags=["reminders"])


class ReminderIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    note: str = Field("", max_length=500)
    due_date: date
    recurrence: Literal["none", "monthly"] = "none"


@router.get("")
def list_notifications(unread_only: bool = False, limit: int = Query(30, ge=1, le=200),
                       user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        items = conn.execute(
            "SELECT id, type, severity, title, message, metadata, is_read, created_at FROM notifications "
            "WHERE user_id = %s AND (NOT %s OR NOT is_read) ORDER BY created_at DESC LIMIT %s",
            (user.user_id, unread_only, limit)).fetchall()
        unread = conn.execute("SELECT count(*) AS n FROM notifications WHERE user_id = %s AND NOT is_read",
                              (user.user_id,)).fetchone()["n"]
    return {"items": items, "unread_count": unread}


@router.post("/read-all", status_code=204)
def mark_all_read(user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        conn.execute("UPDATE notifications SET is_read = TRUE, updated_at = now() WHERE user_id = %s AND NOT is_read",
                     (user.user_id,))


@router.post("/{notification_id}/read", status_code=204)
def mark_read(notification_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        if not conn.execute("UPDATE notifications SET is_read = TRUE, updated_at = now() "
                            "WHERE id = %s AND user_id = %s", (notification_id, user.user_id)).rowcount:
            raise HTTPException(404, "Notification not found")


@router.delete("/{notification_id}", status_code=204)
def delete_notification(notification_id: UUID, user: Principal = Depends(current_user),
                        db: Database = Depends(get_db)):
    with db.tx() as conn:
        if not conn.execute("DELETE FROM notifications WHERE id = %s AND user_id = %s",
                            (notification_id, user.user_id)).rowcount:
            raise HTTPException(404, "Notification not found")


@reminders.get("")
def list_reminders(user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return conn.execute("SELECT id, title, note, due_date, recurrence, last_notified_on, created_at "
                            "FROM reminders WHERE user_id = %s ORDER BY due_date", (user.user_id,)).fetchall()


@reminders.post("", status_code=201)
def create_reminder(body: ReminderIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return conn.execute(
            "INSERT INTO reminders (user_id, title, note, due_date, recurrence) VALUES (%s, %s, %s, %s, %s) "
            "RETURNING id, title, note, due_date, recurrence, last_notified_on, created_at",
            (user.user_id, body.title.strip(), body.note.strip(), body.due_date, body.recurrence)).fetchone()


@reminders.delete("/{reminder_id}", status_code=204)
def delete_reminder(reminder_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        if not conn.execute("DELETE FROM reminders WHERE id = %s AND user_id = %s",
                            (reminder_id, user.user_id)).rowcount:
            raise HTTPException(404, "Reminder not found")
