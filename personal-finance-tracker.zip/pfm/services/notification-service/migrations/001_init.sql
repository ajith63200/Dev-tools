CREATE TABLE notifications (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL,
    type       TEXT NOT NULL CHECK (type IN ('budget_alert', 'monthly_report', 'reminder', 'system')),
    severity   TEXT NOT NULL DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'critical')),
    title      TEXT NOT NULL,
    message    TEXT NOT NULL,
    metadata   JSONB NOT NULL DEFAULT '{}',
    is_read    BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user_created ON notifications (user_id, created_at DESC);
CREATE INDEX idx_notifications_user_unread ON notifications (user_id) WHERE NOT is_read;

CREATE TABLE reminders (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID NOT NULL,
    title            TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 120),
    note             TEXT NOT NULL DEFAULT '',
    due_date         DATE NOT NULL,
    recurrence       TEXT NOT NULL DEFAULT 'none' CHECK (recurrence IN ('none', 'monthly')),
    last_notified_on DATE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reminders_due ON reminders (due_date) WHERE last_notified_on IS NULL;
CREATE INDEX idx_reminders_user ON reminders (user_id, due_date);
