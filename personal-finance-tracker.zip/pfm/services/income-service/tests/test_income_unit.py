from datetime import date
from decimal import Decimal
from uuid import uuid4

import pytest
from pydantic import ValidationError

from app.routes import IncomeIn, _record


def test_amount_must_be_positive_with_two_decimals():
    ok = IncomeIn(source_id=uuid4(), amount="1250.50", txn_date=date(2026, 5, 1))
    assert ok.amount == Decimal("1250.50")
    for bad in ("0", "-1", "10.999"):
        with pytest.raises(ValidationError):
            IncomeIn(source_id=uuid4(), amount=bad, txn_date=date(2026, 5, 1))


def test_event_record_uses_the_shared_transaction_shape():
    row = {"id": uuid4(), "amount": Decimal("10"), "txn_date": date(2026, 5, 1), "source_id": uuid4(),
           "source_name": "Freelancing", "description": "x"}
    assert set(_record(row)) == {"id", "amount", "date", "category_id", "category_name", "payment_method", "description"}
