CREATE TABLE income_sources (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID,                          -- NULL = built-in source visible to everyone
    name       TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 60),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_income_sources_owner_name
    ON income_sources (COALESCE(user_id, '00000000-0000-0000-0000-000000000000'::uuid), lower(name));

INSERT INTO income_sources (name) VALUES
    ('Monthly salary'), ('Freelancing'), ('Business income'), ('Investments'), ('Other income');

CREATE TABLE incomes (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL,
    source_id   UUID NOT NULL REFERENCES income_sources (id) ON DELETE RESTRICT,
    amount      NUMERIC(14, 2) NOT NULL CHECK (amount > 0),
    txn_date    DATE NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_incomes_user_date ON incomes (user_id, txn_date DESC);
CREATE INDEX idx_incomes_user_source ON incomes (user_id, source_id);
