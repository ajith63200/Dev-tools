from datetime import date, datetime
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database
from pfm_common.events import emit
from pfm_common.types import Money, PositiveMoney, Year

sources = APIRouter(prefix="/api/v1/income-sources", tags=["income sources"])
router = APIRouter(prefix="/api/v1/incomes", tags=["incomes"])

SELECT = ("SELECT i.id, i.source_id, s.name AS source_name, i.amount, i.txn_date, i.description, "
          "i.created_at, i.updated_at FROM incomes i JOIN income_sources s ON s.id = i.source_id")


class SourceIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)


class SourceOut(BaseModel):
    id: UUID
    name: str
    is_default: bool


class IncomeIn(BaseModel):
    source_id: UUID
    amount: PositiveMoney
    txn_date: date = Field(ge=date(2000, 1, 1), le=date(2100, 12, 31))
    description: str = Field("", max_length=500)


class IncomeOut(BaseModel):
    id: UUID
    source_id: UUID
    source_name: str
    amount: Money
    txn_date: date
    description: str
    created_at: datetime
    updated_at: datetime


class IncomePage(BaseModel):
    items: list[IncomeOut]
    total: int
    total_amount: Money
    limit: int
    offset: int


def _record(row: dict) -> dict:
    """Shape shared by income.* and expense.* events so consumers treat both uniformly."""
    return {"id": row["id"], "amount": row["amount"], "date": row["txn_date"], "category_id": row["source_id"],
            "category_name": row["source_name"], "payment_method": None, "description": row["description"]}


def _check_source(conn, user_id, source_id) -> None:
    if not conn.execute("SELECT 1 FROM income_sources WHERE id = %s AND (user_id IS NULL OR user_id = %s)",
                        (source_id, user_id)).fetchone():
        raise HTTPException(422, "Unknown income source")


def _get(conn, user_id, income_id) -> dict:
    row = conn.execute(f"{SELECT} WHERE i.id = %s AND i.user_id = %s", (income_id, user_id)).fetchone()
    if not row:
        raise HTTPException(404, "Income not found")
    return row


# ---------------------------------------------------------------- sources
@sources.get("", response_model=list[SourceOut])
def list_sources(user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return conn.execute(
            "SELECT id, name, user_id IS NULL AS is_default FROM income_sources "
            "WHERE user_id IS NULL OR user_id = %s ORDER BY user_id IS NOT NULL, created_at, name",
            (user.user_id,)).fetchall()


@sources.post("", response_model=SourceOut, status_code=201)
def create_source(body: SourceIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    name = body.name.strip()
    with db.tx() as conn:
        if conn.execute("SELECT 1 FROM income_sources WHERE (user_id IS NULL OR user_id = %s) AND lower(name) = lower(%s)",
                        (user.user_id, name)).fetchone():
            raise HTTPException(409, "An income source with this name already exists")
        return conn.execute("INSERT INTO income_sources (user_id, name) VALUES (%s, %s) "
                            "RETURNING id, name, FALSE AS is_default", (user.user_id, name)).fetchone()


@sources.delete("/{source_id}", status_code=204)
def delete_source(source_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        if conn.execute("SELECT 1 FROM incomes WHERE source_id = %s AND user_id = %s LIMIT 1",
                        (source_id, user.user_id)).fetchone():
            raise HTTPException(409, "Source is used by existing transactions")
        cur = conn.execute("DELETE FROM income_sources WHERE id = %s AND user_id = %s", (source_id, user.user_id))
        if not cur.rowcount:
            raise HTTPException(404, "Custom income source not found")


# ---------------------------------------------------------------- incomes
@router.get("", response_model=IncomePage)
def list_incomes(date_from: date | None = None, date_to: date | None = None, source_id: UUID | None = None,
                 search: str | None = Query(None, max_length=100), limit: int = Query(50, ge=1, le=500),
                 offset: int = Query(0, ge=0), user: Principal = Depends(current_user),
                 db: Database = Depends(get_db)):
    where, params = ["i.user_id = %(uid)s"], {"uid": user.user_id, "limit": limit, "offset": offset}
    if date_from:
        where.append("i.txn_date >= %(date_from)s"); params["date_from"] = date_from
    if date_to:
        where.append("i.txn_date <= %(date_to)s"); params["date_to"] = date_to
    if source_id:
        where.append("i.source_id = %(source_id)s"); params["source_id"] = source_id
    if search:
        where.append("(i.description ILIKE %(q)s OR s.name ILIKE %(q)s)"); params["q"] = f"%{search}%"
    clause = " AND ".join(where)
    with db.tx() as conn:
        agg = conn.execute("SELECT count(*) AS total, COALESCE(sum(i.amount), 0) AS total_amount FROM incomes i "
                           f"JOIN income_sources s ON s.id = i.source_id WHERE {clause}", params).fetchone()
        items = conn.execute(f"{SELECT} WHERE {clause} ORDER BY i.txn_date DESC, i.created_at DESC "
                             "LIMIT %(limit)s OFFSET %(offset)s", params).fetchall()
    return {"items": items, **agg, "limit": limit, "offset": offset}


@router.get("/summary")
def income_summary(year: Year, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Monthly and yearly income totals, plus the split by source."""
    args = (user.user_id, date(year, 1, 1), date(year + 1, 1, 1))
    with db.tx() as conn:
        months = {r["month"]: float(r["total"]) for r in conn.execute(
            "SELECT extract(month FROM txn_date)::int AS month, sum(amount) AS total FROM incomes "
            "WHERE user_id = %s AND txn_date >= %s AND txn_date < %s GROUP BY 1", args)}
        by_source = conn.execute(
            "SELECT s.name AS source, sum(i.amount)::float AS total FROM incomes i "
            "JOIN income_sources s ON s.id = i.source_id "
            "WHERE i.user_id = %s AND i.txn_date >= %s AND i.txn_date < %s GROUP BY s.name ORDER BY total DESC",
            args).fetchall()
    return {"year": year, "total": round(sum(months.values()), 2),
            "months": [{"month": m, "total": months.get(m, 0.0)} for m in range(1, 13)], "by_source": by_source}


@router.post("", response_model=IncomeOut, status_code=201)
def create_income(body: IncomeIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        _check_source(conn, user.user_id, body.source_id)
        new_id = conn.execute(
            "INSERT INTO incomes (user_id, source_id, amount, txn_date, description) VALUES (%s, %s, %s, %s, %s) "
            "RETURNING id", (user.user_id, body.source_id, body.amount, body.txn_date, body.description.strip())
        ).fetchone()["id"]
        row = _get(conn, user.user_id, new_id)
        emit(conn, "income.created", user.user_id, {"before": None, "after": _record(row)})
        return row


@router.get("/{income_id}", response_model=IncomeOut)
def get_income(income_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return _get(conn, user.user_id, income_id)


@router.put("/{income_id}", response_model=IncomeOut)
def update_income(income_id: UUID, body: IncomeIn, user: Principal = Depends(current_user),
                  db: Database = Depends(get_db)):
    with db.tx() as conn:
        before = _get(conn, user.user_id, income_id)
        _check_source(conn, user.user_id, body.source_id)
        conn.execute("UPDATE incomes SET source_id = %s, amount = %s, txn_date = %s, description = %s, "
                     "updated_at = now() WHERE id = %s AND user_id = %s",
                     (body.source_id, body.amount, body.txn_date, body.description.strip(), income_id, user.user_id))
        row = _get(conn, user.user_id, income_id)
        emit(conn, "income.updated", user.user_id, {"before": _record(before), "after": _record(row)})
        return row


@router.delete("/{income_id}", status_code=204)
def delete_income(income_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        before = _get(conn, user.user_id, income_id)
        conn.execute("DELETE FROM incomes WHERE id = %s AND user_id = %s", (income_id, user.user_id))
        emit(conn, "income.deleted", user.user_id, {"before": _record(before), "after": None})
