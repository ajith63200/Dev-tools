from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings

from . import routes


class IncomeSettings(Settings):
    service_name: str = "income-service"


def build(settings: Settings | None = None) -> FastAPI:
    return create_app(
        title="PFM Income Service",
        description="Income transactions, income sources and income aggregation.",
        settings=settings or IncomeSettings(),
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.sources, routes.router],
    )


app = build()
