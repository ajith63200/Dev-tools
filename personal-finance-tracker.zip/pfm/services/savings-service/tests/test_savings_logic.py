from decimal import Decimal as D

from app.logic import goal_progress, savings_line


def test_savings_is_income_minus_expenses():
    assert savings_line(D("50000"), D("32000")) == {"income": 50000.0, "expense": 32000.0, "savings": 18000.0,
                                                    "savings_pct": 36.0}


def test_overspending_gives_negative_savings_and_rate():
    line = savings_line(D("1000"), D("1500"))
    assert line["savings"] == -500.0 and line["savings_pct"] == -50.0


def test_no_income_does_not_divide_by_zero():
    assert savings_line(D("0"), D("200"))["savings_pct"] == 0.0


def test_goal_progress():
    assert goal_progress(D("2500"), D("10000")) == {"saved": 2500.0, "progress_pct": 25.0, "achieved": False,
                                                    "remaining": 7500.0}
    assert goal_progress(D("12000"), D("10000"))["achieved"] is True
    assert goal_progress(D("-300"), D("10000"))["progress_pct"] == 0.0
