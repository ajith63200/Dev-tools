-- Local projection of income and expense totals, maintained from income.* / expense.* events.
CREATE TABLE monthly_totals (
    user_id    UUID NOT NULL,
    year       INT NOT NULL,
    month      INT NOT NULL CHECK (month BETWEEN 1 AND 12),
    income     NUMERIC(14, 2) NOT NULL DEFAULT 0,
    expense    NUMERIC(14, 2) NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, year, month)
);

CREATE TABLE savings_goals (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL,
    name          TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    period        TEXT NOT NULL CHECK (period IN ('monthly', 'yearly')),
    year          INT NOT NULL CHECK (year BETWEEN 2000 AND 2100),
    month         INT CHECK (month BETWEEN 1 AND 12),
    target_amount NUMERIC(14, 2) NOT NULL CHECK (target_amount > 0),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK ((period = 'monthly') = (month IS NOT NULL))
);
CREATE INDEX idx_savings_goals_user_period ON savings_goals (user_id, year, month);
