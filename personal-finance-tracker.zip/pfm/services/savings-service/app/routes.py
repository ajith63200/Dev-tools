from datetime import date
from decimal import Decimal
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, model_validator

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database
from pfm_common.types import Month, PositiveMoney, Year

from .logic import goal_progress, savings_line

router = APIRouter(prefix="/api/v1/savings", tags=["savings"])


class GoalIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    period: Literal["monthly", "yearly"]
    year: Year
    month: Month | None = None
    target_amount: PositiveMoney

    @model_validator(mode="after")
    def month_matches_period(self):
        if (self.period == "monthly") != (self.month is not None):
            raise ValueError("month is required for monthly goals and must be omitted for yearly goals")
        return self


def on_transaction_event(conn, event: dict) -> None:
    column = "income" if event["type"].startswith("income.") else "expense"
    for record, sign in ((event["data"].get("before"), -1), (event["data"].get("after"), +1)):
        if record:
            day = date.fromisoformat(record["date"])
            conn.execute(
                f"INSERT INTO monthly_totals (user_id, year, month, {column}) VALUES (%s, %s, %s, %s) "
                f"ON CONFLICT (user_id, year, month) DO UPDATE SET {column} = monthly_totals.{column} + "
                f"EXCLUDED.{column}, updated_at = now()",
                (event["user_id"], day.year, day.month, sign * Decimal(str(record["amount"]))))


def _year_totals(conn, user_id, year: int) -> dict[int, dict]:
    return {r["month"]: r for r in conn.execute(
        "SELECT month, income, expense FROM monthly_totals WHERE user_id = %s AND year = %s", (user_id, year))}


def _goal_view(goal: dict, totals: dict[int, dict]) -> dict:
    months = [goal["month"]] if goal["period"] == "monthly" else range(1, 13)
    saved = sum((totals[m]["income"] - totals[m]["expense"] for m in months if m in totals), Decimal(0))
    return {**goal, "target_amount": float(goal["target_amount"]), **goal_progress(saved, goal["target_amount"])}


@router.get("/summary")
def summary(year: Year, month: Month, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Savings and savings rate for one month."""
    with db.tx() as conn:
        row = _year_totals(conn, user.user_id, year).get(month, {"income": Decimal(0), "expense": Decimal(0)})
    return {"year": year, "month": month, **savings_line(row["income"], row["expense"])}


@router.get("/history")
def history(year: Year, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Month-by-month savings trend for a year, with yearly totals."""
    with db.tx() as conn:
        totals = _year_totals(conn, user.user_id, year)
    zero = {"income": Decimal(0), "expense": Decimal(0)}
    months = [{"month": m, **savings_line(totals.get(m, zero)["income"], totals.get(m, zero)["expense"])}
              for m in range(1, 13)]
    income = sum((t["income"] for t in totals.values()), Decimal(0))
    expense = sum((t["expense"] for t in totals.values()), Decimal(0))
    return {"year": year, "months": months, "totals": savings_line(income, expense)}


@router.get("/goals")
def list_goals(year: Year, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Goals for a year with progress computed from recorded transactions."""
    with db.tx() as conn:
        totals = _year_totals(conn, user.user_id, year)
        goals = conn.execute("SELECT * FROM savings_goals WHERE user_id = %s AND year = %s "
                             "ORDER BY period DESC, month, created_at", (user.user_id, year)).fetchall()
    return [_goal_view(g, totals) for g in goals]


@router.post("/goals", status_code=201)
def create_goal(body: GoalIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        goal = conn.execute(
            "INSERT INTO savings_goals (user_id, name, period, year, month, target_amount) "
            "VALUES (%s, %s, %s, %s, %s, %s) RETURNING *",
            (user.user_id, body.name.strip(), body.period, body.year, body.month, body.target_amount)).fetchone()
        return _goal_view(goal, _year_totals(conn, user.user_id, body.year))


@router.put("/goals/{goal_id}")
def update_goal(goal_id: UUID, body: GoalIn, user: Principal = Depends(current_user),
                db: Database = Depends(get_db)):
    with db.tx() as conn:
        goal = conn.execute(
            "UPDATE savings_goals SET name = %s, period = %s, year = %s, month = %s, target_amount = %s, "
            "updated_at = now() WHERE id = %s AND user_id = %s RETURNING *",
            (body.name.strip(), body.period, body.year, body.month, body.target_amount, goal_id,
             user.user_id)).fetchone()
        if not goal:
            raise HTTPException(404, "Goal not found")
        return _goal_view(goal, _year_totals(conn, user.user_id, body.year))


@router.delete("/goals/{goal_id}", status_code=204)
def delete_goal(goal_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        if not conn.execute("DELETE FROM savings_goals WHERE id = %s AND user_id = %s",
                            (goal_id, user.user_id)).rowcount:
            raise HTTPException(404, "Goal not found")
