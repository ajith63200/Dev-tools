"""Savings = Total Income - Total Expenses."""
from decimal import Decimal


def savings_line(income: Decimal, expense: Decimal) -> dict:
    savings = income - expense
    pct = round(float(savings / income * 100), 1) if income > 0 else 0.0
    return {"income": float(income), "expense": float(expense), "savings": float(savings), "savings_pct": pct}


def goal_progress(saved: Decimal, target: Decimal) -> dict:
    pct = round(max(float(saved / target * 100), 0.0), 1) if target > 0 else 0.0
    return {"saved": float(saved), "progress_pct": pct, "achieved": saved >= target,
            "remaining": float(max(target - saved, Decimal(0)))}
