from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings

from . import routes


class SavingsSettings(Settings):
    service_name: str = "savings-service"


def build(settings: Settings | None = None) -> FastAPI:
    return create_app(
        title="PFM Savings Service",
        description="Automatic savings calculation, savings history and financial goals.",
        settings=settings or SavingsSettings(),
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.router],
        subscriptions={"income.*": routes.on_transaction_event, "expense.*": routes.on_transaction_event},
    )


app = build()
