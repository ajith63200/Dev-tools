from app.main import GatewaySettings
from app.ratelimit import RateLimiter
from app.routing import RESOURCE_TO_SERVICE, is_public, resolve


def test_every_resource_resolves_to_a_configured_upstream():
    upstreams = GatewaySettings().upstreams()
    assert len(upstreams) == 8
    for resource in RESOURCE_TO_SERVICE:
        assert resolve(resource, upstreams).startswith("http://")
    assert resolve("admin", upstreams) is None


def test_only_login_register_refresh_are_public():
    assert is_public("POST", "/api/v1/auth/login") and is_public("post", "/api/v1/auth/register/")
    assert not is_public("GET", "/api/v1/auth/login")
    assert not is_public("GET", "/api/v1/auth/me") and not is_public("POST", "/api/v1/expenses")


def test_rate_limiter_blocks_after_limit_and_resets_next_window():
    now = [1_000_000.0]
    limiter = RateLimiter(clock=lambda: now[0])
    assert [limiter.hit("ip:1", limit=3)[0] for _ in range(4)] == [True, True, True, False]
    assert limiter.hit("ip:2", limit=3)[0] is True          # separate key
    now[0] += 60
    assert limiter.hit("ip:1", limit=3)[0] is True


def test_rate_limiter_reports_retry_after_within_window():
    limiter = RateLimiter(clock=lambda: 90.0)
    assert 1 <= limiter.hit("k", 1)[1] <= 61
