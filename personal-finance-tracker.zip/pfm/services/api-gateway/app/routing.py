"""Route table: the first path segment after /api/v1 selects the upstream service."""

PUBLIC = {("POST", "/api/v1/auth/login"), ("POST", "/api/v1/auth/register"), ("POST", "/api/v1/auth/refresh")}

RESOURCE_TO_SERVICE = {
    "auth": "auth",
    "users": "user",
    "incomes": "income", "income-sources": "income",
    "expenses": "expense", "categories": "expense",
    "budgets": "budget",
    "savings": "savings",
    "analytics": "analytics",
    "notifications": "notification", "reminders": "notification",
}

HOP_BY_HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers",
              "transfer-encoding", "upgrade", "host", "content-length"}


def resolve(resource: str, upstreams: dict[str, str]) -> str | None:
    service = RESOURCE_TO_SERVICE.get(resource)
    return upstreams.get(service) if service else None


def is_public(method: str, path: str) -> bool:
    return (method.upper(), path.rstrip("/")) in PUBLIC
