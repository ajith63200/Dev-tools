"""Fixed-window rate limiting. Redis-backed when available (shared across replicas), in-memory otherwise."""
import logging
import threading
import time
from collections.abc import Callable

log = logging.getLogger(__name__)


class RateLimiter:
    def __init__(self, redis_url: str = "", clock: Callable[[], float] = time.time):
        self.clock = clock
        self._local: dict[str, int] = {}
        self._lock = threading.Lock()
        self.redis = None
        if redis_url:
            import redis
            self.redis = redis.Redis.from_url(redis_url, socket_timeout=0.3, socket_connect_timeout=0.3)

    def hit(self, key: str, limit: int, window: int = 60) -> tuple[bool, int]:
        """Record one request. Returns (allowed, seconds until the window resets)."""
        now = self.clock()
        bucket = int(now // window)
        retry_after = int(window - now % window) + 1
        name = f"rl:{key}:{bucket}"
        count = self._redis_hit(name, window)
        if count is None:
            count = self._local_hit(name, bucket)
        return count <= limit, retry_after

    def _redis_hit(self, name: str, window: int) -> int | None:
        if not self.redis:
            return None
        try:
            pipe = self.redis.pipeline()
            pipe.incr(name)
            pipe.expire(name, window * 2)
            return int(pipe.execute()[0])
        except Exception:
            return None  # fail open to the local limiter rather than rejecting traffic

    def _local_hit(self, name: str, bucket: int) -> int:
        with self._lock:
            if len(self._local) > 50_000:  # drop expired windows
                self._local = {k: v for k, v in self._local.items() if k.endswith(f":{bucket}")}
            self._local[name] = self._local.get(name, 0) + 1
            return self._local[name]
