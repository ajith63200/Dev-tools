"""API gateway: single entry point, routing, token validation and rate limiting."""
import asyncio
import logging

import httpx
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse

from pfm_common.app import create_app
from pfm_common.auth import decode_token
from pfm_common.config import Settings

from .ratelimit import RateLimiter
from .routing import HOP_BY_HOP, RESOURCE_TO_SERVICE, is_public, resolve

log = logging.getLogger("pfm.gateway")
METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"]


class GatewaySettings(Settings):
    service_name: str = "api-gateway"
    auth_service_url: str = "http://auth-service:8000"
    user_service_url: str = "http://user-service:8000"
    income_service_url: str = "http://income-service:8000"
    expense_service_url: str = "http://expense-service:8000"
    budget_service_url: str = "http://budget-service:8000"
    savings_service_url: str = "http://savings-service:8000"
    analytics_service_url: str = "http://analytics-service:8000"
    notification_service_url: str = "http://notification-service:8000"
    rate_limit_per_minute: int = 600       # per authenticated user
    auth_rate_limit_per_minute: int = 20   # per client IP on login/register/refresh
    upstream_timeout_seconds: float = 15.0
    max_body_bytes: int = 1_048_576

    def upstreams(self) -> dict[str, str]:
        return {name: getattr(self, f"{name}_service_url").rstrip("/")
                for name in set(RESOURCE_TO_SERVICE.values())}


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    return forwarded.split(",")[0].strip() if forwarded else (request.client.host if request.client else "unknown")


def build(settings: Settings | None = None, transport: httpx.AsyncBaseTransport | None = None) -> FastAPI:
    settings = settings or GatewaySettings()
    upstreams = settings.upstreams()
    limiter = RateLimiter(settings.redis_url)
    app = create_app(
        title="PFM API Gateway",
        description="Central entry point. Routes /api/v1/* to the owning microservice.",
        settings=settings, use_database=False,
    )
    app.state.client = httpx.AsyncClient(timeout=settings.upstream_timeout_seconds, transport=transport)
    app.state.limiter = limiter

    @app.get("/api/v1/status", tags=["gateway"])
    async def status():
        """Readiness of every upstream service."""
        async def probe(name: str, url: str):
            try:
                resp = await app.state.client.get(f"{url}/health/ready", timeout=2.0)
                return name, "ok" if resp.status_code == 200 else "degraded"
            except httpx.HTTPError:
                return name, "down"
        results = dict(await asyncio.gather(*(probe(n, u) for n, u in sorted(upstreams.items()))))
        healthy = all(v == "ok" for v in results.values())
        return JSONResponse({"status": "ok" if healthy else "degraded", "services": results},
                            status_code=200 if healthy else 503)

    @app.get("/api/v1/openapi/{service}", tags=["gateway"])
    async def service_openapi(service: str):
        """OpenAPI document of one upstream service (auth, user, income, expense, budget, ...)."""
        if service not in upstreams:
            raise HTTPException(404, "Unknown service")
        resp = await app.state.client.get(f"{upstreams[service]}/openapi.json")
        return Response(resp.content, media_type="application/json")

    @app.api_route("/api/v1/{resource}", methods=METHODS, include_in_schema=False)
    @app.api_route("/api/v1/{resource}/{rest:path}", methods=METHODS, include_in_schema=False)
    async def proxy(resource: str, request: Request, rest: str = ""):
        upstream = resolve(resource, upstreams)
        if upstream is None:
            raise HTTPException(404, "Not found")
        path = request.url.path
        ip = client_ip(request)

        if is_public(request.method, path):
            allowed, retry = limiter.hit(f"auth:{ip}", settings.auth_rate_limit_per_minute)
        else:
            header = request.headers.get("authorization", "")
            if not header.lower().startswith("bearer "):
                raise HTTPException(401, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
            claims = decode_token(settings, header[7:])
            request.state.user_id = claims["sub"]
            allowed, retry = limiter.hit(f"user:{claims['sub']}", settings.rate_limit_per_minute)
        if not allowed:
            return JSONResponse({"detail": "Too many requests"}, status_code=429, headers={"Retry-After": str(retry)})

        body = await request.body()
        if len(body) > settings.max_body_bytes:
            raise HTTPException(413, "Request body too large")
        headers = {k: v for k, v in request.headers.items() if k.lower() not in HOP_BY_HOP}
        headers["x-request-id"] = request.state.request_id
        headers["x-forwarded-for"] = ip
        try:
            resp = await app.state.client.request(request.method, f"{upstream}{path}", params=request.query_params,
                                                  content=body, headers=headers)
        except httpx.TimeoutException:
            return JSONResponse({"detail": "Upstream service timed out"}, status_code=504)
        except httpx.HTTPError:
            log.warning("upstream unavailable", extra={"upstream": resource})
            return JSONResponse({"detail": "Service temporarily unavailable"}, status_code=503)
        passthrough = {k: v for k, v in resp.headers.items()
                       if k.lower() in ("content-type", "content-disposition", "www-authenticate", "retry-after")}
        return Response(resp.content, status_code=resp.status_code, headers=passthrough)

    return app


app = build()
