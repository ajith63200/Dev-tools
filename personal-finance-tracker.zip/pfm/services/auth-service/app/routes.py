from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status

from pfm_common.app import get_db
from pfm_common.auth import Principal, create_token, current_user, decode_token, require_role
from pfm_common.db import Database
from pfm_common.events import emit

from .schemas import (
    AuthResponse,
    ChangePasswordRequest,
    LoginRequest,
    RefreshRequest,
    RegisterRequest,
    RoleUpdate,
    TokenPair,
    UserOut,
)
from .security import DUMMY_HASH, hash_password, verify_password

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])
USER_COLS = "id, email, role, is_active, created_at"


def _tokens(request: Request, user: dict) -> TokenPair:
    s = request.app.state.settings
    args = dict(user_id=str(user["id"]), email=user["email"], role=user["role"])
    return TokenPair(access_token=create_token(s, kind="access", **args),
                     refresh_token=create_token(s, kind="refresh", **args),
                     expires_in=s.access_token_ttl_minutes * 60)


@router.post("/register", response_model=AuthResponse, status_code=201)
def register(body: RegisterRequest, request: Request, db: Database = Depends(get_db)):
    with db.tx() as conn:
        if conn.execute("SELECT 1 FROM users WHERE lower(email) = lower(%s)", (body.email,)).fetchone():
            raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")
        user = conn.execute(
            f"INSERT INTO users (email, password_hash) VALUES (%s, %s) RETURNING {USER_COLS}",
            (body.email.lower(), hash_password(body.password))).fetchone()
        emit(conn, "user.registered", user["id"], {"email": user["email"], "full_name": body.full_name})
    return AuthResponse(user=UserOut(**user), tokens=_tokens(request, user))


@router.post("/login", response_model=AuthResponse)
def login(body: LoginRequest, request: Request, db: Database = Depends(get_db)):
    with db.tx() as conn:
        row = conn.execute(f"SELECT {USER_COLS}, password_hash FROM users WHERE lower(email) = lower(%s)",
                           (body.email,)).fetchone()
        valid = verify_password(body.password, row["password_hash"] if row else DUMMY_HASH)
        if not (row and valid and row["is_active"]):
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
        conn.execute("UPDATE users SET last_login_at = now() WHERE id = %s", (row["id"],))
    return AuthResponse(user=UserOut(**row), tokens=_tokens(request, row))


@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, request: Request, db: Database = Depends(get_db)):
    claims = decode_token(request.app.state.settings, body.refresh_token, kind="refresh")
    with db.tx() as conn:  # re-read so role changes and deactivation take effect
        user = conn.execute(f"SELECT {USER_COLS} FROM users WHERE id = %s AND is_active", (claims["sub"],)).fetchone()
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
    return _tokens(request, user)


@router.get("/me", response_model=UserOut)
def me(user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        row = conn.execute(f"SELECT {USER_COLS} FROM users WHERE id = %s", (user.user_id,)).fetchone()
    if not row:
        raise HTTPException(404, "User not found")
    return row


@router.post("/change-password", status_code=204)
def change_password(body: ChangePasswordRequest, user: Principal = Depends(current_user),
                    db: Database = Depends(get_db)):
    with db.tx() as conn:
        row = conn.execute("SELECT password_hash FROM users WHERE id = %s", (user.user_id,)).fetchone()
        if not row or not verify_password(body.current_password, row["password_hash"]):
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Current password is incorrect")
        conn.execute("UPDATE users SET password_hash = %s, updated_at = now() WHERE id = %s",
                     (hash_password(body.new_password), user.user_id))


# ---- administration (role-based access control) ----
@router.get("/users", response_model=list[UserOut])
def list_users(limit: int = 50, offset: int = 0, _: Principal = Depends(require_role("admin")),
               db: Database = Depends(get_db)):
    with db.tx() as conn:
        return conn.execute(f"SELECT {USER_COLS} FROM users ORDER BY created_at LIMIT %s OFFSET %s",
                            (min(limit, 200), max(offset, 0))).fetchall()


@router.patch("/users/{user_id}/role", response_model=UserOut)
def set_role(user_id: UUID, body: RoleUpdate, _: Principal = Depends(require_role("admin")),
             db: Database = Depends(get_db)):
    with db.tx() as conn:
        row = conn.execute(f"UPDATE users SET role = %s, updated_at = now() WHERE id = %s RETURNING {USER_COLS}",
                           (body.role, user_id)).fetchone()
    if not row:
        raise HTTPException(404, "User not found")
    return row
