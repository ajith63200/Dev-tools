import logging
from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings
from pfm_common.events import emit

from . import routes
from .security import hash_password


class AuthSettings(Settings):
    service_name: str = "auth-service"
    admin_email: str = ""      # optional bootstrap administrator
    admin_password: str = ""


def bootstrap_admin(app: FastAPI) -> None:
    s: AuthSettings = app.state.settings
    if not (s.admin_email and s.admin_password):
        return
    with app.state.db.tx() as conn:
        row = conn.execute(
            "INSERT INTO users (email, password_hash, role) VALUES (%s, %s, 'admin') "
            "ON CONFLICT (lower(email)) DO NOTHING RETURNING id, email",
            (s.admin_email.lower(), hash_password(s.admin_password))).fetchone()
        if row:
            emit(conn, "user.registered", row["id"], {"email": row["email"], "full_name": "Administrator"})
            logging.getLogger("pfm").info("bootstrap administrator created")


def build(settings: Settings | None = None) -> FastAPI:
    return create_app(
        title="PFM Authentication Service",
        description="Registration, login, JWT issuance and role management.",
        settings=settings or AuthSettings(),
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.router],
        on_startup=bootstrap_admin,
    )


app = build()
