"""Password hashing (bcrypt, per-password salt, cost 12)."""
import bcrypt


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12)).decode()


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), password_hash.encode())
    except ValueError:
        return False


# Compared against when the account does not exist, so login timing does not reveal valid emails.
DUMMY_HASH = hash_password("timing-equaliser")
