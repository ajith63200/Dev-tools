import pytest
from pydantic import ValidationError

from app.schemas import RegisterRequest
from app.security import hash_password, verify_password


def test_password_is_hashed_with_bcrypt_and_salted():
    first, second = hash_password("Passw0rd!x"), hash_password("Passw0rd!x")
    assert first.startswith("$2b$12$") and first != second
    assert verify_password("Passw0rd!x", first) and not verify_password("passw0rd!x", first)


def test_verify_tolerates_malformed_hash():
    assert verify_password("anything", "not-a-hash") is False


@pytest.mark.parametrize("password", ["short1", "allletters", "12345678", "x1" * 40])
def test_weak_or_oversized_passwords_rejected(password):
    with pytest.raises(ValidationError):
        RegisterRequest(email="a@example.com", password=password, full_name="A")


def test_email_must_be_valid():
    with pytest.raises(ValidationError):
        RegisterRequest(email="not-an-email", password="Passw0rd!x", full_name="A")
