from decimal import Decimal

import pytest

from app.logic import line, reached_thresholds, status_for, utilization_pct


@pytest.mark.parametrize("spent,limit,expected", [(0, 1000, 0.0), (799.99, 1000, 80.0), (800, 1000, 80.0),
                                                  (1500, 1000, 150.0), (10, 0, 0.0)])
def test_utilization(spent, limit, expected):
    assert utilization_pct(Decimal(str(spent)), Decimal(str(limit))) == expected


@pytest.mark.parametrize("pct,thresholds,status", [(79.9, [], "ok"), (80, [80], "warning"), (90, [80, 90], "critical"),
                                                   (100, [80, 90, 100], "exceeded"), (240, [80, 90, 100], "exceeded")])
def test_thresholds_and_status(pct, thresholds, status):
    assert reached_thresholds(pct) == thresholds and status_for(pct) == status


def test_line_reports_negative_remaining_when_over_budget():
    assert line(Decimal("1000"), Decimal("1250")) == {
        "limit_amount": 1000.0, "spent": 1250.0, "remaining": -250.0, "utilization_pct": 125.0, "status": "exceeded"}
