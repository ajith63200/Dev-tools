CREATE TABLE budgets (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL,
    year          INT NOT NULL CHECK (year BETWEEN 2000 AND 2100),
    month         INT NOT NULL CHECK (month BETWEEN 1 AND 12),
    category_id   UUID,                       -- NULL = overall monthly limit; id owned by expense-service
    category_name TEXT,
    limit_amount  NUMERIC(14, 2) NOT NULL CHECK (limit_amount > 0),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK ((category_id IS NULL) = (category_name IS NULL))
);
CREATE UNIQUE INDEX uq_budgets_scope
    ON budgets (user_id, year, month, COALESCE(category_id, '00000000-0000-0000-0000-000000000000'::uuid));

-- Local projection of spending, maintained from expense.* events.
CREATE TABLE category_spend (
    user_id       UUID NOT NULL,
    year          INT NOT NULL,
    month         INT NOT NULL,
    category_id   UUID NOT NULL,
    category_name TEXT NOT NULL,
    spent         NUMERIC(14, 2) NOT NULL DEFAULT 0,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, year, month, category_id)
);

-- Which thresholds (80/90/100) have already been announced for a budget.
CREATE TABLE budget_alerts (
    budget_id UUID NOT NULL REFERENCES budgets (id) ON DELETE CASCADE,
    threshold INT NOT NULL CHECK (threshold IN (80, 90, 100)),
    sent_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (budget_id, threshold)
);
