from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings

from . import routes, service


class BudgetSettings(Settings):
    service_name: str = "budget-service"


def build(settings: Settings | None = None) -> FastAPI:
    return create_app(
        title="PFM Budget Service",
        description="Monthly and category budgets, utilisation tracking and threshold alerts.",
        settings=settings or BudgetSettings(),
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.router],
        subscriptions={"expense.*": service.on_expense_event},
    )


app = build()
