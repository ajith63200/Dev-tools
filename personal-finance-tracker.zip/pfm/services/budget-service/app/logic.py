"""Pure budget rules (no I/O) so they are trivially unit-testable."""
from decimal import Decimal

THRESHOLDS = (80, 90, 100)


def utilization_pct(spent: Decimal, limit: Decimal) -> float:
    return round(float(spent / limit * 100), 1) if limit > 0 else 0.0


def reached_thresholds(pct: float) -> list[int]:
    return [t for t in THRESHOLDS if pct >= t]


def status_for(pct: float) -> str:
    if pct >= 100:
        return "exceeded"
    if pct >= 90:
        return "critical"
    if pct >= 80:
        return "warning"
    return "ok"


def line(limit: Decimal, spent: Decimal) -> dict:
    pct = utilization_pct(spent, limit)
    return {"limit_amount": float(limit), "spent": float(spent), "remaining": float(limit - spent),
            "utilization_pct": pct, "status": status_for(pct)}
