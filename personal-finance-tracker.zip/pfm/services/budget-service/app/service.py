"""Budget state changes: spend projection and threshold alerts."""
from datetime import date, datetime, timezone
from decimal import Decimal

from pfm_common.events import emit

from .logic import reached_thresholds, utilization_pct


def apply_spend(conn, user_id, record: dict, sign: int) -> tuple[int, int]:
    day = date.fromisoformat(record["date"])
    conn.execute(
        "INSERT INTO category_spend (user_id, year, month, category_id, category_name, spent) "
        "VALUES (%s, %s, %s, %s, %s, %s) ON CONFLICT (user_id, year, month, category_id) DO UPDATE SET "
        "spent = category_spend.spent + EXCLUDED.spent, category_name = EXCLUDED.category_name, updated_at = now()",
        (user_id, day.year, day.month, record["category_id"], record["category_name"],
         sign * Decimal(str(record["amount"]))))
    return day.year, day.month


def spend_by_category(conn, user_id, year: int, month: int) -> dict:
    rows = conn.execute("SELECT category_id, category_name, spent FROM category_spend "
                        "WHERE user_id = %s AND year = %s AND month = %s AND spent <> 0", (user_id, year, month))
    return {r["category_id"]: r for r in rows}


def evaluate_alerts(conn, user_id, year: int, month: int, today: date | None = None) -> list[dict]:
    """Record newly reached thresholds; announce the highest one, once, for current/future months only."""
    today = today or datetime.now(timezone.utc).date()
    spend = spend_by_category(conn, user_id, year, month)
    total = sum((r["spent"] for r in spend.values()), Decimal(0))
    events = []
    for budget in conn.execute("SELECT * FROM budgets WHERE user_id = %s AND year = %s AND month = %s",
                               (user_id, year, month)).fetchall():
        spent = total if budget["category_id"] is None else spend.get(budget["category_id"], {}).get("spent", Decimal(0))
        pct = utilization_pct(spent, budget["limit_amount"])
        # Spending dropped (edit/delete) or the limit was raised: allow the alert to fire again later.
        conn.execute("DELETE FROM budget_alerts WHERE budget_id = %s AND threshold > %s", (budget["id"], pct))
        new = [t for t in reached_thresholds(pct) if conn.execute(
            "INSERT INTO budget_alerts (budget_id, threshold) VALUES (%s, %s) ON CONFLICT DO NOTHING",
            (budget["id"], t)).rowcount]
        if new and (year, month) >= (today.year, today.month):
            events.append(emit(conn, "budget.threshold_reached", user_id, {
                "budget_id": budget["id"], "scope": "category" if budget["category_id"] else "overall",
                "category_name": budget["category_name"], "threshold": max(new), "year": year, "month": month,
                "spent": spent, "limit_amount": budget["limit_amount"], "utilization_pct": pct}))
    return events


def on_expense_event(conn, event: dict) -> None:
    periods = set()
    if event["data"].get("before"):
        periods.add(apply_spend(conn, event["user_id"], event["data"]["before"], -1))
    if event["data"].get("after"):
        periods.add(apply_spend(conn, event["user_id"], event["data"]["after"], +1))
    for year, month in periods:
        evaluate_alerts(conn, event["user_id"], year, month)
