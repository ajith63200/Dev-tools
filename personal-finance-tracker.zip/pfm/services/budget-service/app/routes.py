from decimal import Decimal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, model_validator

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database
from pfm_common.events import emit
from pfm_common.types import Month, PositiveMoney, Year

from .logic import line
from .service import evaluate_alerts, spend_by_category

router = APIRouter(prefix="/api/v1/budgets", tags=["budgets"])
ZERO_UUID = "00000000-0000-0000-0000-000000000000"


class BudgetIn(BaseModel):
    year: Year
    month: Month
    category_id: UUID | None = Field(None, description="Omit for the overall monthly limit")
    category_name: str | None = Field(None, max_length=60)
    limit_amount: PositiveMoney

    @model_validator(mode="after")
    def category_pair(self):
        if (self.category_id is None) != (self.category_name is None):
            raise ValueError("category_id and category_name must be provided together")
        return self


class CopyRequest(BaseModel):
    from_year: Year
    from_month: Month
    to_year: Year
    to_month: Month


def build_view(conn, user_id, year: int, month: int) -> dict:
    budgets = conn.execute("SELECT * FROM budgets WHERE user_id = %s AND year = %s AND month = %s "
                           "ORDER BY category_name NULLS FIRST", (user_id, year, month)).fetchall()
    spend = spend_by_category(conn, user_id, year, month)
    total_spent = sum((r["spent"] for r in spend.values()), Decimal(0))
    overall, categories, budgeted_ids = None, [], set()
    for b in budgets:
        if b["category_id"] is None:
            overall = {"id": b["id"], **line(b["limit_amount"], total_spent)}
        else:
            budgeted_ids.add(b["category_id"])
            spent = spend.get(b["category_id"], {}).get("spent", Decimal(0))
            categories.append({"id": b["id"], "category_id": b["category_id"], "category_name": b["category_name"],
                               **line(b["limit_amount"], spent)})
    category_limit = sum((Decimal(str(c["limit_amount"])) for c in categories), Decimal(0))
    # Without an explicit overall limit, the plan is the sum of the category budgets.
    effective = Decimal(str(overall["limit_amount"])) if overall else category_limit
    return {
        "year": year, "month": month, "overall": overall, "categories": categories,
        "unbudgeted": [{"category_id": cid, "category_name": r["category_name"], "spent": float(r["spent"])}
                       for cid, r in spend.items() if cid not in budgeted_ids],
        "total_spent": float(total_spent),
        "effective_limit": float(effective) if effective else None,
        "remaining": float(effective - total_spent) if effective else None,
        "utilization_pct": line(effective, total_spent)["utilization_pct"] if effective else None,
    }


@router.get("")
def get_budgets(year: Year, month: Month, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Budgets for a month with actual spending, utilisation percentages and status."""
    with db.tx() as conn:
        return build_view(conn, user.user_id, year, month)


@router.put("")
def upsert_budget(body: BudgetIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Create or replace the overall limit or one category budget for a month."""
    with db.tx() as conn:
        conn.execute(
            "INSERT INTO budgets (user_id, year, month, category_id, category_name, limit_amount) "
            "VALUES (%s, %s, %s, %s, %s, %s) "
            f"ON CONFLICT (user_id, year, month, COALESCE(category_id, '{ZERO_UUID}'::uuid)) DO UPDATE SET "
            "limit_amount = EXCLUDED.limit_amount, category_name = EXCLUDED.category_name, updated_at = now()",
            (user.user_id, body.year, body.month, body.category_id, body.category_name, body.limit_amount))
        evaluate_alerts(conn, user.user_id, body.year, body.month)
        emit(conn, "budget.changed", user.user_id, {"year": body.year, "month": body.month})
        return build_view(conn, user.user_id, body.year, body.month)


@router.post("/copy")
def copy_budgets(body: CopyRequest, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Copy every budget of one month into another month (existing budgets are kept)."""
    with db.tx() as conn:
        cur = conn.execute(
            "INSERT INTO budgets (user_id, year, month, category_id, category_name, limit_amount) "
            "SELECT user_id, %s, %s, category_id, category_name, limit_amount FROM budgets "
            "WHERE user_id = %s AND year = %s AND month = %s ON CONFLICT DO NOTHING",
            (body.to_year, body.to_month, user.user_id, body.from_year, body.from_month))
        evaluate_alerts(conn, user.user_id, body.to_year, body.to_month)
        emit(conn, "budget.changed", user.user_id, {"year": body.to_year, "month": body.to_month})
        return {"copied": cur.rowcount}


@router.delete("/{budget_id}", status_code=204)
def delete_budget(budget_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        row = conn.execute("DELETE FROM budgets WHERE id = %s AND user_id = %s RETURNING year, month",
                           (budget_id, user.user_id)).fetchone()
        if not row:
            raise HTTPException(404, "Budget not found")
        emit(conn, "budget.changed", user.user_id, row)
