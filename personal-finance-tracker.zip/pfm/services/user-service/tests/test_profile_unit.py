import pytest
from pydantic import ValidationError

from app.routes import ProfileUpdate


def test_valid_preferences():
    p = ProfileUpdate(currency="USD", timezone="America/New_York", theme="dark")
    assert p.model_dump(exclude_none=True) == {"currency": "USD", "timezone": "America/New_York", "theme": "dark"}


@pytest.mark.parametrize("field,value", [("currency", "usd"), ("currency", "RUPEE"), ("timezone", "Mars/Olympus"),
                                         ("theme", "neon")])
def test_invalid_preferences(field, value):
    with pytest.raises(ValidationError):
        ProfileUpdate(**{field: value})
