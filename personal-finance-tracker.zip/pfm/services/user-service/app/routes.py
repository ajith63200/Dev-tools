from datetime import datetime
from typing import Literal
from uuid import UUID
from zoneinfo import available_timezones

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, field_validator

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database

router = APIRouter(prefix="/api/v1/users", tags=["users"])


class ProfileUpdate(BaseModel):
    full_name: str | None = Field(None, min_length=1, max_length=120)
    currency: str | None = Field(None, pattern=r"^[A-Z]{3}$", description="ISO 4217 code")
    timezone: str | None = None
    theme: Literal["light", "dark", "system"] | None = None
    week_start: Literal["monday", "sunday"] | None = None
    notify_budget_alerts: bool | None = None
    notify_monthly_report: bool | None = None

    @field_validator("timezone")
    @classmethod
    def known_timezone(cls, v):
        if v is not None and v not in available_timezones():
            raise ValueError("unknown IANA timezone")
        return v


class Profile(BaseModel):
    user_id: UUID
    email: str
    full_name: str
    currency: str
    timezone: str
    theme: str
    week_start: str
    notify_budget_alerts: bool
    notify_monthly_report: bool
    created_at: datetime
    updated_at: datetime


def ensure_profile(conn, user_id, email: str = "", full_name: str = "") -> dict:
    """Idempotent upsert: used by the API (lazy) and by the user.registered consumer."""
    conn.execute(
        "INSERT INTO profiles (user_id, email, full_name) VALUES (%s, %s, %s) "
        "ON CONFLICT (user_id) DO UPDATE SET "
        "email = CASE WHEN EXCLUDED.email <> '' THEN EXCLUDED.email ELSE profiles.email END, "
        "full_name = CASE WHEN profiles.full_name = '' THEN EXCLUDED.full_name ELSE profiles.full_name END",
        (user_id, email, full_name))
    return conn.execute("SELECT * FROM profiles WHERE user_id = %s", (user_id,)).fetchone()


@router.get("/me", response_model=Profile)
def get_profile(user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return ensure_profile(conn, user.user_id, user.email)


@router.put("/me", response_model=Profile)
def update_profile(body: ProfileUpdate, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    changes = body.model_dump(exclude_none=True)
    with db.tx() as conn:
        ensure_profile(conn, user.user_id, user.email)
        if changes:
            sets = ", ".join(f"{col} = %({col})s" for col in changes)  # column names come from the schema, not input
            conn.execute(f"UPDATE profiles SET {sets}, updated_at = now() WHERE user_id = %(uid)s",
                         {**changes, "uid": user.user_id})
        return conn.execute("SELECT * FROM profiles WHERE user_id = %s", (user.user_id,)).fetchone()
