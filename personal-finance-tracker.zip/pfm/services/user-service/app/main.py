from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings

from . import routes


class UserSettings(Settings):
    service_name: str = "user-service"


def on_user_registered(conn, event: dict) -> None:
    routes.ensure_profile(conn, event["user_id"], event["data"].get("email", ""), event["data"].get("full_name", ""))


def build(settings: Settings | None = None) -> FastAPI:
    return create_app(
        title="PFM User Service",
        description="User profiles and financial preferences (currency, timezone, theme).",
        settings=settings or UserSettings(),
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.router],
        subscriptions={"user.registered": on_user_registered},
    )


app = build()
