CREATE TABLE profiles (
    user_id    UUID PRIMARY KEY,              -- identity owned by auth-service (no cross-service FK)
    email      TEXT NOT NULL DEFAULT '',
    full_name  TEXT NOT NULL DEFAULT '',
    currency   CHAR(3) NOT NULL DEFAULT 'INR',
    timezone   TEXT NOT NULL DEFAULT 'Asia/Kolkata',
    theme      TEXT NOT NULL DEFAULT 'system' CHECK (theme IN ('light', 'dark', 'system')),
    week_start TEXT NOT NULL DEFAULT 'monday' CHECK (week_start IN ('monday', 'sunday')),
    notify_budget_alerts   BOOLEAN NOT NULL DEFAULT TRUE,
    notify_monthly_report  BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
