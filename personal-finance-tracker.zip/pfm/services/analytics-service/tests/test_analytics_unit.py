from datetime import date
from decimal import Decimal

from app.export import monthly_pdf, monthly_xlsx
from app.insights import build_insights
from app.reports import pct, shift_month


def report(**over):
    base = {"period_label": "May 2026", "total_income": 100000.0, "total_expenses": 60000.0, "total_savings": 40000.0,
            "savings_pct": 40.0, "highest_category": {"category": "Rent", "amount": 30000.0, "pct": 50.0, "count": 1},
            "lowest_category": {"category": "Travel", "amount": 500.0, "pct": 0.8, "count": 1},
            "average_daily_expenditure": 1935.48,
            "comparison": {k: {"current": 1.0, "previous": 1.0, "change": 0.0, "change_pct": 0.0}
                           for k in ("income", "expenses", "savings")},
            "budget": None, "categories": [{"category": "Rent", "amount": 30000.0, "pct": 50.0, "count": 1}],
            "income_sources": []}
    return {**base, **over}


def titles(r):
    return [i["title"] for i in build_insights(r)]


def test_shift_month_wraps_years():
    assert shift_month(2026, 1, -1) == (2025, 12) and shift_month(2026, 12, 1) == (2027, 1)
    assert shift_month(2026, 3, -11) == (2025, 4)


def test_pct_handles_zero_denominator():
    assert pct(Decimal("5"), Decimal("0")) == 0.0 and pct(Decimal("1"), Decimal("3")) == 33.3


def test_insights_for_healthy_month():
    t = titles(report())
    assert "Healthy savings rate" in t and "Rent dominates spending" in t and "No budget set" in t


def test_insights_for_overspending_and_budget_breach():
    r = report(total_expenses=120000.0, total_savings=-20000.0, savings_pct=-20.0,
               comparison={**report()["comparison"], "expenses": {"current": 120000.0, "previous": 60000.0,
                                                                   "change": 60000.0, "change_pct": 100.0}},
               budget={"limit": 100000.0, "spent": 120000.0, "remaining": -20000.0, "utilization_pct": 120.0,
                       "overall": None, "categories": [{"category_name": "Food", "limit_amount": 1.0, "spent": 2.0,
                                                        "remaining": -1.0, "utilization_pct": 200.0}]})
    t = titles(r)
    assert {"Spending exceeded income", "Expenses are rising", "Budget exceeded", "Category budgets exceeded"} <= set(t)


def test_insights_for_empty_month():
    assert titles(report(total_income=0.0, total_expenses=0.0, total_savings=0.0, savings_pct=0.0)) == ["No activity yet"]


def test_exports_render():
    r = report()
    r["insights"] = build_insights(r)
    rows = [{"txn_date": date(2026, 5, 2), "kind": "expense", "category_name": "Rent", "payment_method": "upi",
             "description": "May rent", "amount": Decimal("30000")}]
    assert monthly_pdf(r, rows, "INR", "a@example.com").startswith(b"%PDF")
    assert monthly_xlsx(r, rows, "INR").startswith(b"PK")
