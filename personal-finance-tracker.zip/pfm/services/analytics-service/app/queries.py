"""SQL over the analytics read model. Every query is scoped to one user."""
from datetime import date
from decimal import Decimal

SCOPE = "user_id = %s AND txn_date >= %s AND txn_date < %s"


def totals(conn, user_id, start: date, end: date) -> dict[str, Decimal]:
    out = {"income": Decimal(0), "expense": Decimal(0)}
    for row in conn.execute(f"SELECT kind, sum(amount) AS total FROM transactions WHERE {SCOPE} GROUP BY kind",
                            (user_id, start, end)):
        out[row["kind"]] = row["total"]
    return out


def monthly_series(conn, user_id, start: date, end: date) -> dict[tuple[int, int], dict[str, Decimal]]:
    out: dict = {}
    for row in conn.execute(
            "SELECT extract(year FROM txn_date)::int AS y, extract(month FROM txn_date)::int AS m, kind, "
            f"sum(amount) AS total FROM transactions WHERE {SCOPE} GROUP BY 1, 2, 3", (user_id, start, end)):
        out.setdefault((row["y"], row["m"]), {"income": Decimal(0), "expense": Decimal(0)})[row["kind"]] = row["total"]
    return out


def by_category(conn, user_id, start: date, end: date, kind: str = "expense") -> list[dict]:
    return conn.execute(
        f"SELECT category_name AS category, sum(amount) AS amount, count(*) AS count FROM transactions "
        f"WHERE {SCOPE} AND kind = %s GROUP BY category_name ORDER BY amount DESC, category_name",
        (user_id, start, end, kind)).fetchall()


def daily_expenses(conn, user_id, start: date, end: date) -> dict[date, Decimal]:
    return {r["txn_date"]: r["total"] for r in conn.execute(
        f"SELECT txn_date, sum(amount) AS total FROM transactions WHERE {SCOPE} AND kind = 'expense' "
        "GROUP BY txn_date", (user_id, start, end))}


def transactions(conn, user_id, start: date, end: date, limit: int = 5000) -> list[dict]:
    return conn.execute(
        f"SELECT id, kind, amount, txn_date, category_name, payment_method, description FROM transactions "
        f"WHERE {SCOPE} ORDER BY txn_date DESC, created_at DESC LIMIT %s", (user_id, start, end, limit)).fetchall()
