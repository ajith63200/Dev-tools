import logging
from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, Query, Request, Response

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database
from pfm_common.types import Month, Year, month_bounds

from . import export, queries, reports

router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])
log = logging.getLogger(__name__)


def fetch_budget(request: Request, user: Principal, year: int, month: int) -> dict | None:
    """Synchronous call to budget-service with the caller's token. Reports degrade gracefully without it."""
    app = request.app
    try:
        resp = app.state.http.get(f"{app.state.settings.budget_service_url}/api/v1/budgets",
                                  params={"year": year, "month": month},
                                  headers={"Authorization": f"Bearer {user.token}",
                                           "X-Request-ID": getattr(request.state, "request_id", "")})
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:
        log.warning("budget-service unavailable (%s); returning report without budget data", type(exc).__name__)
        return None


def _today():
    return datetime.now(timezone.utc).date()


@router.get("/dashboard")
def dashboard(request: Request, year: Year, month: Month, user: Principal = Depends(current_user),
              db: Database = Depends(get_db)):
    """Everything the landing dashboard needs for one month, in a single call."""
    cache, key = request.app.state.cache, f"dashboard:{year}-{month}"
    if (hit := cache.get(user.user_id, key)) is not None:
        return hit
    budget = fetch_budget(request, user, year, month)
    with db.tx() as conn:
        data = reports.dashboard(conn, user.user_id, year, month, budget)
    data["budget_available"] = budget is not None
    if budget is not None:
        cache.set(user.user_id, key, data)
    return data


@router.get("/reports/monthly")
def monthly(request: Request, year: Year, month: Month, user: Principal = Depends(current_user),
            db: Database = Depends(get_db)):
    """Automated monthly report: totals, extremes, daily average, month-over-month comparison and insights."""
    budget = fetch_budget(request, user, year, month)
    with db.tx() as conn:
        return reports.monthly_report(conn, user.user_id, year, month, budget, _today())


@router.get("/reports/monthly/export")
def monthly_export(request: Request, year: Year, month: Month, format: Literal["pdf", "xlsx"] = "pdf",
                   currency: str = Query("INR", pattern=r"^[A-Z]{3}$"), user: Principal = Depends(current_user),
                   db: Database = Depends(get_db)):
    """Download the monthly report as PDF or Excel."""
    budget = fetch_budget(request, user, year, month)
    with db.tx() as conn:
        report = reports.monthly_report(conn, user.user_id, year, month, budget, _today())
        rows = queries.transactions(conn, user.user_id, *month_bounds(year, month))
    name = f"financial-report-{year}-{month:02d}"
    if format == "pdf":
        content, media = export.monthly_pdf(report, rows, currency, user.email), "application/pdf"
    else:
        content = export.monthly_xlsx(report, rows, currency)
        media = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    return Response(content, media_type=media,
                    headers={"Content-Disposition": f'attachment; filename="{name}.{format}"'})


@router.get("/reports/quarterly")
def quarterly(year: Year, quarter: int = Query(ge=1, le=4), user: Principal = Depends(current_user),
              db: Database = Depends(get_db)):
    first = (quarter - 1) * 3 + 1
    with db.tx() as conn:
        return {"year": year, "quarter": quarter, **reports.period_report(
            conn, user.user_id, [(year, m) for m in range(first, first + 3)], f"Q{quarter} {year}")}


@router.get("/reports/yearly")
def yearly(year: Year, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return {"year": year, **reports.period_report(
            conn, user.user_id, [(year, m) for m in range(1, 13)], str(year))}


@router.get("/trends/spending")
def spending_trend(months: int = Query(6, ge=2, le=36), user: Principal = Depends(current_user),
                   db: Database = Depends(get_db)):
    """Income, expenses and savings for the trailing N months (ending with the current month)."""
    today = _today()
    window = [reports.shift_month(today.year, today.month, d) for d in range(-(months - 1), 1)]
    with db.tx() as conn:
        return {"months": reports._series(conn, user.user_id, window)}
