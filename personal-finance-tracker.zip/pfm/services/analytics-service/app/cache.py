"""Optional Redis cache. Every failure degrades to 'no cache' rather than an error."""
import json
import logging

log = logging.getLogger(__name__)


class Cache:
    def __init__(self, url: str, ttl: int = 30):
        self.ttl = ttl
        self.client = None
        if url:
            import redis
            self.client = redis.Redis.from_url(url, socket_timeout=0.5, socket_connect_timeout=0.5,
                                               decode_responses=True)

    def _key(self, user_id, name: str) -> str:
        version = self.client.get(f"analytics:ver:{user_id}") or "0"
        return f"analytics:{user_id}:{version}:{name}"

    def get(self, user_id, name: str):
        if not self.client:
            return None
        try:
            raw = self.client.get(self._key(user_id, name))
            return json.loads(raw) if raw else None
        except Exception:
            return None

    def set(self, user_id, name: str, value) -> None:
        if not self.client:
            return
        try:
            self.client.set(self._key(user_id, name), json.dumps(value, default=str), ex=self.ttl)
        except Exception:
            log.debug("cache write skipped")

    def invalidate(self, user_id) -> None:
        """Bump the user's version so every cached entry for them becomes unreachable."""
        if not self.client:
            return
        try:
            self.client.incr(f"analytics:ver:{user_id}")
        except Exception:
            log.debug("cache invalidation skipped")
