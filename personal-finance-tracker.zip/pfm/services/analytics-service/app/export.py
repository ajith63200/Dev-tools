"""Monthly report exports: PDF (ReportLab) and Excel (openpyxl)."""
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

INK, MUTED, RULE = colors.HexColor("#0f172a"), colors.HexColor("#64748b"), colors.HexColor("#e2e8f0")


def money(value: float | None, currency: str) -> str:
    return "-" if value is None else f"{currency} {value:,.2f}"


def _change(row: dict) -> str:
    return "n/a" if row["change_pct"] is None else f"{row['change_pct']:+.1f}%"


def _summary_rows(report: dict, currency: str) -> list[tuple[str, str]]:
    high, low, budget = report["highest_category"], report["lowest_category"], report["budget"]
    rows = [
        ("Total income", money(report["total_income"], currency)),
        ("Total expenses", money(report["total_expenses"], currency)),
        ("Total savings", money(report["total_savings"], currency)),
        ("Savings percentage", f"{report['savings_pct']:.1f}%"),
        ("Highest spending category", f"{high['category']} ({money(high['amount'], currency)})" if high else "-"),
        ("Lowest spending category", f"{low['category']} ({money(low['amount'], currency)})" if low else "-"),
        ("Average daily expenditure", money(report["average_daily_expenditure"], currency)),
        ("Income vs previous month", _change(report["comparison"]["income"])),
        ("Expenses vs previous month", _change(report["comparison"]["expenses"])),
        ("Savings vs previous month", _change(report["comparison"]["savings"])),
    ]
    if budget:
        rows += [("Monthly budget", money(budget["limit"], currency)),
                 ("Budget utilisation", f"{budget['utilization_pct']:.1f}%"),
                 ("Budget remaining", money(budget["remaining"], currency))]
    else:
        rows.append(("Monthly budget", "Not set"))
    return rows


def _table(data: list[list], widths: list[float], numeric_from: int = 1) -> Table:
    table = Table(data, colWidths=widths, repeatRows=1)
    table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (-1, 0), MUTED), ("TEXTCOLOR", (0, 1), (-1, -1), INK),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE), ("ALIGN", (numeric_from, 0), (-1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return table


def monthly_pdf(report: dict, transactions: list[dict], currency: str, owner: str) -> bytes:
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Title"], alignment=0, fontSize=20, textColor=INK, spaceAfter=2)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontSize=12, textColor=INK, spaceBefore=14, spaceAfter=6)
    body = ParagraphStyle("body", parent=styles["BodyText"], fontSize=9.5, leading=13, textColor=INK)
    muted = ParagraphStyle("muted", parent=body, textColor=MUTED)
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm,
                            bottomMargin=16 * mm, title=f"Financial report - {report['period_label']}")
    story = [Paragraph("Monthly financial report", h1),
             Paragraph(f"{report['period_label']} &nbsp;|&nbsp; {owner}", muted), Spacer(1, 8),
             Paragraph("Summary", h2),
             _table([["Metric", "Value"]] + [list(r) for r in _summary_rows(report, currency)], [90 * mm, 84 * mm])]
    if report["categories"]:
        story += [Paragraph("Spending by category", h2), _table(
            [["Category", "Transactions", "Amount", "Share"]] +
            [[c["category"], c["count"], money(c["amount"], currency), f"{c['pct']:.1f}%"] for c in report["categories"]],
            [74 * mm, 30 * mm, 45 * mm, 25 * mm])]
    if report["budget"] and report["budget"]["categories"]:
        story += [Paragraph("Budget vs actual", h2), _table(
            [["Category", "Budget", "Spent", "Used"]] +
            [[c["category_name"], money(c["limit_amount"], currency), money(c["spent"], currency),
              f"{c['utilization_pct']:.1f}%"] for c in report["budget"]["categories"]],
            [74 * mm, 40 * mm, 40 * mm, 20 * mm])]
    story.append(Paragraph("Insights and recommendations", h2))
    story += [Paragraph(f"<b>{i['title']}.</b> {i['message']}", body) for i in report["insights"]]
    if transactions:
        story += [Paragraph(f"Transactions ({len(transactions)})", h2), _table(
            [["Date", "Type", "Category / source", "Description", "Amount"]] +
            [[t["txn_date"].isoformat(), t["kind"].title(), t["category_name"], (t["description"] or "")[:34],
              money(float(t["amount"]), currency)] for t in transactions],
            [22 * mm, 18 * mm, 44 * mm, 54 * mm, 36 * mm], numeric_from=4)]
    doc.build(story)
    return buf.getvalue()


def monthly_xlsx(report: dict, transactions: list[dict], currency: str) -> bytes:
    wb = Workbook()
    head_font, head_fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="0F172A")
    number = "#,##0.00"

    def sheet(title: str, headers: list[str], rows: list[list], widths: list[int], money_cols: tuple = ()):
        ws = wb.create_sheet(title)
        ws.append(headers)
        for cell in ws[1]:
            cell.font, cell.fill, cell.alignment = head_font, head_fill, Alignment(vertical="center")
        for row in rows:
            ws.append(row)
        for i, width in enumerate(widths):
            ws.column_dimensions[chr(65 + i)].width = width
        for col in money_cols:
            for cell in ws[chr(65 + col)][1:]:
                cell.number_format = number
        ws.freeze_panes = "A2"
        return ws

    wb.remove(wb.active)
    high, low, budget = report["highest_category"], report["lowest_category"], report["budget"]
    cmp = report["comparison"]
    summary = [
        ["Period", report["period_label"]], ["Currency", currency],
        ["Total income", report["total_income"]], ["Total expenses", report["total_expenses"]],
        ["Total savings", report["total_savings"]], ["Savings percentage", report["savings_pct"] / 100],
        ["Highest spending category", high["category"] if high else "-"],
        ["Lowest spending category", low["category"] if low else "-"],
        ["Average daily expenditure", report["average_daily_expenditure"]],
        ["Previous month income", cmp["income"]["previous"]],
        ["Previous month expenses", cmp["expenses"]["previous"]],
        ["Previous month savings", cmp["savings"]["previous"]],
        ["Monthly budget", budget["limit"] if budget else "Not set"],
        ["Budget utilisation", budget["utilization_pct"] / 100 if budget else "-"],
    ]
    ws = sheet("Summary", ["Metric", "Value"], summary, [32, 26])
    for cell in ws["B"][1:]:
        if isinstance(cell.value, float):
            cell.number_format = "0.0%" if "percentage" in ws[f"A{cell.row}"].value.lower() \
                or "utilisation" in ws[f"A{cell.row}"].value.lower() else number
    sheet("Categories", ["Category", "Transactions", "Amount", "Share"],
          [[c["category"], c["count"], c["amount"], c["pct"] / 100] for c in report["categories"]],
          [30, 14, 16, 10], money_cols=(2,))
    for cell in wb["Categories"]["D"][1:]:
        cell.number_format = "0.0%"
    if budget:
        sheet("Budget", ["Category", "Budget", "Spent", "Remaining", "Used %"],
              [[c["category_name"], c["limit_amount"], c["spent"], c["remaining"], c["utilization_pct"]]
               for c in budget["categories"]], [30, 16, 16, 16, 10], money_cols=(1, 2, 3))
    sheet("Insights", ["Type", "Insight", "Recommendation"],
          [[i["type"], i["title"], i["message"]] for i in report["insights"]], [12, 34, 100])
    sheet("Transactions", ["Date", "Type", "Category / source", "Payment method", "Description", "Amount"],
          [[t["txn_date"], t["kind"], t["category_name"], t["payment_method"] or "", t["description"],
            float(t["amount"])] for t in transactions], [12, 10, 28, 16, 44, 16], money_cols=(5,))
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
