"""Rule-based financial insights. Pure function of a report: deterministic and unit-testable."""


def build_insights(report: dict) -> list[dict]:
    out: list[dict] = []

    def add(kind: str, title: str, message: str) -> None:
        out.append({"type": kind, "title": title, "message": message})

    income, expenses, savings = report["total_income"], report["total_expenses"], report["total_savings"]
    rate = report["savings_pct"]
    if income == 0 and expenses == 0:
        add("info", "No activity yet", "Add income and expense transactions to unlock insights for this period.")
        return out
    if income == 0:
        add("warning", "No income recorded", "Expenses were recorded without any income. Add your income so the "
            "savings rate reflects reality.")
    elif savings < 0:
        add("warning", "Spending exceeded income", f"You spent {abs(rate):.0f}% more than you earned. Review the "
            "largest categories below and postpone discretionary purchases.")
    elif rate < 10:
        add("warning", "Low savings rate", f"Only {rate:.0f}% of income was saved. A common target is 20%; "
            "automating a transfer on payday helps.")
    elif rate < 20:
        add("info", "Savings rate is close to target", f"You saved {rate:.0f}% of income. Trimming one "
            "discretionary category would take you past the 20% mark.")
    else:
        add("positive", "Healthy savings rate", f"You saved {rate:.0f}% of income, above the 20% guideline.")

    top = report.get("highest_category")
    if top and expenses > 0 and top["pct"] >= 40:
        add("info", f"{top['category']} dominates spending",
            f"{top['category']} accounts for {top['pct']:.0f}% of expenses. If it is not a fixed cost, "
            "set a category budget for it.")

    change = report.get("comparison", {}).get("expenses", {}).get("change_pct")
    if change is not None:
        if change >= 10:
            add("warning", "Expenses are rising", f"Spending is up {change:.0f}% on the previous month.")
        elif change <= -10:
            add("positive", "Expenses are falling", f"Spending is down {abs(change):.0f}% on the previous month.")

    budget = report.get("budget")
    if budget and budget.get("utilization_pct") is not None:
        used = budget["utilization_pct"]
        if used >= 100:
            add("warning", "Budget exceeded", f"{used:.0f}% of the monthly budget has been used.")
        elif used >= 80:
            add("warning", "Budget nearly used", f"{used:.0f}% of the monthly budget has been used.")
        else:
            add("positive", "Within budget", f"{used:.0f}% of the monthly budget has been used.")
        over = [c["category_name"] for c in budget.get("categories", []) if c["utilization_pct"] >= 100]
        if over:
            add("warning", "Category budgets exceeded", "Over budget in: " + ", ".join(over) + ".")
    elif budget is None and expenses > 0:
        add("info", "No budget set", "Set a monthly budget to get alerts at 80%, 90% and 100% of your limit.")
    return out
