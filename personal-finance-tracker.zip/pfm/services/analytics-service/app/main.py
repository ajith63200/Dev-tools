from datetime import datetime, timezone
from pathlib import Path

import httpx
from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings
from pfm_common.events import emit
from pfm_common.types import month_bounds

from . import queries, reports, routes
from .cache import Cache


class AnalyticsSettings(Settings):
    service_name: str = "analytics-service"
    budget_service_url: str = "http://budget-service:8000"
    cache_ttl_seconds: int = 30
    report_job_interval_seconds: int = 300


def announce_monthly_reports(app: FastAPI) -> None:
    """Once per user and month: tell the platform that last month's report is ready."""
    today = datetime.now(timezone.utc).date()
    year, month = reports.shift_month(today.year, today.month, -1)
    start, end = month_bounds(year, month)
    with app.state.db.tx() as conn:
        users = conn.execute(
            "INSERT INTO report_notices (user_id, year, month) SELECT DISTINCT user_id, %s::int, %s::int "
            "FROM transactions WHERE txn_date >= %s AND txn_date < %s ON CONFLICT DO NOTHING RETURNING user_id",
            (year, month, start, end)).fetchall()
        for row in users:
            t = queries.totals(conn, row["user_id"], start, end)
            emit(conn, "report.monthly_ready", row["user_id"], {
                "year": year, "month": month, "total_income": t["income"], "total_expenses": t["expense"],
                "total_savings": t["income"] - t["expense"]})


def build(settings: Settings | None = None) -> FastAPI:
    settings = settings or AnalyticsSettings()
    cache = Cache(settings.redis_url, settings.cache_ttl_seconds)

    def on_transaction(conn, event: dict) -> None:
        kind = event["type"].split(".")[0]
        after = event["data"].get("after")
        if after is None:
            conn.execute("DELETE FROM transactions WHERE id = %s", (event["data"]["before"]["id"],))
        else:
            conn.execute(
                "INSERT INTO transactions (id, user_id, kind, amount, txn_date, category_id, category_name, "
                "payment_method, description) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
                "ON CONFLICT (id) DO UPDATE SET amount = EXCLUDED.amount, txn_date = EXCLUDED.txn_date, "
                "category_id = EXCLUDED.category_id, category_name = EXCLUDED.category_name, "
                "payment_method = EXCLUDED.payment_method, description = EXCLUDED.description, updated_at = now()",
                (after["id"], event["user_id"], kind, after["amount"], after["date"], after["category_id"],
                 after["category_name"], after["payment_method"], after.get("description", "")))
        cache.invalidate(event["user_id"])

    def on_budget(conn, event: dict) -> None:
        cache.invalidate(event["user_id"])

    def startup(app: FastAPI) -> None:
        app.state.cache = cache
        app.state.http = httpx.Client(timeout=3.0)

    return create_app(
        title="PFM Analytics and Reporting Service",
        description="Dashboard aggregates, trends, monthly/quarterly/yearly reports and PDF/Excel exports.",
        settings=settings,
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.router],
        subscriptions={"income.*": on_transaction, "expense.*": on_transaction, "budget.*": on_budget},
        jobs=[("monthly-report-announcer", settings.report_job_interval_seconds, announce_monthly_reports)],
        on_startup=startup,
    )


app = build()
