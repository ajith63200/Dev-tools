"""Dashboard and report assembly. All figures are computed from stored transactions."""
import calendar
from datetime import date, timedelta
from decimal import Decimal

from pfm_common.types import month_bounds

from . import queries
from .insights import build_insights


def shift_month(year: int, month: int, delta: int) -> tuple[int, int]:
    index = year * 12 + (month - 1) + delta
    return index // 12, index % 12 + 1


def pct(part: Decimal, whole: Decimal) -> float:
    return round(float(part / whole * 100), 1) if whole else 0.0


def _categories(rows: list[dict]) -> list[dict]:
    total = sum((r["amount"] for r in rows), Decimal(0))
    return [{"category": r["category"], "amount": float(r["amount"]), "count": r["count"],
             "pct": pct(r["amount"], total)} for r in rows]


def _series(conn, user_id, months: list[tuple[int, int]]) -> list[dict]:
    start = date(months[0][0], months[0][1], 1)
    end = month_bounds(*months[-1])[1]
    data = queries.monthly_series(conn, user_id, start, end)
    out = []
    for y, m in months:
        row = data.get((y, m), {"income": Decimal(0), "expense": Decimal(0)})
        out.append({"year": y, "month": m, "label": f"{calendar.month_abbr[m]} {y % 100:02d}",
                    "income": float(row["income"]), "expenses": float(row["expense"]),
                    "savings": float(row["income"] - row["expense"]),
                    "savings_pct": pct(row["income"] - row["expense"], row["income"])})
    return out


def _budget_section(budget: dict | None) -> dict | None:
    if not budget or budget.get("effective_limit") is None:
        return None
    return {"limit": budget["effective_limit"], "spent": budget["total_spent"], "remaining": budget["remaining"],
            "utilization_pct": budget["utilization_pct"], "overall": budget["overall"],
            "categories": budget["categories"]}


def dashboard(conn, user_id, year: int, month: int, budget: dict | None) -> dict:
    start, end = month_bounds(year, month)
    t = queries.totals(conn, user_id, start, end)
    savings = t["income"] - t["expense"]
    categories = _categories(queries.by_category(conn, user_id, start, end))
    daily = queries.daily_expenses(conn, user_id, start, end)
    days = [start + timedelta(days=i) for i in range((end - start).days)]
    section = _budget_section(budget)
    return {
        "year": year, "month": month,
        "summary": {"total_income": float(t["income"]), "total_expenses": float(t["expense"]),
                    "total_savings": float(savings), "savings_pct": pct(savings, t["income"]),
                    "budget_limit": section["limit"] if section else None,
                    "budget_remaining": section["remaining"] if section else None,
                    "budget_utilization_pct": section["utilization_pct"] if section else None},
        "income_vs_expense": _series(conn, user_id, [shift_month(year, month, d) for d in range(-11, 1)]),
        "category_breakdown": categories,
        "top_categories": categories[:5],
        "daily_spending": [{"date": d.isoformat(), "day": d.day, "amount": float(daily.get(d, 0))} for d in days],
        "budget": section,
        "recent_transactions": [{**r, "amount": float(r["amount"])}
                                for r in queries.transactions(conn, user_id, start, end, limit=8)],
    }


def _compare(current: Decimal, previous: Decimal) -> dict:
    return {"current": float(current), "previous": float(previous), "change": float(current - previous),
            "change_pct": pct(current - previous, abs(previous)) if previous else None}


def monthly_report(conn, user_id, year: int, month: int, budget: dict | None, today: date) -> dict:
    start, end = month_bounds(year, month)
    prev_start, prev_end = month_bounds(*shift_month(year, month, -1))
    cur, prev = queries.totals(conn, user_id, start, end), queries.totals(conn, user_id, prev_start, prev_end)
    savings, prev_savings = cur["income"] - cur["expense"], prev["income"] - prev["expense"]
    categories = _categories(queries.by_category(conn, user_id, start, end))
    # Average over elapsed days for the month in progress, over the whole month otherwise.
    days = (today - start).days + 1 if start <= today < end else (end - start).days
    report = {
        "year": year, "month": month, "period_label": f"{calendar.month_name[month]} {year}",
        "total_income": float(cur["income"]), "total_expenses": float(cur["expense"]),
        "total_savings": float(savings), "savings_pct": pct(savings, cur["income"]),
        "highest_category": categories[0] if categories else None,
        "lowest_category": categories[-1] if categories else None,
        "average_daily_expenditure": round(float(cur["expense"]) / days, 2) if days > 0 else 0.0,
        "days_counted": days,
        "comparison": {"income": _compare(cur["income"], prev["income"]),
                       "expenses": _compare(cur["expense"], prev["expense"]),
                       "savings": _compare(savings, prev_savings)},
        "budget": _budget_section(budget),
        "categories": categories,
        "income_sources": _categories(queries.by_category(conn, user_id, start, end, kind="income")),
    }
    report["insights"] = build_insights(report)
    return report


def period_report(conn, user_id, months: list[tuple[int, int]], label: str) -> dict:
    """Quarterly / yearly report across consecutive months."""
    start, end = date(months[0][0], months[0][1], 1), month_bounds(*months[-1])[1]
    series = _series(conn, user_id, months)
    t = queries.totals(conn, user_id, start, end)
    savings = t["income"] - t["expense"]
    active = [m for m in series if m["income"] or m["expenses"]]
    categories = _categories(queries.by_category(conn, user_id, start, end))
    report = {
        "period_label": label, "months": series,
        "total_income": float(t["income"]), "total_expenses": float(t["expense"]),
        "total_savings": float(savings), "savings_pct": pct(savings, t["income"]),
        "average_monthly_expenses": round(float(t["expense"]) / len(active), 2) if active else 0.0,
        "best_savings_month": max(active, key=lambda m: m["savings"])["label"] if active else None,
        "highest_expense_month": max(active, key=lambda m: m["expenses"])["label"] if active else None,
        "highest_category": categories[0] if categories else None,
        "lowest_category": categories[-1] if categories else None,
        "categories": categories,
        "income_sources": _categories(queries.by_category(conn, user_id, start, end, kind="income")),
    }
    report["insights"] = build_insights(report)
    return report
