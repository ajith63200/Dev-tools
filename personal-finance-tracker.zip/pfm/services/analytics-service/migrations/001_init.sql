-- Read model (CQRS): a denormalised copy of every transaction, built from income.* / expense.* events.
-- analytics-service never reads the income or expense databases.
CREATE TABLE transactions (
    id             UUID PRIMARY KEY,           -- id assigned by the owning service
    user_id        UUID NOT NULL,
    kind           TEXT NOT NULL CHECK (kind IN ('income', 'expense')),
    amount         NUMERIC(14, 2) NOT NULL,
    txn_date       DATE NOT NULL,
    category_id    UUID,
    category_name  TEXT NOT NULL,              -- expense category or income source
    payment_method TEXT,
    description    TEXT NOT NULL DEFAULT '',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_transactions_user_kind_date ON transactions (user_id, kind, txn_date);
CREATE INDEX idx_transactions_user_date ON transactions (user_id, txn_date DESC);

-- Months for which the "monthly report ready" event has been announced.
CREATE TABLE report_notices (
    user_id    UUID NOT NULL,
    year       INT NOT NULL,
    month      INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, year, month)
);
