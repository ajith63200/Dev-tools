import json
import logging
from datetime import date

import pytest
from fastapi import HTTPException

from pfm_common.auth import create_token, decode_token
from pfm_common.config import Settings
from pfm_common.events import MemoryBus
from pfm_common.logging import JsonFormatter
from pfm_common.types import month_bounds

SETTINGS = Settings(jwt_secret="unit-test-secret-0123456789abcdef0")
USER = dict(user_id="5b1c7c0e-4a2d-4f0b-9d59-0d6c1f0a9a11", email="a@example.com", role="user")


def test_token_roundtrip_and_type_enforcement():
    access = create_token(SETTINGS, kind="access", **USER)
    assert decode_token(SETTINGS, access)["sub"] == USER["user_id"]
    with pytest.raises(HTTPException) as exc:
        decode_token(SETTINGS, create_token(SETTINGS, kind="refresh", **USER))
    assert exc.value.status_code == 401


def test_token_signed_with_another_secret_is_rejected():
    forged = create_token(Settings(jwt_secret="another-secret-0123456789abcdef012"), kind="access", **USER)
    with pytest.raises(HTTPException):
        decode_token(SETTINGS, forged)


def test_expired_token_is_rejected():
    expired = create_token(Settings(jwt_secret=SETTINGS.jwt_secret, access_token_ttl_minutes=-1), kind="access", **USER)
    with pytest.raises(HTTPException):
        decode_token(SETTINGS, expired)


def test_production_requires_strong_secret():
    with pytest.raises(RuntimeError):
        Settings(environment="production").validate_for_runtime()
    Settings(environment="production", jwt_secret="x" * 40).validate_for_runtime()


def test_month_bounds_handles_december():
    assert month_bounds(2026, 12) == (date(2026, 12, 1), date(2027, 1, 1))
    assert month_bounds(2026, 2) == (date(2026, 2, 1), date(2026, 3, 1))


def test_memory_bus_topic_matching():
    bus, seen = MemoryBus(SETTINGS), []
    bus.subscribe("q", ["expense.*"], seen.append)
    bus.publish("expense.created", {"id": 1})
    bus.publish("income.created", {"id": 2})
    bus.stop()
    bus.publish("expense.deleted", {"id": 3})
    assert seen == [{"id": 1}]


def test_log_formatter_masks_sensitive_fields():
    record = logging.LogRecord("t", logging.INFO, "", 0, "hello", (), None)
    record.amount, record.password, record.route = 1234.5, "hunter2", "/x"
    out = json.loads(JsonFormatter("svc").format(record))
    assert out["amount"] == "***" and out["password"] == "***" and out["route"] == "/x"
