"""JWT helpers and FastAPI dependencies.

The gateway validates tokens at the edge; every service validates them again
(defence in depth) and scopes each query to the token's subject.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from uuid import UUID

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .config import Settings

_bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    user_id: UUID
    email: str
    role: str
    token: str


def create_token(settings: Settings, *, user_id: str, email: str, role: str, kind: str) -> str:
    ttl = (timedelta(minutes=settings.access_token_ttl_minutes) if kind == "access"
           else timedelta(days=settings.refresh_token_ttl_days))
    now = datetime.now(timezone.utc)
    claims = {"sub": str(user_id), "email": email, "role": role, "type": kind,
              "iat": now, "exp": now + ttl, "iss": "pfm-auth"}
    return jwt.encode(claims, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_token(settings: Settings, token: str, kind: str = "access") -> dict:
    unauthorized = HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token",
                                 headers={"WWW-Authenticate": "Bearer"})
    try:
        claims = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm],
                            issuer="pfm-auth", options={"require": ["exp", "sub", "type"]})
    except jwt.PyJWTError:
        raise unauthorized from None
    if claims.get("type") != kind:
        raise unauthorized
    return claims


def current_user(request: Request,
                 cred: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> Principal:
    if cred is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated",
                            headers={"WWW-Authenticate": "Bearer"})
    claims = decode_token(request.app.state.settings, cred.credentials)
    principal = Principal(UUID(claims["sub"]), claims.get("email", ""), claims.get("role", "user"),
                          cred.credentials)
    request.state.user_id = str(principal.user_id)
    return principal


def require_role(*roles: str):
    def checker(user: Principal = Depends(current_user)) -> Principal:
        if user.role not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient permissions")
        return user
    return checker
