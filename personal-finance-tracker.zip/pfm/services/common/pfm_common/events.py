"""Event-driven plumbing.

* `emit()` writes an event to the service's outbox table inside the caller's
  transaction, so a state change and its event commit atomically.
* `OutboxRelay` publishes outbox rows to the bus (at-least-once).
* `idempotent()` wraps consumers so redelivered events are applied once.
* Two bus drivers: RabbitMQ (topic exchange + per-service durable queue with a
  dead-letter queue) and an in-memory bus used by tests.
"""
import fnmatch
import json
import logging
import threading
from collections.abc import Callable
from datetime import datetime, timezone
from uuid import uuid4

import psycopg
from fastapi.encoders import jsonable_encoder
from psycopg.types.json import Jsonb

from .config import Settings
from .db import Database

log = logging.getLogger(__name__)
Handler = Callable[[psycopg.Connection, dict], None]


def emit(conn: psycopg.Connection, event_type: str, user_id, data: dict) -> dict:
    event = {"id": str(uuid4()), "type": event_type, "user_id": str(user_id),
             "occurred_at": datetime.now(timezone.utc).isoformat(), "data": jsonable_encoder(data)}
    conn.execute("INSERT INTO outbox (event_id, routing_key, payload) VALUES (%s, %s, %s)",
                 (event["id"], event_type, Jsonb(event)))
    return event


def idempotent(db: Database, handlers: dict[str, Handler]) -> Callable[[dict], None]:
    """Dispatch an event to the first matching handler exactly once per event id."""
    def handle(event: dict) -> None:
        fn = next((h for pattern, h in handlers.items() if fnmatch.fnmatch(event["type"], pattern)), None)
        if fn is None:
            return
        with db.tx() as conn:
            cur = conn.execute("INSERT INTO processed_events (event_id) VALUES (%s) ON CONFLICT DO NOTHING",
                               (event["id"],))
            if cur.rowcount:
                fn(conn, event)
    return handle


# --------------------------------------------------------------------------- bus drivers
class MemoryBus:
    """In-process bus shared by every app in the interpreter (tests, single-process demos)."""
    _subscribers: list[tuple[list[str], Callable[[dict], None]]] = []

    def __init__(self, settings: Settings):
        self._mine: list = []

    def publish(self, routing_key: str, payload: dict) -> None:
        for patterns, handler in list(MemoryBus._subscribers):
            if any(fnmatch.fnmatch(routing_key, p) for p in patterns):
                try:
                    handler(payload)
                except Exception:
                    log.exception("in-memory event handler failed")

    def subscribe(self, queue: str, patterns: list[str], handler: Callable[[dict], None]) -> None:
        entry = (patterns, handler)
        self._mine.append(entry)
        MemoryBus._subscribers.append(entry)

    def start(self) -> None: ...

    def stop(self) -> None:
        for entry in self._mine:
            if entry in MemoryBus._subscribers:
                MemoryBus._subscribers.remove(entry)


class AmqpBus:
    """RabbitMQ driver. One connection for publishing, one consumer thread per service."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.exchange = settings.events_exchange
        self._pub_conn = None
        self._pub_ch = None
        self._subscription = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def _connect(self):
        import pika
        params = pika.URLParameters(self.settings.rabbitmq_url)
        params.heartbeat = 30
        params.blocked_connection_timeout = 30
        conn = pika.BlockingConnection(params)
        ch = conn.channel()
        ch.exchange_declare(self.exchange, exchange_type="topic", durable=True)
        return conn, ch

    def publish(self, routing_key: str, payload: dict) -> None:
        import pika
        try:
            if self._pub_conn is None or self._pub_conn.is_closed:
                self._pub_conn, self._pub_ch = self._connect()
                self._pub_ch.confirm_delivery()
            self._pub_ch.basic_publish(
                self.exchange, routing_key, json.dumps(payload).encode(),
                pika.BasicProperties(content_type="application/json", delivery_mode=2,
                                     message_id=payload.get("id")))
        except Exception:
            self._pub_conn = None
            raise

    def subscribe(self, queue: str, patterns: list[str], handler: Callable[[dict], None]) -> None:
        self._subscription = (queue, patterns, handler)

    def start(self) -> None:
        if self._subscription:
            self._thread = threading.Thread(target=self._consume_forever, name="amqp-consumer", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        try:
            if self._pub_conn and self._pub_conn.is_open:
                self._pub_conn.close()
        except Exception:
            pass

    def _consume_forever(self) -> None:
        queue, patterns, handler = self._subscription
        dlx, dlq = f"{self.exchange}.dlx", f"{queue}.dlq"
        while not self._stop.is_set():
            try:
                conn, ch = self._connect()
                ch.exchange_declare(dlx, exchange_type="direct", durable=True)
                ch.queue_declare(dlq, durable=True)
                ch.queue_bind(dlq, dlx, routing_key=queue)
                ch.queue_declare(queue, durable=True, arguments={
                    "x-dead-letter-exchange": dlx, "x-dead-letter-routing-key": queue})
                for pattern in patterns:
                    ch.queue_bind(queue, self.exchange, routing_key=pattern)
                ch.basic_qos(prefetch_count=20)
                log.info("consuming from %s", queue)
                for method, _props, body in ch.consume(queue, inactivity_timeout=1):
                    if self._stop.is_set():
                        break
                    if method is None:
                        continue
                    try:
                        handler(json.loads(body))
                        ch.basic_ack(method.delivery_tag)
                    except Exception:
                        log.exception("event handler failed; dead-lettering", extra={"routing_key": method.routing_key})
                        ch.basic_nack(method.delivery_tag, requeue=False)
                conn.close()
            except Exception as exc:
                if not self._stop.is_set():
                    log.warning("event bus unavailable (%s); retrying in 3s", type(exc).__name__)
                    self._stop.wait(3)


def make_bus(settings: Settings):
    return MemoryBus(settings) if settings.event_bus == "memory" else AmqpBus(settings)


# --------------------------------------------------------------------------- outbox relay
class OutboxRelay:
    def __init__(self, db: Database, bus, interval: float = 0.5):
        self.db, self.bus, self.interval = db, bus, interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def flush(self, batch: int = 200) -> int:
        """Publish pending events in commit order; rows stay pending if the bus is down."""
        error: Exception | None = None
        with self.db.tx() as conn:
            rows = conn.execute(
                "SELECT id, routing_key, payload FROM outbox WHERE published_at IS NULL "
                "ORDER BY id LIMIT %s FOR UPDATE SKIP LOCKED", (batch,)).fetchall()
            sent = []
            for row in rows:
                try:
                    self.bus.publish(row["routing_key"], row["payload"])
                except Exception as exc:  # keep order: stop at the first failure
                    error = exc
                    break
                sent.append(row["id"])
            if sent:
                conn.execute("UPDATE outbox SET published_at = now() WHERE id = ANY(%s)", (sent,))
        if error:
            raise error
        return len(sent)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                if self.flush() == 0:
                    self._stop.wait(self.interval)
            except Exception as exc:
                log.warning("outbox relay failed (%s); will retry", type(exc).__name__)
                self._stop.wait(3)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, name="outbox-relay", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)


def run_periodically(name: str, interval: float, fn: Callable[[], None], stop: threading.Event) -> threading.Thread:
    def loop():
        while not stop.is_set():
            try:
                fn()
            except Exception:
                log.exception("background job %s failed", name)
            stop.wait(interval)
    thread = threading.Thread(target=loop, name=name, daemon=True)
    thread.start()
    return thread
