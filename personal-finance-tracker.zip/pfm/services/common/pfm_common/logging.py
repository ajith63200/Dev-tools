"""Structured JSON logging to stdout.

Policy: request/response bodies and monetary values are never logged. The
formatter additionally masks well-known sensitive keys if they appear in
`extra` fields, as a safety net.
"""
import json
import logging
import sys
from datetime import datetime, timezone

SENSITIVE = {"password", "password_hash", "token", "access_token", "refresh_token",
             "authorization", "amount", "limit_amount", "target_amount", "jwt_secret"}
_RESERVED = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime"}


class JsonFormatter(logging.Formatter):
    def __init__(self, service: str):
        super().__init__()
        self.service = service

    def format(self, record: logging.LogRecord) -> str:
        out = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "service": self.service,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key not in _RESERVED:
                out[key] = "***" if key.lower() in SENSITIVE else value
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        return json.dumps(out, default=str)


def setup_logging(service: str, level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter(service))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
    for noisy in ("uvicorn.access", "pika", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
