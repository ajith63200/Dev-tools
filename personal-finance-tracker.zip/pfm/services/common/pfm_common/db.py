"""PostgreSQL access: a connection pool, a transaction helper and a tiny SQL migration runner."""
import logging
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

log = logging.getLogger(__name__)

# Tables every service owns for reliable messaging (transactional outbox + idempotent consumer).
BOOTSTRAP_SQL = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version    TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS outbox (
    id           BIGSERIAL PRIMARY KEY,
    event_id     UUID NOT NULL UNIQUE,
    routing_key  TEXT NOT NULL,
    payload      JSONB NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    published_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_outbox_unpublished ON outbox (id) WHERE published_at IS NULL;
CREATE TABLE IF NOT EXISTS processed_events (
    event_id     UUID PRIMARY KEY,
    processed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""


class Database:
    def __init__(self, url: str, max_size: int = 10):
        self.pool = ConnectionPool(url, min_size=1, max_size=max_size, open=False,
                                   kwargs={"row_factory": dict_row})

    def open(self) -> None:
        self.pool.open(wait=True, timeout=60)

    def close(self) -> None:
        self.pool.close()

    @contextmanager
    def tx(self) -> Iterator[psycopg.Connection]:
        """One transaction: commits on success, rolls back on any exception."""
        with self.pool.connection() as conn:
            yield conn

    def ping(self) -> bool:
        try:
            with self.tx() as conn:
                conn.execute("SELECT 1")
            return True
        except Exception:
            return False

    def migrate(self, migrations_dir: Path | None) -> None:
        """Apply pending `NNN_name.sql` files in order. Safe with concurrent replicas."""
        with self.tx() as conn:
            conn.execute("SELECT pg_advisory_xact_lock(727274)")
            conn.execute(BOOTSTRAP_SQL)
            applied = {r["version"] for r in conn.execute("SELECT version FROM schema_migrations")}
            files = sorted(migrations_dir.glob("*.sql")) if migrations_dir else []
            for path in files:
                if path.stem in applied:
                    continue
                log.info("applying migration %s", path.stem)
                conn.execute(path.read_text())
                conn.execute("INSERT INTO schema_migrations (version) VALUES (%s)", (path.stem,))
