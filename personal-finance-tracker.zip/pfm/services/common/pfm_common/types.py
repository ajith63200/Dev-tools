"""Shared API types."""
from datetime import date
from decimal import Decimal
from typing import Annotated

from pydantic import Field, PlainSerializer

# Stored as NUMERIC(14,2); serialised to JSON numbers for chart-friendly clients.
Money = Annotated[Decimal, PlainSerializer(float, return_type=float, when_used="json")]
PositiveMoney = Annotated[Decimal, Field(gt=0, max_digits=14, decimal_places=2),
                          PlainSerializer(float, return_type=float, when_used="json")]
Year = Annotated[int, Field(ge=2000, le=2100)]
Month = Annotated[int, Field(ge=1, le=12)]


def month_bounds(year: int, month: int) -> tuple[date, date]:
    """[first day, first day of next month)."""
    return date(year, month, 1), (date(year + 1, 1, 1) if month == 12 else date(year, month + 1, 1))
