"""Environment-driven configuration (12-factor). No file or cloud SDK lookups."""
from pydantic_settings import BaseSettings, SettingsConfigDict

INSECURE_SECRET = "change-me-in-production"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")

    service_name: str = "service"
    environment: str = "development"
    log_level: str = "INFO"

    database_url: str = ""
    db_pool_max: int = 10

    event_bus: str = "amqp"  # amqp | memory
    rabbitmq_url: str = "amqp://guest:guest@rabbitmq:5672/"
    events_exchange: str = "pfm.events"

    redis_url: str = ""

    jwt_secret: str = INSECURE_SECRET
    jwt_algorithm: str = "HS256"
    access_token_ttl_minutes: int = 30
    refresh_token_ttl_days: int = 7

    cors_origins: str = ""

    def validate_for_runtime(self) -> None:
        if self.environment == "production" and (
            self.jwt_secret == INSECURE_SECRET or len(self.jwt_secret) < 32
        ):
            raise RuntimeError("JWT_SECRET must be set to a strong value (>= 32 chars) in production")
