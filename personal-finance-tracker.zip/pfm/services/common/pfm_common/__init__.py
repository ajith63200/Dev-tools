"""Shared platform code: configuration, database access, auth, events and the app factory.

Each service vendors this package at image build time, so services stay
independently buildable and deployable while sharing one implementation of
the cross-cutting concerns.
"""
