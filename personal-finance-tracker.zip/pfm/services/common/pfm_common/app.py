"""Application factory shared by every service: lifecycle, health, metrics, errors, logging."""
import logging
import threading
import time
from collections.abc import Callable, Iterable
from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4

import psycopg
from fastapi import APIRouter, FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

from .config import Settings
from .db import Database
from .events import Handler, OutboxRelay, idempotent, make_bus, run_periodically
from .logging import setup_logging

log = logging.getLogger("pfm")

REQUESTS = Counter("pfm_http_requests_total", "HTTP requests", ["service", "method", "route", "status"])
LATENCY = Histogram("pfm_http_request_duration_seconds", "HTTP request latency", ["service", "route"])


def get_db(request: Request) -> Database:
    return request.app.state.db


def create_app(
    *,
    title: str,
    description: str = "",
    settings: Settings | None = None,
    migrations_dir: Path | None = None,
    routers: Iterable[APIRouter] = (),
    subscriptions: dict[str, Handler] | None = None,
    jobs: Iterable[tuple[str, float, Callable[[FastAPI], None]]] = (),
    use_database: bool = True,
    on_startup: Callable[[FastAPI], None] | None = None,
) -> FastAPI:
    settings = settings or Settings()
    setup_logging(settings.service_name, settings.log_level)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        settings.validate_for_runtime()
        stop = threading.Event()
        relay = bus = None
        if use_database:
            app.state.db.open()
            app.state.db.migrate(migrations_dir)
            bus = make_bus(settings)
            relay = OutboxRelay(app.state.db, bus)
            app.state.relay = relay
            if subscriptions:
                bus.subscribe(f"{settings.service_name}.events", list(subscriptions),
                              idempotent(app.state.db, subscriptions))
            bus.start()
            relay.start()
        if on_startup:
            on_startup(app)
        for name, interval, fn in jobs:
            run_periodically(name, interval, lambda fn=fn: fn(app), stop)
        log.info("service started")
        yield
        stop.set()
        if relay:
            relay.stop()
        if bus:
            bus.stop()
        if use_database:
            app.state.db.close()

    app = FastAPI(title=title, description=description, version="1.0.0", lifespan=lifespan)
    app.state.settings = settings
    if use_database:
        app.state.db = Database(settings.database_url, settings.db_pool_max)

    if settings.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
                           allow_methods=["*"], allow_headers=["*"], allow_credentials=True)

    @app.middleware("http")
    async def observe(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or uuid4().hex
        request.state.request_id = request_id
        started = time.perf_counter()
        status_code = 500
        try:
            response: Response = await call_next(request)
            status_code = response.status_code
            response.headers["X-Request-ID"] = request_id
            return response
        finally:
            route = getattr(request.scope.get("route"), "path", "unmatched")
            elapsed = time.perf_counter() - started
            if not route.startswith(("/health", "/metrics")):
                REQUESTS.labels(settings.service_name, request.method, route, status_code).inc()
                LATENCY.labels(settings.service_name, route).observe(elapsed)
                # Path template only: no query strings, bodies or amounts in logs.
                log.info("request", extra={"method": request.method, "route": route, "status": status_code,
                                           "duration_ms": round(elapsed * 1000, 1), "request_id": request_id,
                                           "user_id": getattr(request.state, "user_id", None)})

    @app.exception_handler(psycopg.errors.UniqueViolation)
    async def conflict(_: Request, __: Exception):
        return JSONResponse({"detail": "Resource already exists"}, status_code=409)

    @app.exception_handler(psycopg.errors.ForeignKeyViolation)
    async def fk(_: Request, __: Exception):
        return JSONResponse({"detail": "Referenced resource does not exist or is still in use"}, status_code=409)

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        log.error("unhandled error", exc_info=exc, extra={"request_id": getattr(request.state, "request_id", None)})
        return JSONResponse({"detail": "Internal server error"}, status_code=500)

    @app.get("/health/live", include_in_schema=False)
    def live():
        return {"status": "ok", "service": settings.service_name}

    @app.get("/health/ready", include_in_schema=False)
    def ready():
        if use_database and not app.state.db.ping():
            return JSONResponse({"status": "unavailable", "database": "down"}, status_code=503)
        return {"status": "ok", "service": settings.service_name}

    @app.get("/metrics", include_in_schema=False)
    def metrics():
        return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

    for router in routers:
        app.include_router(router)
    return app
