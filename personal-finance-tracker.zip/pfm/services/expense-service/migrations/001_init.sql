CREATE TABLE expense_categories (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID,                          -- NULL = built-in category visible to everyone
    name       TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 60),
    color      TEXT NOT NULL DEFAULT '#64748b' CHECK (color ~ '^#[0-9a-fA-F]{6}$'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_expense_categories_owner_name
    ON expense_categories (COALESCE(user_id, '00000000-0000-0000-0000-000000000000'::uuid), lower(name));

INSERT INTO expense_categories (name, color) VALUES
    ('Food and groceries', '#f59e0b'), ('Transportation', '#3b82f6'), ('Rent and accommodation', '#8b5cf6'),
    ('Shopping', '#ec4899'), ('Healthcare', '#ef4444'), ('Entertainment', '#14b8a6'),
    ('Utilities and bills', '#eab308'), ('Travel', '#06b6d4'), ('EMI and loans', '#f97316'),
    ('Subscriptions', '#a855f7'), ('Other expenses', '#64748b');

CREATE TABLE expenses (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL,
    category_id    UUID NOT NULL REFERENCES expense_categories (id) ON DELETE RESTRICT,
    amount         NUMERIC(14, 2) NOT NULL CHECK (amount > 0),
    txn_date       DATE NOT NULL,
    payment_method TEXT NOT NULL CHECK (payment_method IN
                       ('cash', 'upi', 'credit_card', 'debit_card', 'bank_transfer', 'other')),
    description    TEXT NOT NULL DEFAULT '',
    notes          TEXT NOT NULL DEFAULT '',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_expenses_user_date ON expenses (user_id, txn_date DESC);
CREATE INDEX idx_expenses_user_category ON expenses (user_id, category_id, txn_date);
CREATE INDEX idx_expenses_user_method ON expenses (user_id, payment_method);
