from datetime import date
from uuid import uuid4

import pytest
from pydantic import ValidationError

from app.routes import CategoryIn, ExpenseIn

BASE = dict(category_id=uuid4(), amount="99.90", txn_date=date(2026, 5, 1), payment_method="upi")


def test_valid_expense():
    assert ExpenseIn(**BASE).payment_method == "upi"


@pytest.mark.parametrize("override", [{"amount": "0"}, {"amount": "-3"}, {"payment_method": "cheque"},
                                      {"txn_date": date(1990, 1, 1)}, {"description": "x" * 501}])
def test_invalid_expense(override):
    with pytest.raises(ValidationError):
        ExpenseIn(**{**BASE, **override})


def test_category_colour_must_be_hex():
    CategoryIn(name="Pets", color="#22c55e")
    with pytest.raises(ValidationError):
        CategoryIn(name="Pets", color="green")
