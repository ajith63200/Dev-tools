from pathlib import Path

from fastapi import FastAPI

from pfm_common.app import create_app
from pfm_common.config import Settings

from . import routes


class ExpenseSettings(Settings):
    service_name: str = "expense-service"


def build(settings: Settings | None = None) -> FastAPI:
    return create_app(
        title="PFM Expense Service",
        description="Expense transactions, categories and spending aggregation.",
        settings=settings or ExpenseSettings(),
        migrations_dir=Path(__file__).resolve().parents[1] / "migrations",
        routers=[routes.categories, routes.router],
    )


app = build()
