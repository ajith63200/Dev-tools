from datetime import date, datetime
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from pfm_common.app import get_db
from pfm_common.auth import Principal, current_user
from pfm_common.db import Database
from pfm_common.events import emit
from pfm_common.types import Money, PositiveMoney, Year, month_bounds

categories = APIRouter(prefix="/api/v1/categories", tags=["expense categories"])
router = APIRouter(prefix="/api/v1/expenses", tags=["expenses"])

PaymentMethod = Literal["cash", "upi", "credit_card", "debit_card", "bank_transfer", "other"]
SELECT = ("SELECT e.id, e.category_id, c.name AS category_name, c.color AS category_color, e.amount, e.txn_date, "
          "e.payment_method, e.description, e.notes, e.created_at, e.updated_at "
          "FROM expenses e JOIN expense_categories c ON c.id = e.category_id")


class CategoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    color: str = Field("#64748b", pattern=r"^#[0-9a-fA-F]{6}$")


class CategoryOut(BaseModel):
    id: UUID
    name: str
    color: str
    is_default: bool


class ExpenseIn(BaseModel):
    category_id: UUID
    amount: PositiveMoney
    txn_date: date = Field(ge=date(2000, 1, 1), le=date(2100, 12, 31))
    payment_method: PaymentMethod
    description: str = Field("", max_length=500)
    notes: str = Field("", max_length=2000)


class ExpenseOut(BaseModel):
    id: UUID
    category_id: UUID
    category_name: str
    category_color: str
    amount: Money
    txn_date: date
    payment_method: PaymentMethod
    description: str
    notes: str
    created_at: datetime
    updated_at: datetime


class ExpensePage(BaseModel):
    items: list[ExpenseOut]
    total: int
    total_amount: Money
    limit: int
    offset: int


def _record(row: dict) -> dict:
    return {"id": row["id"], "amount": row["amount"], "date": row["txn_date"], "category_id": row["category_id"],
            "category_name": row["category_name"], "payment_method": row["payment_method"],
            "description": row["description"]}


def _check_category(conn, user_id, category_id) -> None:
    if not conn.execute("SELECT 1 FROM expense_categories WHERE id = %s AND (user_id IS NULL OR user_id = %s)",
                        (category_id, user_id)).fetchone():
        raise HTTPException(422, "Unknown expense category")


def _get(conn, user_id, expense_id) -> dict:
    row = conn.execute(f"{SELECT} WHERE e.id = %s AND e.user_id = %s", (expense_id, user_id)).fetchone()
    if not row:
        raise HTTPException(404, "Expense not found")
    return row


# ---------------------------------------------------------------- categories
@categories.get("", response_model=list[CategoryOut])
def list_categories(user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return conn.execute(
            "SELECT id, name, color, user_id IS NULL AS is_default FROM expense_categories "
            "WHERE user_id IS NULL OR user_id = %s ORDER BY user_id IS NOT NULL, created_at, name",
            (user.user_id,)).fetchall()


@categories.post("", response_model=CategoryOut, status_code=201)
def create_category(body: CategoryIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    name = body.name.strip()
    with db.tx() as conn:
        if conn.execute("SELECT 1 FROM expense_categories WHERE (user_id IS NULL OR user_id = %s) "
                        "AND lower(name) = lower(%s)", (user.user_id, name)).fetchone():
            raise HTTPException(409, "A category with this name already exists")
        return conn.execute("INSERT INTO expense_categories (user_id, name, color) VALUES (%s, %s, %s) "
                            "RETURNING id, name, color, FALSE AS is_default",
                            (user.user_id, name, body.color)).fetchone()


@categories.delete("/{category_id}", status_code=204)
def delete_category(category_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        if conn.execute("SELECT 1 FROM expenses WHERE category_id = %s AND user_id = %s LIMIT 1",
                        (category_id, user.user_id)).fetchone():
            raise HTTPException(409, "Category is used by existing transactions")
        cur = conn.execute("DELETE FROM expense_categories WHERE id = %s AND user_id = %s",
                           (category_id, user.user_id))
        if not cur.rowcount:
            raise HTTPException(404, "Custom category not found")


# ---------------------------------------------------------------- expenses
@router.get("", response_model=ExpensePage)
def list_expenses(date_from: date | None = None, date_to: date | None = None, category_id: UUID | None = None,
                  payment_method: PaymentMethod | None = None, search: str | None = Query(None, max_length=100),
                  limit: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0),
                  user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    where, params = ["e.user_id = %(uid)s"], {"uid": user.user_id, "limit": limit, "offset": offset}
    if date_from:
        where.append("e.txn_date >= %(date_from)s"); params["date_from"] = date_from
    if date_to:
        where.append("e.txn_date <= %(date_to)s"); params["date_to"] = date_to
    if category_id:
        where.append("e.category_id = %(category_id)s"); params["category_id"] = category_id
    if payment_method:
        where.append("e.payment_method = %(payment_method)s"); params["payment_method"] = payment_method
    if search:
        where.append("(e.description ILIKE %(q)s OR e.notes ILIKE %(q)s OR c.name ILIKE %(q)s)")
        params["q"] = f"%{search}%"
    clause = " AND ".join(where)
    with db.tx() as conn:
        agg = conn.execute("SELECT count(*) AS total, COALESCE(sum(e.amount), 0) AS total_amount FROM expenses e "
                           f"JOIN expense_categories c ON c.id = e.category_id WHERE {clause}", params).fetchone()
        items = conn.execute(f"{SELECT} WHERE {clause} ORDER BY e.txn_date DESC, e.created_at DESC "
                             "LIMIT %(limit)s OFFSET %(offset)s", params).fetchall()
    return {"items": items, **agg, "limit": limit, "offset": offset}


@router.get("/summary")
def expense_summary(year: Year, month: int | None = Query(None, ge=1, le=12),
                    user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    """Spending aggregation for a year (or a single month): totals by month, category and payment method."""
    start, end = month_bounds(year, month) if month else (date(year, 1, 1), date(year + 1, 1, 1))
    args = (user.user_id, start, end)
    scope = "user_id = %s AND txn_date >= %s AND txn_date < %s"
    with db.tx() as conn:
        months = {r["month"]: float(r["total"]) for r in conn.execute(
            f"SELECT extract(month FROM txn_date)::int AS month, sum(amount) AS total FROM expenses WHERE {scope} "
            "GROUP BY 1", args)}
        by_category = conn.execute(
            "SELECT c.name AS category, sum(e.amount)::float AS total FROM expenses e "
            "JOIN expense_categories c ON c.id = e.category_id "
            "WHERE e.user_id = %s AND e.txn_date >= %s AND e.txn_date < %s GROUP BY c.name ORDER BY total DESC",
            args).fetchall()
        by_method = conn.execute(
            f"SELECT payment_method, sum(amount)::float AS total FROM expenses WHERE {scope} "
            "GROUP BY payment_method ORDER BY total DESC", args).fetchall()
    return {"year": year, "month": month, "total": round(sum(months.values()), 2),
            "months": [{"month": m, "total": months.get(m, 0.0)} for m in range(1, 13)],
            "by_category": by_category, "by_payment_method": by_method}


@router.post("", response_model=ExpenseOut, status_code=201)
def create_expense(body: ExpenseIn, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        _check_category(conn, user.user_id, body.category_id)
        new_id = conn.execute(
            "INSERT INTO expenses (user_id, category_id, amount, txn_date, payment_method, description, notes) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id",
            (user.user_id, body.category_id, body.amount, body.txn_date, body.payment_method,
             body.description.strip(), body.notes.strip())).fetchone()["id"]
        row = _get(conn, user.user_id, new_id)
        emit(conn, "expense.created", user.user_id, {"before": None, "after": _record(row)})
        return row


@router.get("/{expense_id}", response_model=ExpenseOut)
def get_expense(expense_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        return _get(conn, user.user_id, expense_id)


@router.put("/{expense_id}", response_model=ExpenseOut)
def update_expense(expense_id: UUID, body: ExpenseIn, user: Principal = Depends(current_user),
                   db: Database = Depends(get_db)):
    with db.tx() as conn:
        before = _get(conn, user.user_id, expense_id)
        _check_category(conn, user.user_id, body.category_id)
        conn.execute(
            "UPDATE expenses SET category_id = %s, amount = %s, txn_date = %s, payment_method = %s, "
            "description = %s, notes = %s, updated_at = now() WHERE id = %s AND user_id = %s",
            (body.category_id, body.amount, body.txn_date, body.payment_method, body.description.strip(),
             body.notes.strip(), expense_id, user.user_id))
        row = _get(conn, user.user_id, expense_id)
        emit(conn, "expense.updated", user.user_id, {"before": _record(before), "after": _record(row)})
        return row


@router.delete("/{expense_id}", status_code=204)
def delete_expense(expense_id: UUID, user: Principal = Depends(current_user), db: Database = Depends(get_db)):
    with db.tx() as conn:
        before = _get(conn, user.user_id, expense_id)
        conn.execute("DELETE FROM expenses WHERE id = %s AND user_id = %s", (expense_id, user.user_id))
        emit(conn, "expense.deleted", user.user_id, {"before": _record(before), "after": None})
