# CI/CD

| Pipeline | File | Trigger |
|---|---|---|
| GitHub Actions CI | `.github/workflows/ci.yml` | every push and pull request |
| GitHub Actions release | `.github/workflows/release.yml` | tags `vX.Y.Z` |
| Jenkins (same stages) | `ci-cd/Jenkinsfile` | multibranch pipeline |

GitHub only reads workflows from `.github/workflows/`, so the Actions files live there; this folder holds the
Jenkins pipeline and this overview.

**CI stages:** ruff lint -> unit tests per service -> integration tests against PostgreSQL -> frontend typecheck,
unit tests and production build -> Compose / Helm / Terraform validation -> build all images, start the stack,
seed it and run the end-to-end smoke test -> vulnerability scan.

**Release:** multi-arch images are pushed to `ghcr.io/<owner>/pfm-<component>:<version>`. The optional deploy job
runs `helm upgrade --install` against whichever cluster the `KUBECONFIG_B64` secret points to (set the repository
variable `DEPLOY_ENABLED=true`). Nothing in the pipeline is tied to a cloud provider.
