"""End-to-end behaviour across services: auth, CRUD, events, projections, reports, isolation."""
from datetime import datetime, timezone
from uuid import uuid4

import pytest

TODAY = datetime.now(timezone.utc).date()
Y, M = TODAY.year, TODAY.month
PERIOD = {"year": Y, "month": M}


def day(n: int) -> str:
    return TODAY.replace(day=n).isoformat()


@pytest.fixture(scope="module")
def alice(platform):
    return platform.register(f"alice-{uuid4().hex[:8]}@example.com", name="Alice Example")


@pytest.fixture(scope="module")
def refs(platform, alice):
    cats = {c["name"]: c["id"] for c in platform.clients["expense"].get("/api/v1/categories", headers=alice).json()}
    srcs = {s["name"]: s["id"] for s in platform.clients["income"].get("/api/v1/income-sources", headers=alice).json()}
    return cats, srcs


def add_expense(platform, headers, category_id, amount, d=1, method="upi", description="test"):
    r = platform.clients["expense"].post("/api/v1/expenses", headers=headers, json={
        "category_id": category_id, "amount": amount, "txn_date": day(d), "payment_method": method,
        "description": description})
    assert r.status_code == 201, r.text
    return r.json()


# ---------------------------------------------------------------- auth
def test_registration_creates_profile_and_welcome_notification(platform, alice):
    profile = platform.clients["user"].get("/api/v1/users/me", headers=alice).json()
    assert profile["full_name"] == "Alice Example" and profile["currency"] == "INR"
    notes = platform.clients["notification"].get("/api/v1/notifications", headers=alice).json()
    assert notes["unread_count"] == 1 and notes["items"][0]["type"] == "system"


def test_duplicate_email_and_weak_password_rejected(platform):
    email = f"dup-{uuid4().hex[:8]}@example.com"
    platform.register(email)
    auth = platform.clients["auth"]
    assert auth.post("/api/v1/auth/register", json={"email": email.upper(), "password": "Passw0rd!x",
                                                    "full_name": "X"}).status_code == 409
    assert auth.post("/api/v1/auth/register", json={"email": "weak@example.com", "password": "short",
                                                    "full_name": "X"}).status_code == 422


def test_login_refresh_and_token_types(platform):
    email = f"login-{uuid4().hex[:8]}@example.com"
    platform.register(email, password="Correct1horse")
    auth = platform.clients["auth"]
    assert auth.post("/api/v1/auth/login", json={"email": email, "password": "wrong-pass1"}).status_code == 401
    tokens = auth.post("/api/v1/auth/login", json={"email": email, "password": "Correct1horse"}).json()["tokens"]
    # a refresh token must not work as an access token
    assert auth.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {tokens['refresh_token']}"}).status_code == 401
    refreshed = auth.post("/api/v1/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert refreshed.status_code == 200
    assert auth.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {refreshed.json()['access_token']}"}).status_code == 200


def test_unauthenticated_and_rbac(platform, alice):
    for service, path in [("expense", "/api/v1/expenses"), ("income", "/api/v1/incomes"),
                          ("budget", f"/api/v1/budgets?year={Y}&month={M}"), ("savings", f"/api/v1/savings/history?year={Y}"),
                          ("analytics", f"/api/v1/analytics/dashboard?year={Y}&month={M}"),
                          ("notification", "/api/v1/notifications"), ("user", "/api/v1/users/me")]:
        assert platform.clients[service].get(path).status_code == 401, service
        assert platform.clients[service].get(path, headers={"Authorization": "Bearer not.a.jwt"}).status_code == 401
    assert platform.clients["auth"].get("/api/v1/auth/users", headers=alice).status_code == 403


# ---------------------------------------------------------------- validation
def test_input_validation(platform, alice, refs):
    cats, _ = refs
    post = lambda body: platform.clients["expense"].post("/api/v1/expenses", headers=alice, json=body).status_code
    good = {"category_id": cats["Shopping"], "amount": 10, "txn_date": day(1), "payment_method": "cash"}
    assert post({**good, "amount": -5}) == 422
    assert post({**good, "amount": 0}) == 422
    assert post({**good, "payment_method": "bitcoin"}) == 422
    assert post({**good, "category_id": str(uuid4())}) == 422
    assert post({**good, "txn_date": "not-a-date"}) == 422


# ---------------------------------------------------------------- the main money flow
def test_transactions_drive_savings_budgets_analytics_and_alerts(platform, alice, refs):
    cats, srcs = refs
    c = platform.clients
    assert c["income"].post("/api/v1/incomes", headers=alice, json={
        "source_id": srcs["Monthly salary"], "amount": 100000, "txn_date": day(1), "description": "Salary"}).status_code == 201
    assert c["income"].post("/api/v1/incomes", headers=alice, json={
        "source_id": srcs["Freelancing"], "amount": 20000, "txn_date": day(1)}).status_code == 201

    # budgets: overall 50,000 and Food 10,000
    assert c["budget"].put("/api/v1/budgets", headers=alice, json={**PERIOD, "limit_amount": 50000}).status_code == 200
    assert c["budget"].put("/api/v1/budgets", headers=alice, json={
        **PERIOD, "category_id": cats["Food and groceries"], "category_name": "Food and groceries",
        "limit_amount": 10000}).status_code == 200

    rent = add_expense(platform, alice, cats["Rent and accommodation"], 25000, method="bank_transfer")
    food = add_expense(platform, alice, cats["Food and groceries"], 7500)
    add_expense(platform, alice, cats["Transportation"], 2500.50, method="credit_card")
    platform.flush()

    # savings = income - expenses
    s = c["savings"].get("/api/v1/savings/summary", headers=alice, params=PERIOD).json()
    assert s["income"] == 120000 and s["expense"] == 35000.5 and s["savings"] == 84999.5
    assert s["savings_pct"] == 70.8

    # budget utilisation
    b = c["budget"].get("/api/v1/budgets", headers=alice, params=PERIOD).json()
    assert b["overall"]["utilization_pct"] == 70.0 and b["overall"]["status"] == "ok"
    assert b["categories"][0]["utilization_pct"] == 75.0 and b["remaining"] == 14999.5
    assert {u["category_name"] for u in b["unbudgeted"]} == {"Rent and accommodation", "Transportation"}

    # dashboard is computed from the stored transactions
    d = c["analytics"].get("/api/v1/analytics/dashboard", headers=alice, params=PERIOD).json()
    assert d["summary"] == {"total_income": 120000.0, "total_expenses": 35000.5, "total_savings": 84999.5,
                            "savings_pct": 70.8, "budget_limit": 50000.0, "budget_remaining": 14999.5,
                            "budget_utilization_pct": 70.0}
    assert d["top_categories"][0]["category"] == "Rent and accommodation"
    assert round(sum(x["pct"] for x in d["category_breakdown"])) == 100
    assert sum(x["amount"] for x in d["daily_spending"]) == 35000.5
    assert d["income_vs_expense"][-1]["income"] == 120000 and len(d["income_vs_expense"]) == 12

    # crossing 80% of the food budget -> exactly one alert
    add_expense(platform, alice, cats["Food and groceries"], 1000)       # 8,500 / 10,000 = 85%
    platform.flush()
    alerts = lambda: [n for n in c["notification"].get("/api/v1/notifications", headers=alice).json()["items"]
                      if n["type"] == "budget_alert"]
    assert [a["metadata"]["threshold"] for a in alerts()] == [80]
    add_expense(platform, alice, cats["Food and groceries"], 100)        # still in the 80% band: no new alert
    platform.flush()
    assert len(alerts()) == 1
    add_expense(platform, alice, cats["Food and groceries"], 2400)       # 11,000 -> jumps past 90 and 100
    platform.flush()
    food_alerts = [a for a in alerts() if a["metadata"]["scope"] == "category"]
    assert sorted(a["metadata"]["threshold"] for a in food_alerts) == [80, 100]
    assert any(a["severity"] == "critical" for a in food_alerts)

    # update: amounts move between projections; delete: they disappear
    r = c["expense"].put(f"/api/v1/expenses/{rent['id']}", headers=alice, json={
        "category_id": cats["Rent and accommodation"], "amount": 20000, "txn_date": day(1),
        "payment_method": "bank_transfer", "description": "Rent (renegotiated)"})
    assert r.status_code == 200
    assert c["expense"].delete(f"/api/v1/expenses/{food['id']}", headers=alice).status_code == 204
    platform.flush()
    expected = 20000 + 2500.5 + 1000 + 100 + 2400
    assert c["savings"].get("/api/v1/savings/summary", headers=alice, params=PERIOD).json()["expense"] == expected
    assert c["budget"].get("/api/v1/budgets", headers=alice, params=PERIOD).json()["total_spent"] == expected
    d = c["analytics"].get("/api/v1/analytics/dashboard", headers=alice, params=PERIOD).json()
    assert d["summary"]["total_expenses"] == expected
    listed = c["expense"].get("/api/v1/expenses", headers=alice).json()
    assert listed["total"] == 5 and listed["total_amount"] == expected


def test_filters_and_search(platform, alice, refs):
    cats, _ = refs
    get = lambda **params: platform.clients["expense"].get("/api/v1/expenses", headers=alice, params=params).json()
    assert get(payment_method="credit_card")["total"] == 1
    assert get(category_id=cats["Food and groceries"])["total"] == 3
    assert get(search="renegotiated")["total"] == 1
    assert get(date_from=day(1), date_to=day(1))["total"] == 5
    assert get(date_from="2001-01-01", date_to="2001-12-31")["total"] == 0
    assert len(get(limit=2)["items"]) == 2


def test_monthly_report_and_exports(platform, alice):
    c = platform.clients["analytics"]
    report = c.get("/api/v1/analytics/reports/monthly", headers=alice, params=PERIOD).json()
    assert report["highest_category"]["category"] == "Rent and accommodation"
    assert report["lowest_category"]["category"] == "Transportation"
    assert report["average_daily_expenditure"] == round(report["total_expenses"] / TODAY.day, 2)
    assert report["comparison"]["expenses"]["previous"] == 0 and report["comparison"]["expenses"]["change_pct"] is None
    assert report["budget"]["limit"] == 50000 and report["insights"]
    pdf = c.get("/api/v1/analytics/reports/monthly/export", headers=alice, params={**PERIOD, "format": "pdf"})
    assert pdf.status_code == 200 and pdf.content.startswith(b"%PDF") and "attachment" in pdf.headers["content-disposition"]
    xlsx = c.get("/api/v1/analytics/reports/monthly/export", headers=alice, params={**PERIOD, "format": "xlsx"})
    assert xlsx.status_code == 200 and xlsx.content.startswith(b"PK")
    yearly = c.get("/api/v1/analytics/reports/yearly", headers=alice, params={"year": Y}).json()
    assert yearly["total_income"] == 120000 and len(yearly["months"]) == 12
    quarter = c.get("/api/v1/analytics/reports/quarterly", headers=alice, params={"year": Y, "quarter": (M - 1) // 3 + 1}).json()
    assert quarter["total_income"] == 120000 and len(quarter["months"]) == 3


def test_savings_goals_progress(platform, alice):
    c = platform.clients["savings"]
    assert c.post("/api/v1/savings/goals", headers=alice, json={"name": "bad", "period": "monthly", "year": Y,
                                                               "target_amount": 10}).status_code == 422
    goal = c.post("/api/v1/savings/goals", headers=alice, json={
        "name": "Emergency fund", "period": "yearly", "year": Y, "target_amount": 187999}).json()
    assert goal["saved"] == 93999.5 and goal["progress_pct"] == 50.0 and goal["achieved"] is False
    monthly = c.post("/api/v1/savings/goals", headers=alice, json={
        "name": "Monthly target", "period": "monthly", "year": Y, "month": M, "target_amount": 50000}).json()
    assert monthly["achieved"] is True
    assert len(c.get("/api/v1/savings/goals", headers=alice, params={"year": Y}).json()) == 2
    assert c.delete(f"/api/v1/savings/goals/{goal['id']}", headers=alice).status_code == 204


def test_custom_categories_and_sources(platform, alice):
    c = platform.clients["expense"]
    created = c.post("/api/v1/categories", headers=alice, json={"name": "Pet care", "color": "#22c55e"})
    assert created.status_code == 201 and created.json()["is_default"] is False
    assert c.post("/api/v1/categories", headers=alice, json={"name": "pet CARE"}).status_code == 409
    assert c.post("/api/v1/categories", headers=alice, json={"name": "Shopping"}).status_code == 409
    expense = add_expense(platform, alice, created.json()["id"], 10)
    assert c.delete(f"/api/v1/categories/{created.json()['id']}", headers=alice).status_code == 409  # in use
    c.delete(f"/api/v1/expenses/{expense['id']}", headers=alice)
    assert c.delete(f"/api/v1/categories/{created.json()['id']}", headers=alice).status_code == 204
    platform.flush()
    src = platform.clients["income"].post("/api/v1/income-sources", headers=alice, json={"name": "Rental income"})
    assert src.status_code == 201


# ---------------------------------------------------------------- tenant isolation
def test_users_cannot_see_or_change_each_others_records(platform, alice, refs):
    cats, _ = refs
    bob = platform.register(f"bob-{uuid4().hex[:8]}@example.com", name="Bob")
    c = platform.clients
    target = c["expense"].get("/api/v1/expenses", headers=alice).json()["items"][0]
    body = {"category_id": cats["Shopping"], "amount": 1, "txn_date": day(1), "payment_method": "cash"}
    assert c["expense"].get(f"/api/v1/expenses/{target['id']}", headers=bob).status_code == 404
    assert c["expense"].put(f"/api/v1/expenses/{target['id']}", headers=bob, json=body).status_code == 404
    assert c["expense"].delete(f"/api/v1/expenses/{target['id']}", headers=bob).status_code == 404
    assert c["expense"].get("/api/v1/expenses", headers=bob).json()["total"] == 0
    assert c["income"].get("/api/v1/incomes", headers=bob).json()["total"] == 0
    assert c["savings"].get("/api/v1/savings/summary", headers=bob, params=PERIOD).json()["income"] == 0
    assert c["analytics"].get("/api/v1/analytics/dashboard", headers=bob, params=PERIOD).json()["summary"]["total_expenses"] == 0
    assert c["budget"].get("/api/v1/budgets", headers=bob, params=PERIOD).json()["overall"] is None
    budget_id = c["budget"].get("/api/v1/budgets", headers=alice, params=PERIOD).json()["overall"]["id"]
    assert c["budget"].delete(f"/api/v1/budgets/{budget_id}", headers=bob).status_code == 404
    note_id = c["notification"].get("/api/v1/notifications", headers=alice).json()["items"][0]["id"]
    assert c["notification"].post(f"/api/v1/notifications/{note_id}/read", headers=bob).status_code == 404
    # alice's record is untouched
    assert c["expense"].get(f"/api/v1/expenses/{target['id']}", headers=alice).json()["amount"] == target["amount"]


# ---------------------------------------------------------------- messaging guarantees
def test_redelivered_events_are_applied_once(platform, alice):
    before = platform.clients["savings"].get("/api/v1/savings/summary", headers=alice, params=PERIOD).json()
    with platform.apps["expense"].state.db.tx() as conn:
        conn.execute("UPDATE outbox SET published_at = NULL")  # simulate the broker redelivering everything
    platform.flush()
    after = platform.clients["savings"].get("/api/v1/savings/summary", headers=alice, params=PERIOD).json()
    assert before == after


def test_reminders_become_notifications(platform, alice):
    c = platform.clients["notification"]
    assert c.post("/api/v1/reminders", headers=alice, json={"title": "Pay credit card bill", "due_date": TODAY.isoformat(),
                                                           "recurrence": "monthly"}).status_code == 201
    from importlib import import_module
    import_module("pfm_notification_app.service").dispatch_due_reminders(platform.apps["notification"])
    items = c.get("/api/v1/notifications", headers=alice, params={"unread_only": True}).json()["items"]
    assert any(n["type"] == "reminder" and n["title"] == "Pay credit card bill" for n in items)
    assert c.get("/api/v1/reminders", headers=alice).json()[0]["due_date"] > TODAY.isoformat()  # rolled forward
    assert c.post("/api/v1/notifications/read-all", headers=alice).status_code == 204
    assert c.get("/api/v1/notifications", headers=alice).json()["unread_count"] == 0


def test_monthly_report_announcement_is_sent_once(platform):
    from importlib import import_module
    reports = import_module("pfm_analytics_app.reports")
    y, m = reports.shift_month(Y, M, -1)
    carol = platform.register(f"carol-{uuid4().hex[:8]}@example.com")
    cats = platform.clients["expense"].get("/api/v1/categories", headers=carol).json()
    platform.clients["expense"].post("/api/v1/expenses", headers=carol, json={
        "category_id": cats[0]["id"], "amount": 99, "txn_date": f"{y}-{m:02d}-05", "payment_method": "cash"})
    platform.flush()
    announce = import_module("pfm_analytics_app.main").announce_monthly_reports
    announce(platform.apps["analytics"]); announce(platform.apps["analytics"])
    platform.flush()
    items = platform.clients["notification"].get("/api/v1/notifications", headers=carol).json()["items"]
    assert [n["type"] for n in items].count("monthly_report") == 1


# ---------------------------------------------------------------- gateway
def test_gateway_routes_authenticates_and_rate_limits(platform, alice):
    gw = platform.clients["gateway"]
    assert gw.get("/api/v1/expenses").status_code == 401
    assert gw.get("/api/v1/expenses", headers={"Authorization": "Bearer forged"}).status_code == 401
    assert gw.get("/api/v1/unknown-resource", headers=alice).status_code == 404
    listed = gw.get("/api/v1/expenses", headers=alice, params={"limit": 1})
    assert listed.status_code == 200 and len(listed.json()["items"]) == 1
    assert gw.get("/api/v1/users/me", headers=alice).json()["full_name"] == "Alice Example"
    pdf = gw.get("/api/v1/analytics/reports/monthly/export", headers=alice, params={**PERIOD, "format": "pdf"})
    assert pdf.content.startswith(b"%PDF") and pdf.headers["content-type"] == "application/pdf"
    assert gw.get("/api/v1/status").json()["status"] == "ok"
    codes = [gw.post("/api/v1/auth/login", json={"email": "nobody@example.com", "password": "nope-nope1"}).status_code
             for _ in range(7)]
    assert codes[:5] == [401] * 5 and codes[5:] == [429, 429]
