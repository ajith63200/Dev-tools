"""Whole-platform integration harness.

Boots all nine services in one interpreter against a real PostgreSQL (one database per
service, exactly like production) with the in-memory event bus, so tests exercise real
SQL, migrations, the outbox, consumers and cross-service flows without containers.

    TEST_DATABASE_ADMIN_URL=postgresql://postgres:postgres@localhost:5432/postgres pytest tests/integration
"""
import importlib.util
import os
import sys
from pathlib import Path

import httpx
import psycopg
import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "services" / "common"))

ADMIN_URL = os.environ.get("TEST_DATABASE_ADMIN_URL", "postgresql://postgres:postgres@127.0.0.1:5432/postgres")
SERVICES = ["auth", "user", "income", "expense", "budget", "savings", "analytics", "notification"]
SECRET = "integration-test-secret-0123456789abcdef"


def load_service(name: str):
    """Import services/<name>/app as a uniquely named package so all services coexist in one process."""
    directory = "api-gateway" if name == "gateway" else f"{name}-service"
    package = f"pfm_{name}_app"
    init = ROOT / "services" / directory / "app" / "__init__.py"
    spec = importlib.util.spec_from_file_location(package, init, submodule_search_locations=[str(init.parent)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[package] = module
    spec.loader.exec_module(module)
    return importlib.import_module(f"{package}.main")


class Platform:
    def __init__(self):
        self.clients: dict[str, TestClient] = {}
        self.apps = {}

    def flush(self) -> None:
        """Deliver every pending event, including events emitted by consumers."""
        for _ in range(10):
            if sum(app.state.relay.flush() for app in self.apps.values()) == 0:
                return
        raise AssertionError("event cascade did not settle")

    def register(self, email: str, password: str = "Passw0rd!x", name: str = "Test User") -> dict:
        resp = self.clients["auth"].post("/api/v1/auth/register",
                                         json={"email": email, "password": password, "full_name": name})
        assert resp.status_code == 201, resp.text
        self.flush()
        return {"Authorization": f"Bearer {resp.json()['tokens']['access_token']}"}


@pytest.fixture(scope="session")
def platform():
    base = ADMIN_URL.rsplit("/", 1)[0]
    with psycopg.connect(ADMIN_URL, autocommit=True) as admin:
        for name in SERVICES:
            admin.execute(f'DROP DATABASE IF EXISTS "pfm_test_{name}" WITH (FORCE)')
            admin.execute(f'CREATE DATABASE "pfm_test_{name}"')

    p = Platform()
    stack = []
    for name in SERVICES:
        module = load_service(name)
        settings_cls = next(v for k, v in vars(module).items() if k.endswith("Settings") and k != "Settings")
        extra = {"budget_service_url": "http://testserver"} if name == "analytics" else {}
        settings = settings_cls(database_url=f"{base}/pfm_test_{name}", event_bus="memory", jwt_secret=SECRET,
                                redis_url="", **extra)
        app = module.build(settings)
        client = TestClient(app)
        client.__enter__()
        stack.append(client)
        p.apps[name], p.clients[name] = app, client
    # analytics -> budget synchronous call goes through the budget app in-process
    p.apps["analytics"].state.http = p.clients["budget"]

    # API gateway in front of the in-process services
    gateway = load_service("gateway")
    transports = {f"{n}.test": httpx.ASGITransport(app=p.apps[n]) for n in SERVICES}

    class Router(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request):
            return await transports[request.url.host].handle_async_request(request)

    gw_settings = gateway.GatewaySettings(jwt_secret=SECRET, auth_rate_limit_per_minute=5, redis_url="",
                                          **{f"{n}_service_url": f"http://{n}.test" for n in SERVICES})
    gw_client = TestClient(gateway.build(gw_settings, transport=Router()))
    gw_client.__enter__()
    stack.append(gw_client)
    p.clients["gateway"] = gw_client

    yield p
    for client in reversed(stack):
        client.__exit__(None, None, None)
