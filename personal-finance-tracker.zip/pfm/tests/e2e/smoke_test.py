#!/usr/bin/env python3
"""End-to-end smoke test against a RUNNING stack (Docker Compose, Kubernetes port-forward, ...).

Exercises the real path: gateway -> services -> PostgreSQL -> RabbitMQ -> consumers -> analytics.
Standard library only.   GATEWAY_URL=http://localhost:8080 python tests/e2e/smoke_test.py
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import date

GATEWAY = os.environ.get("GATEWAY_URL", "http://localhost:8080").rstrip("/")
token = None


def call(method, path, body=None, raw=False):
    req = urllib.request.Request(f"{GATEWAY}{path}", method=method,
                                 data=json.dumps(body).encode() if body is not None else None)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = resp.read()
            return resp.status, data if raw else (json.loads(data) if data else None)
    except urllib.error.HTTPError as err:
        return err.code, None


def check(name, condition):
    print(f"  {'PASS' if condition else 'FAIL'}  {name}")
    if not condition:
        sys.exit(1)


def eventually(fn, timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if (value := fn()):
            return value
        time.sleep(0.5)
    return None


today = date.today()
period = f"year={today.year}&month={today.month}"
email = f"smoke-{uuid.uuid4().hex[:10]}@example.com"

check("all services ready", call("GET", "/api/v1/status")[0] == 200)
check("protected route rejects anonymous calls", call("GET", "/api/v1/expenses")[0] == 401)
status, body = call("POST", "/api/v1/auth/register", {"email": email, "password": "Smoke-test1", "full_name": "Smoke Test"})
check("register", status == 201)
token = body["tokens"]["access_token"]

cats = call("GET", "/api/v1/categories")[1]
sources = call("GET", "/api/v1/income-sources")[1]
check("default categories and sources", len(cats) >= 11 and len(sources) >= 5)
food = next(c for c in cats if c["name"] == "Food and groceries")
check("create income", call("POST", "/api/v1/incomes", {"source_id": sources[0]["id"], "amount": 50000,
                                                       "txn_date": today.isoformat()})[0] == 201)
check("set budget", call("PUT", "/api/v1/budgets", {"year": today.year, "month": today.month, "category_id": food["id"],
                                                    "category_name": food["name"], "limit_amount": 1000})[0] == 200)
status, expense = call("POST", "/api/v1/expenses", {"category_id": food["id"], "amount": 950, "txn_date": today.isoformat(),
                                                    "payment_method": "upi", "description": "smoke"})
check("create expense", status == 201)

dash = eventually(lambda: (d := call("GET", f"/api/v1/analytics/dashboard?{period}")[1]) and
                  d["summary"]["total_expenses"] == 950 and d["summary"]["total_income"] == 50000 and d)
check("dashboard reflects events (analytics read model)", bool(dash))
check("savings = income - expenses", dash["summary"]["total_savings"] == 49050)
check("savings service projection", eventually(
    lambda: call("GET", f"/api/v1/savings/summary?{period}")[1]["savings"] == 49050))
check("budget utilisation 95%", eventually(
    lambda: call("GET", f"/api/v1/budgets?{period}")[1]["categories"][0]["utilization_pct"] == 95.0))
check("budget alert notification delivered", eventually(
    lambda: any(n["type"] == "budget_alert" for n in call("GET", "/api/v1/notifications")[1]["items"])))
status, pdf = call("GET", f"/api/v1/analytics/reports/monthly/export?{period}&format=pdf", raw=True)
check("PDF export", status == 200 and pdf.startswith(b"%PDF"))
status, xlsx = call("GET", f"/api/v1/analytics/reports/monthly/export?{period}&format=xlsx", raw=True)
check("Excel export", status == 200 and xlsx.startswith(b"PK"))
check("delete expense", call("DELETE", f"/api/v1/expenses/{expense['id']}")[0] == 204)
check("deletion propagates", eventually(
    lambda: call("GET", f"/api/v1/savings/summary?{period}")[1]["expense"] == 0))
print("smoke test passed")
