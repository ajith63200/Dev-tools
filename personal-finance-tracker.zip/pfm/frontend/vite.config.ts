import react from '@vitejs/plugin-react'
import { defineConfig } from "vitest/config"

// In development, /api is proxied to the gateway so the browser sees a single origin (as in production).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': { target: process.env.VITE_DEV_GATEWAY ?? 'http://localhost:8080', changeOrigin: true } },
  },
  build: { chunkSizeWarningLimit: 900 },
  test: { environment: 'node' },
})
