import { Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { Button, Card, Empty, ErrorNote, Field, Modal, PageHeader, Spinner, cn } from '../components/ui'
import { api, query } from '../lib/api'
import { monthRange, PAYMENT_METHODS, shortDate, todayIso } from '../lib/format'
import { useFetch, useStore } from '../lib/store'
import type { Category, Expense, Income, Page, Source } from '../lib/types'

type Row = Expense | Income
const PAGE = 20

interface Draft { id?: string; ref: string; amount: string; txn_date: string; payment_method: string; description: string; notes: string }

export default function Transactions({ kind }: { kind: 'expense' | 'income' }) {
  const isExpense = kind === 'expense'
  const base = isExpense ? '/expenses' : '/incomes'
  const { year, month, fmt } = useStore()
  const initial = useMemo(() => monthRange(year, month), [year, month])
  const [filters, setFilters] = useState({ from: initial.from, to: initial.to, ref: '', method: '', search: '' })
  const [search, setSearch] = useState('')
  const [offset, setOffset] = useState(0)
  const [draft, setDraft] = useState<Draft | null>(null)
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  const refs = useFetch<(Category | Source)[]>(isExpense ? '/categories' : '/income-sources')
  const list = useFetch<Page<Row>>(base + query({
    date_from: filters.from, date_to: filters.to, [isExpense ? 'category_id' : 'source_id']: filters.ref,
    payment_method: isExpense ? filters.method : undefined, search: filters.search, limit: PAGE, offset,
  }))

  useEffect(() => {   // debounce the search box
    const id = setTimeout(() => { setFilters((f) => ({ ...f, search })); setOffset(0) }, 300)
    return () => clearTimeout(id)
  }, [search])

  const setFilter = (k: keyof typeof filters, v: string) => { setFilters((f) => ({ ...f, [k]: v })); setOffset(0) }
  const blank = (): Draft => ({ ref: refs.data?.[0]?.id ?? '', amount: '', txn_date: todayIso(), payment_method: 'upi', description: '', notes: '' })
  const edit = (r: Row): Draft => ({
    id: r.id, ref: 'category_id' in r ? r.category_id : r.source_id, amount: String(r.amount), txn_date: r.txn_date,
    payment_method: 'payment_method' in r ? r.payment_method : 'upi', description: r.description, notes: 'notes' in r ? r.notes : '',
  })

  const save = async (e: FormEvent) => {
    e.preventDefault()
    if (!draft) return
    setSaving(true); setFormError(null)
    const common = { amount: Number(draft.amount), txn_date: draft.txn_date, description: draft.description }
    const body = isExpense ? { ...common, category_id: draft.ref, payment_method: draft.payment_method, notes: draft.notes }
      : { ...common, source_id: draft.ref }
    try {
      if (draft.id) await api.put(`${base}/${draft.id}`, body)
      else await api.post(base, body)
      setDraft(null); list.reload()
    } catch (err) { setFormError((err as Error).message) } finally { setSaving(false) }
  }

  const remove = async (r: Row) => {
    if (!window.confirm(`Delete this ${kind} of ${fmt(r.amount, 2)}?`)) return
    try { await api.del(`${base}/${r.id}`); list.reload() } catch (err) { window.alert((err as Error).message) }
  }

  const data = list.data
  const pages = data ? Math.max(1, Math.ceil(data.total / PAGE)) : 1
  const noun = isExpense ? 'expense' : 'income'

  return (
    <>
      <PageHeader title={isExpense ? 'Expenses' : 'Income'} subtitle={isExpense ? 'Every purchase, bill and payment.' : 'Salary, freelance work, investments and more.'}>
        <Button onClick={() => { setFormError(null); setDraft(blank()) }}><Plus size={16} />Add {noun}</Button>
      </PageHeader>

      <Card className="mb-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="Search" className="lg:col-span-1">
            <div className="relative"><Search size={15} className="pointer-events-none absolute left-3 top-2.5 text-muted" />
              <input className="input pl-9" placeholder="Description or notes" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
          </Field>
          <Field label="From"><input type="date" className="input" value={filters.from} onChange={(e) => setFilter('from', e.target.value)} /></Field>
          <Field label="To"><input type="date" className="input" value={filters.to} onChange={(e) => setFilter('to', e.target.value)} /></Field>
          <Field label={isExpense ? 'Category' : 'Source'}>
            <select className="input" value={filters.ref} onChange={(e) => setFilter('ref', e.target.value)}>
              <option value="">All</option>
              {refs.data?.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
          </Field>
          {isExpense ? (
            <Field label="Payment method">
              <select className="input" value={filters.method} onChange={(e) => setFilter('method', e.target.value)}>
                <option value="">All</option>
                {Object.entries(PAYMENT_METHODS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </Field>
          ) : <div />}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <button className="chip hover:text-ink" onClick={() => { setFilters((f) => ({ ...f, ...initial })); setOffset(0) }}>Selected month</button>
          <button className="chip hover:text-ink" onClick={() => { setFilters((f) => ({ ...f, from: `${year}-01-01`, to: `${year}-12-31` })); setOffset(0) }}>This year</button>
          <button className="chip hover:text-ink" onClick={() => { setFilters((f) => ({ ...f, from: '', to: '' })); setOffset(0) }}>All time</button>
          {data && <span className="ml-auto text-muted">{data.total} {data.total === 1 ? 'record' : 'records'} · <span className={cn('num font-medium', isExpense ? 'text-expense' : 'text-income')}>{fmt(data.total_amount, 2)}</span></span>}
        </div>
      </Card>

      {list.error && <ErrorNote message={list.error} onRetry={list.reload} />}
      {!data && list.loading && <Spinner />}
      {data && (
        <Card className="overflow-hidden p-0">
          {data.items.length === 0 ? <Empty title={`No ${noun} found`} hint="Try a wider date range, or add a new record." /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                  <tr><th className="px-5 py-3 font-medium">Date</th><th className="px-3 py-3 font-medium">Description</th>
                    <th className="hidden px-3 py-3 font-medium sm:table-cell">{isExpense ? 'Category' : 'Source'}</th>
                    {isExpense && <th className="hidden px-3 py-3 font-medium md:table-cell">Method</th>}
                    <th className="px-3 py-3 text-right font-medium">Amount</th><th className="px-5 py-3" /></tr>
                </thead>
                <tbody className="divide-y divide-line/70">
                  {data.items.map((r) => {
                    const name = 'category_name' in r ? r.category_name : r.source_name
                    return (
                      <tr key={r.id} className="hover:bg-bg/60">
                        <td className="num whitespace-nowrap px-5 py-3 text-muted">{shortDate(r.txn_date)}</td>
                        <td className="max-w-[16rem] px-3 py-3"><p className="truncate">{r.description || name}</p>
                          <p className="truncate text-xs text-muted sm:hidden">{name}</p>
                          {'notes' in r && r.notes && <p className="truncate text-xs text-muted">{r.notes}</p>}</td>
                        <td className="hidden px-3 py-3 sm:table-cell">
                          <span className="chip">{'category_color' in r && <span className="h-2 w-2 rounded-full" style={{ background: r.category_color }} />}{name}</span></td>
                        {isExpense && <td className="hidden px-3 py-3 text-muted md:table-cell">{'payment_method' in r && PAYMENT_METHODS[r.payment_method]}</td>}
                        <td className={cn('num whitespace-nowrap px-3 py-3 text-right font-medium', isExpense ? 'text-expense' : 'text-income')}>{fmt(r.amount, 2)}</td>
                        <td className="whitespace-nowrap px-5 py-3 text-right">
                          <button aria-label="Edit" onClick={() => { setFormError(null); setDraft(edit(r)) }} className="rounded p-1.5 text-muted hover:text-ink"><Pencil size={15} /></button>
                          <button aria-label="Delete" onClick={() => remove(r)} className="rounded p-1.5 text-muted hover:text-expense"><Trash2 size={15} /></button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
          {data.total > PAGE && (
            <div className="flex items-center justify-between border-t border-line px-5 py-3 text-sm text-muted">
              <span>Page {Math.floor(offset / PAGE) + 1} of {pages}</span>
              <div className="flex gap-2">
                <Button variant="outline" disabled={offset === 0} onClick={() => setOffset(offset - PAGE)}>Previous</Button>
                <Button variant="outline" disabled={offset + PAGE >= data.total} onClick={() => setOffset(offset + PAGE)}>Next</Button>
              </div>
            </div>
          )}
        </Card>
      )}

      <Modal open={draft !== null} title={`${draft?.id ? 'Edit' : 'Add'} ${noun}`} onClose={() => setDraft(null)}>
        {draft && (
          <form onSubmit={save} className="space-y-4">
            {formError && <ErrorNote message={formError} />}
            <div className="grid grid-cols-2 gap-3">
              <Field label="Amount"><input className="input num" type="number" inputMode="decimal" step="0.01" min="0.01" required autoFocus
                value={draft.amount} onChange={(e) => setDraft({ ...draft, amount: e.target.value })} /></Field>
              <Field label="Date"><input className="input" type="date" required value={draft.txn_date} onChange={(e) => setDraft({ ...draft, txn_date: e.target.value })} /></Field>
            </div>
            <div className={cn('grid gap-3', isExpense && 'grid-cols-2')}>
              <Field label={isExpense ? 'Category' : 'Source'}>
                <select className="input" required value={draft.ref} onChange={(e) => setDraft({ ...draft, ref: e.target.value })}>
                  {refs.data?.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </Field>
              {isExpense && (
                <Field label="Payment method">
                  <select className="input" value={draft.payment_method} onChange={(e) => setDraft({ ...draft, payment_method: e.target.value })}>
                    {Object.entries(PAYMENT_METHODS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </Field>
              )}
            </div>
            <Field label="Description"><input className="input" maxLength={500} value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} /></Field>
            {isExpense && <Field label="Notes"><textarea className="input" rows={2} maxLength={2000} value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} /></Field>}
            <div className="flex justify-end gap-2 pt-1">
              <Button type="button" variant="ghost" onClick={() => setDraft(null)}>Cancel</Button>
              <Button type="submit" busy={saving}>{draft.id ? 'Save changes' : `Add ${noun}`}</Button>
            </div>
          </form>
        )}
      </Modal>
    </>
  )
}
