import { CheckCircle2, Plus, Trash2 } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Bar, CartesianGrid, Cell, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Button, C, Card, ChartTooltip, Empty, ErrorNote, Field, Modal, PageHeader, Progress, Spinner, Stat } from '../components/ui'
import { api } from '../lib/api'
import { compact, MONTHS, pct } from '../lib/format'
import { useFetch, useStore } from '../lib/store'
import type { Goal, SavingsHistory } from '../lib/types'
import { ArrowDownRight, ArrowUpRight, Percent, PiggyBank } from 'lucide-react'

export default function Savings() {
  const { year, month, setPeriod, fmt } = useStore()
  const history = useFetch<SavingsHistory>(`/savings/history?year=${year}`)
  const goals = useFetch<Goal[]>(`/savings/goals?year=${year}`)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ name: '', period: 'monthly', month: String(month), target: '' })
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const thisYear = new Date().getFullYear()

  const create = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null)
    try {
      await api.post('/savings/goals', { name: form.name, period: form.period, year, target_amount: Number(form.target),
        ...(form.period === 'monthly' ? { month: Number(form.month) } : {}) })
      setOpen(false); setForm({ ...form, name: '', target: '' }); goals.reload()
    } catch (err) { setError((err as Error).message) } finally { setBusy(false) }
  }
  const remove = async (g: Goal) => { if (window.confirm(`Delete goal "${g.name}"?`)) { await api.del(`/savings/goals/${g.id}`); goals.reload() } }

  const chart = history.data?.months.map((m) => ({ ...m, label: MONTHS[m.month - 1].slice(0, 3) })) ?? []
  const t = history.data?.totals
  return (
    <>
      <PageHeader title="Savings" subtitle="Savings = total income - total expenses, calculated from your transactions.">
        <select aria-label="Year" className="input w-auto" value={year} onChange={(e) => setPeriod(Number(e.target.value), month)}>
          {Array.from({ length: 8 }, (_, i) => thisYear + 1 - i).map((y) => <option key={y}>{y}</option>)}
        </select>
        <Button onClick={() => { setError(null); setOpen(true) }}><Plus size={16} />New goal</Button>
      </PageHeader>
      {history.error && <ErrorNote message={history.error} onRetry={history.reload} />}
      {!history.data && history.loading && <Spinner />}
      {t && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Stat label={`Income ${year}`} tone="income" icon={<ArrowDownRight size={17} />} value={fmt(t.income)} />
            <Stat label={`Expenses ${year}`} tone="expense" icon={<ArrowUpRight size={17} />} value={fmt(t.expense)} />
            <Stat label={`Saved ${year}`} tone="savings" icon={<PiggyBank size={17} />} value={fmt(t.savings)} />
            <Stat label="Savings rate" tone="neutral" icon={<Percent size={17} />} value={pct(t.savings_pct)} hint="Guideline: 20% or more" />
          </div>

          <Card title="Savings trend" subtitle={`Monthly savings (bars) and savings rate (line), ${year}`}>
            <div className="h-72">
              <ResponsiveContainer>
                <ComposedChart data={chart}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} />
                  <YAxis yAxisId="amount" tickFormatter={compact} tickLine={false} axisLine={false} width={44} />
                  <YAxis yAxisId="rate" orientation="right" tickFormatter={(v) => `${v}%`} tickLine={false} axisLine={false} width={40} />
                  <Tooltip cursor={{ fill: 'rgb(var(--line) / 0.4)' }} content={({ active, payload, label }) => (
                    <ChartTooltip active={active} label={label} format={(v) => fmt(v)}
                      payload={payload?.filter((p) => p.dataKey === 'savings').map((p) => ({ name: 'Savings', value: Number(p.value), color: C.savings }))} />)} />
                  <ReferenceLine yAxisId="amount" y={0} stroke={C.muted} />
                  <Bar yAxisId="amount" dataKey="savings" radius={[4, 4, 0, 0]} maxBarSize={28}>
                    {chart.map((m) => <Cell key={m.month} fill={m.savings >= 0 ? C.savings : C.expense} />)}
                  </Bar>
                  <Line yAxisId="rate" dataKey="savings_pct" type="monotone" stroke={C.income} strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card title="Financial goals" subtitle="Progress is measured against savings in the goal period">
            {goals.data?.length === 0 ? <Empty title="No goals for this year" hint="Create a monthly or yearly savings target." /> : (
              <ul className="grid gap-4 md:grid-cols-2">
                {goals.data?.map((g) => (
                  <li key={g.id} className="rounded-xl border border-line p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div><p className="flex items-center gap-1.5 text-sm font-medium">{g.name}{g.achieved && <CheckCircle2 size={15} className="text-income" />}</p>
                        <p className="text-xs text-muted">{g.period === 'monthly' ? `${MONTHS[(g.month ?? 1) - 1]} ${g.year}` : `Year ${g.year}`}</p></div>
                      <button aria-label={`Delete ${g.name}`} onClick={() => remove(g)} className="text-muted hover:text-expense"><Trash2 size={15} /></button>
                    </div>
                    <div className="mt-3"><Progress pct={g.progress_pct} status={g.achieved ? 'ok' : 'warning'} /></div>
                    <div className="mt-2 flex justify-between text-xs text-muted">
                      <span className="num">{fmt(g.saved)} of {fmt(g.target_amount)}</span>
                      <span className="num font-medium text-ink">{pct(g.progress_pct)}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      )}

      <Modal open={open} title="New savings goal" onClose={() => setOpen(false)}>
        <form onSubmit={create} className="space-y-4">
          {error && <ErrorNote message={error} />}
          <Field label="Goal name"><input className="input" required maxLength={80} autoFocus value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Emergency fund" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Period">
              <select className="input" value={form.period} onChange={(e) => setForm({ ...form, period: e.target.value })}>
                <option value="monthly">Monthly</option><option value="yearly">Yearly ({year})</option>
              </select>
            </Field>
            {form.period === 'monthly' && (
              <Field label="Month">
                <select className="input" value={form.month} onChange={(e) => setForm({ ...form, month: e.target.value })}>
                  {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m} {year}</option>)}
                </select>
              </Field>
            )}
          </div>
          <Field label="Target amount"><input className="input num" type="number" min="1" step="0.01" required value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })} /></Field>
          <div className="flex justify-end gap-2"><Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" busy={busy}>Create goal</Button></div>
        </form>
      </Modal>
    </>
  )
}
