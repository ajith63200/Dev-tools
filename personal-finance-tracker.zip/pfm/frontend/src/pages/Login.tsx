import { LineChart, PiggyBank, ShieldCheck, Target } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Button, ErrorNote, Field } from '../components/ui'
import { useStore } from '../lib/store'

export default function Login() {
  const { login, register } = useStore()
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value })

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true); setError(null)
    try {
      if (mode === 'login') await login(form.email, form.password)
      else await register(form.name, form.email, form.password)
    } catch (err) { setError((err as Error).message) } finally { setBusy(false) }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-slate-950 p-12 text-slate-100 lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-teal-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="relative flex items-center gap-2.5 text-lg font-semibold">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-teal-400 text-slate-950"><PiggyBank size={20} /></span>Ledgerly
        </div>
        <div className="relative">
          <h1 className="max-w-md text-4xl font-semibold leading-tight tracking-tight">Know where every rupee goes, and what is left to save.</h1>
          <ul className="mt-8 space-y-4 text-sm text-slate-300">
            <li className="flex items-center gap-3"><LineChart size={18} className="text-teal-300" />Income, spending and savings in one live dashboard</li>
            <li className="flex items-center gap-3"><Target size={18} className="text-teal-300" />Budgets with alerts at 80%, 90% and 100%</li>
            <li className="flex items-center gap-3"><ShieldCheck size={18} className="text-teal-300" />Your records are private to your account</li>
          </ul>
        </div>
        <p className="relative text-xs text-slate-500">Personal Finance Management Platform</p>
      </div>

      <div className="grid place-items-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold tracking-tight">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
            <p className="mt-1 text-sm text-muted">{mode === 'login' ? 'Sign in to your finance dashboard.' : 'Start tracking in under a minute.'}</p>
          </div>
          {error && <ErrorNote message={error} />}
          {mode === 'register' && (
            <Field label="Full name"><input className="input" required maxLength={120} autoComplete="name" value={form.name} onChange={set('name')} /></Field>
          )}
          <Field label="Email"><input className="input" type="email" required autoComplete="email" value={form.email} onChange={set('email')} /></Field>
          <Field label="Password">
            <input className="input" type="password" required minLength={mode === 'register' ? 8 : 1}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={form.password} onChange={set('password')} />
          </Field>
          {mode === 'register' && <p className="text-xs text-muted">At least 8 characters, with a letter and a digit.</p>}
          <Button type="submit" busy={busy} className="w-full">{mode === 'login' ? 'Sign in' : 'Create account'}</Button>
          <p className="text-center text-sm text-muted">
            {mode === 'login' ? 'New here?' : 'Already registered?'}{' '}
            <button type="button" className="font-medium text-accent" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(null) }}>
              {mode === 'login' ? 'Create an account' : 'Sign in'}
            </button>
          </p>
        </form>
      </div>
    </div>
  )
}
