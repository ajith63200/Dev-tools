import { Plus, Trash2 } from 'lucide-react'
import { useEffect, useState, type FormEvent } from 'react'
import { Button, Card, ErrorNote, Field, PageHeader } from '../components/ui'
import { api } from '../lib/api'
import { shortDate, todayIso } from '../lib/format'
import { useFetch, useStore } from '../lib/store'
import type { Category, Reminder, Source } from '../lib/types'

const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'AUD', 'CAD', 'JPY']
const ZONES: string[] = (Intl as unknown as { supportedValuesOf?: (k: string) => string[] }).supportedValuesOf?.('timeZone')
  ?? ['Asia/Kolkata', 'UTC', 'Europe/London', 'America/New_York', 'Asia/Singapore', 'Asia/Dubai']

function useAction(after?: () => void) {
  const [state, setState] = useState<{ busy: boolean; error: string | null; done: boolean }>({ busy: false, error: null, done: false })
  const run = async (fn: () => Promise<unknown>) => {
    setState({ busy: true, error: null, done: false })
    try { await fn(); setState({ busy: false, error: null, done: true }); after?.() }
    catch (err) { setState({ busy: false, error: (err as Error).message, done: false }) }
  }
  return { ...state, run }
}

function ProfileCard() {
  const { profile, saveProfile, theme, setTheme } = useStore()
  const [form, setForm] = useState({ full_name: '', currency: 'INR', timezone: 'Asia/Kolkata' })
  const action = useAction()
  useEffect(() => { if (profile) setForm({ full_name: profile.full_name, currency: profile.currency, timezone: profile.timezone }) }, [profile])
  return (
    <Card title="Profile and preferences" subtitle={profile?.email}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void action.run(() => saveProfile({ ...form, theme })) }}>
        {action.error && <ErrorNote message={action.error} />}
        <Field label="Full name"><input className="input" required maxLength={120} value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Currency">
            <select className="input" value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}>
              {[...new Set([form.currency, ...CURRENCIES])].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Theme">
            <select className="input" value={theme} onChange={(e) => setTheme(e.target.value as 'light' | 'dark' | 'system')}>
              <option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option>
            </select>
          </Field>
        </div>
        <Field label="Time zone">
          <select className="input" value={form.timezone} onChange={(e) => setForm({ ...form, timezone: e.target.value })}>
            {[...new Set([form.timezone, ...ZONES])].map((z) => <option key={z}>{z}</option>)}
          </select>
        </Field>
        <div className="flex items-center gap-3"><Button type="submit" busy={action.busy}>Save changes</Button>{action.done && <span className="text-sm text-income">Saved</span>}</div>
      </form>
    </Card>
  )
}

function PasswordCard() {
  const [form, setForm] = useState({ current_password: '', new_password: '' })
  const action = useAction(() => setForm({ current_password: '', new_password: '' }))
  return (
    <Card title="Password">
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void action.run(() => api.post('/auth/change-password', form)) }}>
        {action.error && <ErrorNote message={action.error} />}
        <Field label="Current password"><input className="input" type="password" required autoComplete="current-password" value={form.current_password} onChange={(e) => setForm({ ...form, current_password: e.target.value })} /></Field>
        <Field label="New password"><input className="input" type="password" required minLength={8} autoComplete="new-password" value={form.new_password} onChange={(e) => setForm({ ...form, new_password: e.target.value })} /></Field>
        <div className="flex items-center gap-3"><Button type="submit" busy={action.busy}>Update password</Button>{action.done && <span className="text-sm text-income">Password updated</span>}</div>
      </form>
    </Card>
  )
}

function ListCard({ title, subtitle, path, withColor }: { title: string; subtitle: string; path: string; withColor?: boolean }) {
  const list = useFetch<(Category | Source)[]>(path)
  const [name, setName] = useState('')
  const [color, setColor] = useState('#0f766e')
  const action = useAction(() => { setName(''); list.reload() })
  const add = (e: FormEvent) => { e.preventDefault(); void action.run(() => api.post(path, withColor ? { name, color } : { name })) }
  return (
    <Card title={title} subtitle={subtitle}>
      {action.error && <div className="mb-3"><ErrorNote message={action.error} /></div>}
      <ul className="mb-4 flex flex-wrap gap-2">
        {list.data?.map((item) => (
          <li key={item.id} className="chip">
            {'color' in item && <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />}
            <span className="text-ink">{item.name}</span>
            {!item.is_default && <button aria-label={`Delete ${item.name}`} onClick={() => action.run(() => api.del(`${path}/${item.id}`))} className="hover:text-expense"><Trash2 size={12} /></button>}
          </li>
        ))}
      </ul>
      <form onSubmit={add} className="flex gap-2">
        {withColor && <input type="color" aria-label="Colour" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-10 cursor-pointer rounded-lg border border-line bg-card p-1" />}
        <input className="input" required maxLength={60} placeholder="Add a custom name" value={name} onChange={(e) => setName(e.target.value)} />
        <Button type="submit" busy={action.busy}><Plus size={15} />Add</Button>
      </form>
    </Card>
  )
}

function RemindersCard() {
  const list = useFetch<Reminder[]>('/reminders')
  const [form, setForm] = useState({ title: '', due_date: todayIso(), recurrence: 'none' })
  const action = useAction(() => { setForm({ ...form, title: '' }); list.reload() })
  return (
    <Card title="Financial reminders" subtitle="You are notified in the app on the due date">
      {action.error && <div className="mb-3"><ErrorNote message={action.error} /></div>}
      <ul className="mb-4 divide-y divide-line/70 text-sm">
        {list.data?.length === 0 && <li className="py-2 text-muted">No reminders yet.</li>}
        {list.data?.map((r) => (
          <li key={r.id} className="flex items-center justify-between gap-3 py-2">
            <span>{r.title} <span className="text-xs text-muted">· {shortDate(r.due_date)}{r.recurrence === 'monthly' && ' · monthly'}</span></span>
            <button aria-label={`Delete ${r.title}`} onClick={() => action.run(() => api.del(`/reminders/${r.id}`))} className="text-muted hover:text-expense"><Trash2 size={15} /></button>
          </li>
        ))}
      </ul>
      <form onSubmit={(e) => { e.preventDefault(); void action.run(() => api.post('/reminders', form)) }} className="grid gap-2 sm:grid-cols-[1fr_auto_auto_auto]">
        <input className="input" required maxLength={120} placeholder="e.g. Pay credit card bill" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input className="input" type="date" required value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
        <select className="input" aria-label="Recurrence" value={form.recurrence} onChange={(e) => setForm({ ...form, recurrence: e.target.value })}><option value="none">Once</option><option value="monthly">Monthly</option></select>
        <Button type="submit" busy={action.busy}><Plus size={15} />Add</Button>
      </form>
    </Card>
  )
}

export default function SettingsPage() {
  return (
    <>
      <PageHeader title="Settings" subtitle="Profile, preferences, categories and reminders." />
      <div className="grid gap-5 lg:grid-cols-2">
        <ProfileCard />
        <PasswordCard />
        <ListCard title="Expense categories" subtitle="Built-in categories plus your own" path="/categories" withColor />
        <ListCard title="Income sources" subtitle="Built-in sources plus your own" path="/income-sources" />
        <div className="lg:col-span-2"><RemindersCard /></div>
      </div>
    </>
  )
}
