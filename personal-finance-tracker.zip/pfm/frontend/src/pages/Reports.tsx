import { AlertTriangle, CheckCircle2, FileSpreadsheet, FileText, Info, TrendingDown, TrendingUp } from 'lucide-react'
import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Button, C, Card, ChartTooltip, Empty, ErrorNote, MonthPicker, PageHeader, Spinner, cn } from '../components/ui'
import { api } from '../lib/api'
import { compact, pct } from '../lib/format'
import { useFetch, useStore } from '../lib/store'
import type { CategoryShare, Delta, Insight, MonthlyReport, PeriodReport } from '../lib/types'

type Tab = 'monthly' | 'quarterly' | 'yearly'
const ICON = { positive: CheckCircle2, warning: AlertTriangle, info: Info }
const TONE = { positive: 'text-income', warning: 'text-budget', info: 'text-accent' }

function Insights({ items }: { items: Insight[] }) {
  return (
    <Card title="Insights and recommendations">
      <ul className="space-y-3">
        {items.map((i) => { const Icon = ICON[i.type]; return (
          <li key={i.title} className="flex gap-3"><Icon size={18} className={cn('mt-0.5 shrink-0', TONE[i.type])} />
            <div><p className="text-sm font-medium">{i.title}</p><p className="text-sm text-muted">{i.message}</p></div></li>
        ) })}
      </ul>
    </Card>
  )
}

function Categories({ title, rows }: { title: string; rows: CategoryShare[] }) {
  const { fmt } = useStore()
  return (
    <Card title={title}>
      {rows.length === 0 ? <Empty title="No data for this period" /> : (
        <table className="w-full text-sm">
          <tbody className="divide-y divide-line/70">
            {rows.map((c) => (
              <tr key={c.category}><td className="py-2 pr-2">{c.category}</td><td className="num py-2 text-right text-muted">{c.count}x</td>
                <td className="num py-2 text-right font-medium">{fmt(c.amount)}</td><td className="num w-16 py-2 text-right text-muted">{pct(c.pct)}</td></tr>
            ))}
          </tbody>
        </table>
      )}
    </Card>
  )
}

function Figure({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return <div><dt className="text-xs uppercase tracking-wide text-muted">{label}</dt><dd className="num mt-1 text-lg font-semibold">{value}</dd>{sub && <dd className="text-xs text-muted">{sub}</dd>}</div>
}

function Change({ label, delta, goodWhenUp }: { label: string; delta: Delta; goodWhenUp: boolean }) {
  const { fmt } = useStore()
  const up = delta.change >= 0
  const good = delta.change === 0 ? null : up === goodWhenUp
  const Icon = up ? TrendingUp : TrendingDown
  return (
    <tr><td className="py-2.5">{label}</td><td className="num py-2.5 text-right text-muted">{fmt(delta.previous)}</td>
      <td className="num py-2.5 text-right font-medium">{fmt(delta.current)}</td>
      <td className={cn('num py-2.5 text-right', good === null ? 'text-muted' : good ? 'text-income' : 'text-expense')}>
        <span className="inline-flex items-center gap-1"><Icon size={14} />{delta.change_pct === null ? 'n/a' : `${delta.change_pct > 0 ? '+' : ''}${delta.change_pct.toFixed(1)}%`}</span></td></tr>
  )
}

function Monthly() {
  const { year, month, profile, fmt } = useStore()
  const { data, loading, error, reload } = useFetch<MonthlyReport>(`/analytics/reports/monthly?year=${year}&month=${month}`)
  const [busy, setBusy] = useState<string | null>(null)
  const exportAs = async (format: 'pdf' | 'xlsx') => {
    setBusy(format)
    try {
      await api.download(`/analytics/reports/monthly/export?year=${year}&month=${month}&format=${format}&currency=${profile?.currency ?? 'INR'}`,
        `financial-report-${year}-${String(month).padStart(2, '0')}.${format}`)
    } catch (err) { window.alert((err as Error).message) } finally { setBusy(null) }
  }
  if (error) return <ErrorNote message={error} onRetry={reload} />
  if (!data) return loading ? <Spinner /> : null
  return (
    <div className={cn('space-y-5', loading && 'opacity-60')}>
      <Card title={`${data.period_label} report`} action={
        <div className="flex gap-2">
          <Button variant="outline" busy={busy === 'pdf'} onClick={() => exportAs('pdf')}><FileText size={15} />PDF</Button>
          <Button variant="outline" busy={busy === 'xlsx'} onClick={() => exportAs('xlsx')}><FileSpreadsheet size={15} />Excel</Button>
        </div>}>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-5 md:grid-cols-4">
          <Figure label="Total income" value={fmt(data.total_income)} />
          <Figure label="Total expenses" value={fmt(data.total_expenses)} />
          <Figure label="Total savings" value={fmt(data.total_savings)} />
          <Figure label="Savings percentage" value={pct(data.savings_pct)} />
          <Figure label="Highest spending category" value={data.highest_category?.category ?? '-'} sub={data.highest_category ? fmt(data.highest_category.amount) : undefined} />
          <Figure label="Lowest spending category" value={data.lowest_category?.category ?? '-'} sub={data.lowest_category ? fmt(data.lowest_category.amount) : undefined} />
          <Figure label="Average daily expenditure" value={fmt(data.average_daily_expenditure)} />
          <Figure label="Budget utilisation" value={data.budget ? pct(data.budget.utilization_pct) : 'No budget'} sub={data.budget ? `${fmt(data.budget.spent)} of ${fmt(data.budget.limit)}` : undefined} />
        </dl>
      </Card>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Compared with the previous month">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-wide text-muted"><tr><th className="pb-2 text-left font-medium">Metric</th><th className="pb-2 text-right font-medium">Previous</th><th className="pb-2 text-right font-medium">This month</th><th className="pb-2 text-right font-medium">Change</th></tr></thead>
            <tbody className="divide-y divide-line/70">
              <Change label="Income" delta={data.comparison.income} goodWhenUp />
              <Change label="Expenses" delta={data.comparison.expenses} goodWhenUp={false} />
              <Change label="Savings" delta={data.comparison.savings} goodWhenUp />
            </tbody>
          </table>
        </Card>
        <Insights items={data.insights} />
        <Categories title="Expenses by category" rows={data.categories} />
        <Categories title="Income by source" rows={data.income_sources} />
      </div>
    </div>
  )
}

function Period({ kind }: { kind: 'quarterly' | 'yearly' }) {
  const { year, month, setPeriod, fmt } = useStore()
  const [quarter, setQuarter] = useState(Math.floor((month - 1) / 3) + 1)
  const path = kind === 'yearly' ? `/analytics/reports/yearly?year=${year}` : `/analytics/reports/quarterly?year=${year}&quarter=${quarter}`
  const { data, loading, error, reload } = useFetch<PeriodReport>(path)
  const thisYear = new Date().getFullYear()
  return (
    <div className="space-y-5">
      <div className="flex gap-2">
        <select aria-label="Year" className="input w-auto" value={year} onChange={(e) => setPeriod(Number(e.target.value), month)}>
          {Array.from({ length: 8 }, (_, i) => thisYear + 1 - i).map((y) => <option key={y}>{y}</option>)}
        </select>
        {kind === 'quarterly' && (
          <div className="inline-flex overflow-hidden rounded-lg border border-line">
            {[1, 2, 3, 4].map((q) => <button key={q} onClick={() => setQuarter(q)} className={cn('px-3 py-2 text-sm font-medium', q === quarter ? 'bg-accent text-white dark:text-slate-950' : 'bg-card text-muted hover:text-ink')}>Q{q}</button>)}
          </div>
        )}
      </div>
      {error && <ErrorNote message={error} onRetry={reload} />}
      {!data && loading && <Spinner />}
      {data && (
        <>
          <Card title={`${data.period_label} summary`}>
            <dl className="grid grid-cols-2 gap-x-6 gap-y-5 md:grid-cols-4">
              <Figure label="Total income" value={fmt(data.total_income)} />
              <Figure label="Total expenses" value={fmt(data.total_expenses)} />
              <Figure label="Total savings" value={fmt(data.total_savings)} />
              <Figure label="Savings percentage" value={pct(data.savings_pct)} />
              <Figure label="Average monthly expenses" value={fmt(data.average_monthly_expenses)} />
              <Figure label="Best savings month" value={data.best_savings_month ?? '-'} />
              <Figure label="Highest expense month" value={data.highest_expense_month ?? '-'} />
              <Figure label="Top category" value={data.highest_category?.category ?? '-'} />
            </dl>
          </Card>
          <Card title="Month by month">
            <div className="h-72">
              <ResponsiveContainer>
                <BarChart data={data.months} barGap={2}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} />
                  <YAxis tickFormatter={compact} tickLine={false} axisLine={false} width={44} />
                  <Tooltip content={<ChartTooltip format={(v) => fmt(v)} />} cursor={{ fill: 'rgb(var(--line) / 0.4)' }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="income" name="Income" fill={C.income} radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar dataKey="expenses" name="Expenses" fill={C.expense} radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar dataKey="savings" name="Savings" fill={C.savings} radius={[4, 4, 0, 0]} maxBarSize={22} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <div className="grid gap-5 lg:grid-cols-2">
            <Categories title="Expenses by category" rows={data.categories} />
            <div className="space-y-5"><Insights items={data.insights} /><Categories title="Income by source" rows={data.income_sources} /></div>
          </div>
        </>
      )}
    </div>
  )
}

export default function Reports() {
  const [tab, setTab] = useState<Tab>('monthly')
  return (
    <>
      <PageHeader title="Reports" subtitle="Monthly, quarterly and yearly summaries built from your transactions.">
        {tab === 'monthly' && <MonthPicker />}
      </PageHeader>
      <div role="tablist" className="mb-5 inline-flex rounded-lg border border-line bg-card p-1">
        {(['monthly', 'quarterly', 'yearly'] as Tab[]).map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={cn('rounded-md px-4 py-1.5 text-sm font-medium capitalize transition', tab === t ? 'bg-accent/10 text-accent' : 'text-muted hover:text-ink')}>{t}</button>
        ))}
      </div>
      {tab === 'monthly' ? <Monthly /> : <Period kind={tab} key={tab} />}
    </>
  )
}
