import { Copy, Plus, Trash2 } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Button, Card, Empty, ErrorNote, Field, MonthPicker, PageHeader, Progress, Spinner, cn } from '../components/ui'
import { api } from '../lib/api'
import { MONTHS, pct, shiftMonth } from '../lib/format'
import { useFetch, useStore } from '../lib/store'
import type { BudgetView, Category } from '../lib/types'

const BADGE: Record<string, string> = { ok: 'text-income bg-income/10', warning: 'text-budget bg-budget/10',
  critical: 'text-budget bg-budget/15', exceeded: 'text-expense bg-expense/10' }
const LABEL: Record<string, string> = { ok: 'On track', warning: '80% used', critical: '90% used', exceeded: 'Limit reached' }

export default function Budgets() {
  const { year, month, fmt } = useStore()
  const view = useFetch<BudgetView>(`/budgets?year=${year}&month=${month}`)
  const cats = useFetch<Category[]>('/categories')
  const [overall, setOverall] = useState('')
  const [form, setForm] = useState({ category: '', limit: '' })
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const data = view.data

  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true); setError(null)
    try { await fn(); view.reload() } catch (err) { setError((err as Error).message) } finally { setBusy(false) }
  }
  const saveOverall = (e: FormEvent) => { e.preventDefault(); void run(async () => {
    await api.put('/budgets', { year, month, limit_amount: Number(overall) }); setOverall('') }) }
  const saveCategory = (e: FormEvent) => { e.preventDefault(); void run(async () => {
    const cat = cats.data?.find((c) => c.id === form.category)
    if (!cat) throw new Error('Choose a category')
    await api.put('/budgets', { year, month, category_id: cat.id, category_name: cat.name, limit_amount: Number(form.limit) })
    setForm({ category: '', limit: '' }) }) }
  const copyPrevious = () => { const p = shiftMonth(year, month, -1); void run(() => api.post('/budgets/copy', {
    from_year: p.year, from_month: p.month, to_year: year, to_month: month })) }

  const budgeted = new Set(data?.categories.map((c) => c.category_id))
  return (
    <>
      <PageHeader title="Budgets" subtitle={`Planned vs actual spending for ${MONTHS[month - 1]} ${year}`}>
        <Button variant="outline" onClick={copyPrevious} busy={busy}><Copy size={15} />Copy last month</Button>
        <MonthPicker />
      </PageHeader>
      {(error || view.error) && <div className="mb-4"><ErrorNote message={(error || view.error)!} /></div>}
      {!data && view.loading && <Spinner />}
      {data && (
        <div className="grid gap-5 lg:grid-cols-3">
          <Card title="Monthly spending limit" className="lg:col-span-1">
            {data.effective_limit !== null ? (
              <>
                <div className="num text-3xl font-semibold tracking-tight">{fmt(data.total_spent)}</div>
                <p className="mt-1 text-sm text-muted">spent of {fmt(data.effective_limit)}{!data.overall && ' (sum of category budgets)'}</p>
                <div className="mt-4"><Progress pct={data.utilization_pct ?? 0} status={data.overall?.status ?? ((data.utilization_pct ?? 0) >= 100 ? 'exceeded' : 'ok')} /></div>
                <div className="mt-3 flex justify-between text-sm">
                  <span className="text-muted">{pct(data.utilization_pct)} used</span>
                  <span className={cn('num font-medium', (data.remaining ?? 0) < 0 ? 'text-expense' : 'text-income')}>
                    {(data.remaining ?? 0) < 0 ? `${fmt(Math.abs(data.remaining ?? 0))} over` : `${fmt(data.remaining)} left`}</span>
                </div>
              </>
            ) : <Empty title="No limit set" hint="Set an overall limit or add category budgets." />}
            <form onSubmit={saveOverall} className="mt-5 flex items-end gap-2 border-t border-line pt-4">
              <Field label={data.overall ? 'Change overall limit' : 'Set overall limit'} className="flex-1">
                <input className="input num" type="number" min="1" step="0.01" required value={overall} placeholder={data.overall ? String(data.overall.limit_amount) : 'e.g. 50000'}
                  onChange={(e) => setOverall(e.target.value)} /></Field>
              <Button type="submit" busy={busy}>Save</Button>
              {data.overall && <Button type="button" variant="ghost" aria-label="Remove overall limit" onClick={() => run(() => api.del(`/budgets/${data.overall!.id}`))}><Trash2 size={15} /></Button>}
            </form>
            <p className="mt-3 text-xs text-muted">You are notified when spending reaches 80%, 90% and 100% of a budget.</p>
          </Card>

          <Card title="Category budgets" subtitle="Actual spending compared with the plan" className="lg:col-span-2">
            {data.categories.length === 0 ? <Empty title="No category budgets yet" hint="Add one below to track a category against a limit." /> : (
              <ul className="space-y-4">
                {data.categories.map((b) => (
                  <li key={b.id}>
                    <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2 text-sm">
                      <span className="flex items-center gap-2 font-medium">{b.category_name}
                        <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-medium', BADGE[b.status])}>{LABEL[b.status]}</span></span>
                      <span className="flex items-center gap-3">
                        <span className="num text-muted">{fmt(b.spent)} / {fmt(b.limit_amount)} · {pct(b.utilization_pct)}</span>
                        <button aria-label={`Remove ${b.category_name} budget`} onClick={() => run(() => api.del(`/budgets/${b.id}`))} className="text-muted hover:text-expense"><Trash2 size={15} /></button>
                      </span>
                    </div>
                    <Progress pct={b.utilization_pct} status={b.status} />
                  </li>
                ))}
              </ul>
            )}
            <form onSubmit={saveCategory} className="mt-6 grid gap-3 border-t border-line pt-4 sm:grid-cols-[1fr_10rem_auto] sm:items-end">
              <Field label="Category">
                <select className="input" required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  <option value="">Choose a category</option>
                  {cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}{budgeted.has(c.id) ? ' (update)' : ''}</option>)}
                </select>
              </Field>
              <Field label="Monthly limit"><input className="input num" type="number" min="1" step="0.01" required value={form.limit} onChange={(e) => setForm({ ...form, limit: e.target.value })} /></Field>
              <Button type="submit" busy={busy}><Plus size={15} />Save budget</Button>
            </form>
            {data.unbudgeted.length > 0 && (
              <div className="mt-6 border-t border-line pt-4">
                <p className="label">Spending without a budget</p>
                <div className="flex flex-wrap gap-2">
                  {data.unbudgeted.map((u) => <span key={u.category_id} className="chip">{u.category_name}<span className="num font-medium text-ink">{fmt(u.spent)}</span></span>)}
                </div>
              </div>
            )}
          </Card>
        </div>
      )}
    </>
  )
}
