import { ArrowDownRight, ArrowUpRight, Percent, PiggyBank, Wallet } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip,
  XAxis, YAxis } from 'recharts'
import { C, Card, ChartTooltip, Empty, ErrorNote, MonthPicker, PageHeader, PALETTE, Progress, Spinner, Stat, cn } from '../components/ui'
import { compact, MONTHS, pct, shortDate } from '../lib/format'
import { useFetch, useStore } from '../lib/store'
import type { Dashboard as Data } from '../lib/types'

export default function Dashboard() {
  const { year, month, profile, fmt } = useStore()
  const { data, loading, error, reload } = useFetch<Data>(`/analytics/dashboard?year=${year}&month=${month}`)
  const tip = <Tooltip content={<ChartTooltip format={(v) => fmt(v)} />} cursor={{ fill: 'rgb(var(--line) / 0.4)' }} />
  const first = profile?.full_name.split(' ')[0]

  return (
    <>
      <PageHeader title={first ? `Hello, ${first}` : 'Dashboard'} subtitle={`Your finances for ${MONTHS[month - 1]} ${year}`}>
        <MonthPicker />
      </PageHeader>
      {error && <ErrorNote message={error} onRetry={reload} />}
      {!data && loading && <Spinner />}
      {data && (
        <div className={cn('space-y-5 transition-opacity', loading && 'opacity-60')}>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
            <Stat label="Income" tone="income" icon={<ArrowDownRight size={17} />} value={fmt(data.summary.total_income)} hint="Total this month" />
            <Stat label="Expenses" tone="expense" icon={<ArrowUpRight size={17} />} value={fmt(data.summary.total_expenses)} hint="Total this month" />
            <Stat label="Savings" tone="savings" icon={<PiggyBank size={17} />} value={fmt(data.summary.total_savings)} hint="Income minus expenses" />
            <Stat label="Savings rate" tone="neutral" icon={<Percent size={17} />} value={pct(data.summary.savings_pct)} hint="Share of income saved" />
            <div className="col-span-2 lg:col-span-1">
              <Stat label="Budget left" tone="budget" icon={<Wallet size={17} />}
                value={data.summary.budget_remaining === null ? 'Not set' : fmt(data.summary.budget_remaining)}
                hint={data.summary.budget_limit === null ? <Link to="/budgets" className="text-accent">Set a monthly budget</Link>
                  : `${pct(data.summary.budget_utilization_pct)} of ${fmt(data.summary.budget_limit)} used`} />
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-3">
            <Card title="Income vs expenses" subtitle="Last 12 months" className="lg:col-span-2">
              <div className="h-72">
                <ResponsiveContainer>
                  <BarChart data={data.income_vs_expense} barGap={2}>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={compact} tickLine={false} axisLine={false} width={44} />
                    {tip}
                    <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="income" name="Income" fill={C.income} radius={[4, 4, 0, 0]} maxBarSize={18} />
                    <Bar dataKey="expenses" name="Expenses" fill={C.expense} radius={[4, 4, 0, 0]} maxBarSize={18} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card title="Spending by category" subtitle={`${MONTHS[month - 1]} ${year}`}>
              {data.category_breakdown.length === 0 ? <Empty title="No expenses yet" hint="Add an expense to see the breakdown." /> : (
                <>
                  <div className="relative h-44">
                    <ResponsiveContainer>
                      <PieChart>
                        <Pie data={data.category_breakdown} dataKey="amount" nameKey="category" innerRadius={52} outerRadius={78}
                          paddingAngle={2} stroke="none">
                          {data.category_breakdown.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
                        </Pie>
                        <Tooltip content={<ChartTooltip format={(v) => fmt(v)} />} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                      <div><div className="text-[11px] uppercase tracking-wide text-muted">Spent</div>
                        <div className="num text-sm font-semibold">{fmt(data.summary.total_expenses)}</div></div>
                    </div>
                  </div>
                  <ul className="mt-3 max-h-28 space-y-1.5 overflow-y-auto pr-1 text-xs">
                    {data.category_breakdown.map((c, i) => (
                      <li key={c.category} className="flex items-center justify-between gap-2">
                        <span className="flex min-w-0 items-center gap-2"><span className="h-2 w-2 shrink-0 rounded-full" style={{ background: PALETTE[i % PALETTE.length] }} />
                          <span className="truncate">{c.category}</span></span>
                        <span className="num text-muted">{pct(c.pct)}</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </Card>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <Card title="Monthly savings trend" subtitle="Income minus expenses, last 12 months">
              <div className="h-60">
                <ResponsiveContainer>
                  <AreaChart data={data.income_vs_expense}>
                    <defs><linearGradient id="sv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={C.savings} stopOpacity={0.35} /><stop offset="100%" stopColor={C.savings} stopOpacity={0} />
                    </linearGradient></defs>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={compact} tickLine={false} axisLine={false} width={44} />
                    {tip}
                    <Area dataKey="savings" name="Savings" type="monotone" stroke={C.savings} strokeWidth={2} fill="url(#sv)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </Card>
            <Card title="Daily spending" subtitle={`${MONTHS[month - 1]} ${year}`}>
              <div className="h-60">
                <ResponsiveContainer>
                  <BarChart data={data.daily_spending}>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis dataKey="day" tickLine={false} axisLine={false} interval={2} />
                    <YAxis tickFormatter={compact} tickLine={false} axisLine={false} width={44} />
                    <Tooltip content={<ChartTooltip format={(v) => fmt(v)} />} cursor={{ fill: 'rgb(var(--line) / 0.4)' }}
                      labelFormatter={(d) => `Day ${d}`} />
                    <Bar dataKey="amount" name="Spent" fill={C.expense} radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>

          <div className="grid gap-5 lg:grid-cols-3">
            <Card title="Budget utilisation" action={<Link to="/budgets" className="text-xs font-medium text-accent">Manage</Link>}>
              {!data.budget_available ? <Empty title="Budget data is temporarily unavailable" />
                : !data.budget ? <Empty title="No budget for this month" hint="Budgets unlock alerts at 80%, 90% and 100%." />
                : (
                  <ul className="space-y-4 text-sm">
                    <li>
                      <div className="mb-1.5 flex justify-between"><span className="font-medium">Overall</span>
                        <span className="num text-muted">{fmt(data.budget.spent)} / {fmt(data.budget.limit)}</span></div>
                      <Progress pct={data.budget.utilization_pct} status={data.budget.utilization_pct >= 100 ? 'exceeded' : data.budget.utilization_pct >= 80 ? 'warning' : 'ok'} />
                    </li>
                    {data.budget.categories.map((b) => (
                      <li key={b.id}>
                        <div className="mb-1.5 flex justify-between gap-2"><span className="truncate">{b.category_name}</span>
                          <span className={cn('num', b.status === 'exceeded' ? 'text-expense' : 'text-muted')}>{pct(b.utilization_pct)}</span></div>
                        <Progress pct={b.utilization_pct} status={b.status} />
                      </li>
                    ))}
                  </ul>
                )}
            </Card>

            <Card title="Top five categories">
              {data.top_categories.length === 0 ? <Empty title="Nothing to rank yet" /> : (
                <ol className="space-y-3.5 text-sm">
                  {data.top_categories.map((c, i) => (
                    <li key={c.category}>
                      <div className="mb-1.5 flex justify-between gap-2">
                        <span className="truncate"><span className="num mr-2 text-muted">{i + 1}</span>{c.category}</span>
                        <span className="num font-medium">{fmt(c.amount)}</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-line">
                        <div className="h-full rounded-full" style={{ width: `${(c.amount / data.top_categories[0].amount) * 100}%`, background: PALETTE[i] }} />
                      </div>
                    </li>
                  ))}
                </ol>
              )}
            </Card>

            <Card title="Recent transactions" action={<Link to="/expenses" className="text-xs font-medium text-accent">View all</Link>}>
              {data.recent_transactions.length === 0 ? <Empty title="No transactions this month" /> : (
                <ul className="divide-y divide-line/70 text-sm">
                  {data.recent_transactions.map((t) => (
                    <li key={t.id} className="flex items-center justify-between gap-3 py-2">
                      <div className="min-w-0"><p className="truncate">{t.description || t.category_name}</p>
                        <p className="text-xs text-muted">{t.category_name} · {shortDate(t.txn_date)}</p></div>
                      <span className={cn('num shrink-0 font-medium', t.kind === 'income' ? 'text-income' : 'text-expense')}>
                        {t.kind === 'income' ? '+' : '-'}{fmt(t.amount)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </div>
      )}
    </>
  )
}
