// Thin API client: bearer auth, single-flight token refresh, uniform errors.
const BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '/api/v1'
const KEY = 'pfm.tokens'

export interface Tokens { access_token: string; refresh_token: string }

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message) }
}

let tokens: Tokens | null = (() => {
  try { return JSON.parse(localStorage.getItem(KEY) ?? 'null') } catch { return null }
})()
let refreshing: Promise<boolean> | null = null
const listeners = new Set<() => void>()

export const hasSession = () => tokens !== null
export const onSessionExpired = (fn: () => void) => { listeners.add(fn); return () => { listeners.delete(fn) } }

export function setTokens(next: Tokens | null) {
  tokens = next
  if (next) localStorage.setItem(KEY, JSON.stringify(next))
  else localStorage.removeItem(KEY)
}

async function refresh(): Promise<boolean> {
  if (!tokens) return false
  refreshing ??= fetch(`${BASE}/auth/refresh`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: tokens.refresh_token }),
  }).then(async (r) => {
    if (!r.ok) return false
    setTokens(await r.json())
    return true
  }).catch(() => false).finally(() => { refreshing = null })
  return refreshing
}

function describe(status: number, payload: unknown): string {
  const detail = (payload as { detail?: unknown } | null)?.detail
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) {
    return detail.map((d: { loc?: string[]; msg?: string }) =>
      `${d.loc?.slice(1).join('.') ?? 'field'}: ${d.msg ?? 'invalid'}`).join('; ')
  }
  return status >= 500 ? 'The server is unavailable. Please try again.' : `Request failed (${status})`
}

async function send(method: string, path: string, body?: unknown, retry = true): Promise<Response> {
  const headers: Record<string, string> = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (tokens) headers.Authorization = `Bearer ${tokens.access_token}`
  let resp: Response
  try {
    resp = await fetch(`${BASE}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) })
  } catch {
    throw new ApiError(0, 'Cannot reach the server. Check your connection.')
  }
  if (resp.status === 401 && retry && tokens && !path.startsWith('/auth/login')) {
    if (await refresh()) return send(method, path, body, false)
    setTokens(null)
    listeners.forEach((fn) => fn())
  }
  if (!resp.ok) throw new ApiError(resp.status, describe(resp.status, await resp.json().catch(() => null)))
  return resp
}

async function json<T>(method: string, path: string, body?: unknown): Promise<T> {
  const resp = await send(method, path, body)
  return (resp.status === 204 ? undefined : await resp.json()) as T
}

export function query(params: Record<string, string | number | boolean | undefined | null>): string {
  const q = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') q.set(k, String(v))
  const s = q.toString()
  return s ? `?${s}` : ''
}

export const api = {
  get: <T>(path: string) => json<T>('GET', path),
  post: <T>(path: string, body?: unknown) => json<T>('POST', path, body),
  put: <T>(path: string, body?: unknown) => json<T>('PUT', path, body),
  del: (path: string) => json<void>('DELETE', path),
  async download(path: string, fallbackName: string) {
    const resp = await send('GET', path)
    const name = /filename="([^"]+)"/.exec(resp.headers.get('content-disposition') ?? '')?.[1] ?? fallbackName
    const url = URL.createObjectURL(await resp.blob())
    const a = Object.assign(document.createElement('a'), { href: url, download: name })
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  },
}
