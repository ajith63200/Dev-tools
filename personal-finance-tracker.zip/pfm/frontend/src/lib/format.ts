export const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
  'October', 'November', 'December']

export const PAYMENT_METHODS: Record<string, string> = {
  cash: 'Cash', upi: 'UPI', credit_card: 'Credit card', debit_card: 'Debit card', bank_transfer: 'Bank transfer',
  other: 'Other',
}

export function money(value: number | null | undefined, currency: string, digits = 0): string {
  if (value === null || value === undefined) return '-'
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency, maximumFractionDigits: digits,
      minimumFractionDigits: digits }).format(value)
  } catch {
    return `${currency} ${value.toFixed(digits)}`
  }
}

export function compact(value: number): string {
  return new Intl.NumberFormat(undefined, { notation: 'compact', maximumFractionDigits: 1 }).format(value)
}

export const pct = (value: number | null | undefined) => (value === null || value === undefined ? '-' : `${value.toFixed(1)}%`)

export function monthRange(year: number, month: number): { from: string; to: string } {
  const pad = (n: number) => String(n).padStart(2, '0')
  const last = new Date(year, month, 0).getDate()
  return { from: `${year}-${pad(month)}-01`, to: `${year}-${pad(month)}-${pad(last)}` }
}

export function shiftMonth(year: number, month: number, delta: number): { year: number; month: number } {
  const index = year * 12 + (month - 1) + delta
  return { year: Math.floor(index / 12), month: (index % 12) + 1 }
}

export function shortDate(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number)
  return new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
}

export const todayIso = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
