export interface Profile {
  user_id: string; email: string; full_name: string; currency: string; timezone: string
  theme: 'light' | 'dark' | 'system'; notify_budget_alerts: boolean; notify_monthly_report: boolean
}
export interface Category { id: string; name: string; color: string; is_default: boolean }
export interface Source { id: string; name: string; is_default: boolean }
export interface Expense {
  id: string; category_id: string; category_name: string; category_color: string; amount: number; txn_date: string
  payment_method: string; description: string; notes: string
}
export interface Income { id: string; source_id: string; source_name: string; amount: number; txn_date: string; description: string }
export interface Page<T> { items: T[]; total: number; total_amount: number; limit: number; offset: number }

export interface CategoryShare { category: string; amount: number; count: number; pct: number }
export interface SeriesPoint { year: number; month: number; label: string; income: number; expenses: number; savings: number; savings_pct: number }
export interface BudgetLine { id: string; limit_amount: number; spent: number; remaining: number; utilization_pct: number; status: string }
export interface CategoryBudget extends BudgetLine { category_id: string; category_name: string }
export interface BudgetSection { limit: number; spent: number; remaining: number; utilization_pct: number; overall: BudgetLine | null; categories: CategoryBudget[] }
export interface BudgetView {
  year: number; month: number; overall: BudgetLine | null; categories: CategoryBudget[]
  unbudgeted: { category_id: string; category_name: string; spent: number }[]
  total_spent: number; effective_limit: number | null; remaining: number | null; utilization_pct: number | null
}
export interface Dashboard {
  summary: { total_income: number; total_expenses: number; total_savings: number; savings_pct: number
    budget_limit: number | null; budget_remaining: number | null; budget_utilization_pct: number | null }
  income_vs_expense: SeriesPoint[]; category_breakdown: CategoryShare[]; top_categories: CategoryShare[]
  daily_spending: { date: string; day: number; amount: number }[]; budget: BudgetSection | null
  recent_transactions: { id: string; kind: 'income' | 'expense'; amount: number; txn_date: string; category_name: string; description: string }[]
  budget_available: boolean
}
export interface Delta { current: number; previous: number; change: number; change_pct: number | null }
export interface Insight { type: 'positive' | 'warning' | 'info'; title: string; message: string }
export interface MonthlyReport {
  period_label: string; total_income: number; total_expenses: number; total_savings: number; savings_pct: number
  highest_category: CategoryShare | null; lowest_category: CategoryShare | null; average_daily_expenditure: number
  comparison: { income: Delta; expenses: Delta; savings: Delta }; budget: BudgetSection | null
  categories: CategoryShare[]; income_sources: CategoryShare[]; insights: Insight[]
}
export interface PeriodReport {
  period_label: string; months: SeriesPoint[]; total_income: number; total_expenses: number; total_savings: number
  savings_pct: number; average_monthly_expenses: number; best_savings_month: string | null
  highest_expense_month: string | null; highest_category: CategoryShare | null; lowest_category: CategoryShare | null
  categories: CategoryShare[]; income_sources: CategoryShare[]; insights: Insight[]
}
export interface SavingsMonth { month: number; income: number; expense: number; savings: number; savings_pct: number }
export interface SavingsHistory { year: number; months: SavingsMonth[]; totals: Omit<SavingsMonth, 'month'> }
export interface Goal {
  id: string; name: string; period: 'monthly' | 'yearly'; year: number; month: number | null; target_amount: number
  saved: number; progress_pct: number; achieved: boolean; remaining: number
}
export interface Notice { id: string; type: string; severity: 'info' | 'warning' | 'critical'; title: string; message: string; is_read: boolean; created_at: string }
export interface Reminder { id: string; title: string; note: string; due_date: string; recurrence: 'none' | 'monthly' }
