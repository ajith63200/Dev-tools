// App-wide state: session + profile, theme, and the selected reporting period.
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api, hasSession, onSessionExpired, setTokens, type Tokens } from './api'
import { money } from './format'
import type { Profile } from './types'

type Theme = 'light' | 'dark' | 'system'
interface Store {
  profile: Profile | null
  ready: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
  saveProfile: (changes: Partial<Profile>) => Promise<void>
  theme: Theme
  setTheme: (t: Theme) => void
  year: number
  month: number
  setPeriod: (year: number, month: number) => void
  fmt: (value: number | null | undefined, digits?: number) => string
}

const Ctx = createContext<Store | null>(null)
export const useStore = () => {
  const store = useContext(Ctx)
  if (!store) throw new Error('StoreProvider missing')
  return store
}

function applyTheme(theme: Theme) {
  const dark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
  document.documentElement.classList.toggle('dark', dark)
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const now = new Date()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [ready, setReady] = useState(!hasSession())
  const [theme, setThemeState] = useState<Theme>(() => (localStorage.getItem('pfm.theme') as Theme) ?? 'system')
  const [period, setPeriodState] = useState({ year: now.getFullYear(), month: now.getMonth() + 1 })

  const loadProfile = useCallback(async () => {
    try { setProfile(await api.get<Profile>('/users/me')) } catch { setProfile(null) } finally { setReady(true) }
  }, [])

  useEffect(() => { if (hasSession()) void loadProfile() }, [loadProfile])
  useEffect(() => onSessionExpired(() => setProfile(null)), [])
  useEffect(() => {
    applyTheme(theme)
    const media = window.matchMedia('(prefers-color-scheme: dark)')
    const listener = () => applyTheme(theme)
    media.addEventListener('change', listener)
    return () => media.removeEventListener('change', listener)
  }, [theme])

  const store = useMemo<Store>(() => {
    const start = async (path: string, body: object) => {
      const { tokens } = await api.post<{ tokens: Tokens }>(path, body)
      setTokens(tokens)
      await loadProfile()
    }
    return {
      profile, ready, theme, ...period,
      login: (email, password) => start('/auth/login', { email, password }),
      register: (full_name, email, password) => start('/auth/register', { full_name, email, password }),
      logout: () => { setTokens(null); setProfile(null) },
      saveProfile: async (changes) => setProfile(await api.put<Profile>('/users/me', changes)),
      setTheme: (t) => { localStorage.setItem('pfm.theme', t); setThemeState(t) },
      setPeriod: (year, month) => setPeriodState({ year, month }),
      fmt: (value, digits = 0) => money(value, profile?.currency ?? 'INR', digits),
    }
  }, [profile, ready, theme, period, loadProfile])

  return <Ctx.Provider value={store}>{children}</Ctx.Provider>
}

/** Fetch JSON whenever `path` changes. Pass null to skip. */
export function useFetch<T>(path: string | null) {
  const [state, setState] = useState<{ data: T | null; loading: boolean; error: string | null }>(
    { data: null, loading: path !== null, error: null })
  const [tick, setTick] = useState(0)
  useEffect(() => {
    if (path === null) return
    let live = true
    setState((s) => ({ ...s, loading: true, error: null }))
    api.get<T>(path)
      .then((data) => live && setState({ data, loading: false, error: null }))
      .catch((e: Error) => live && setState((s) => ({ ...s, loading: false, error: e.message })))
    return () => { live = false }
  }, [path, tick])
  return { ...state, reload: useCallback(() => setTick((t) => t + 1), []) }
}
