import { describe, expect, it } from 'vitest'
import { monthRange, pct, shiftMonth } from './format'
import { query } from './api'

describe('format helpers', () => {
  it('computes month ranges including leap years', () => {
    expect(monthRange(2024, 2)).toEqual({ from: '2024-02-01', to: '2024-02-29' })
    expect(monthRange(2026, 12)).toEqual({ from: '2026-12-01', to: '2026-12-31' })
  })
  it('shifts months across year boundaries', () => {
    expect(shiftMonth(2026, 1, -1)).toEqual({ year: 2025, month: 12 })
    expect(shiftMonth(2026, 12, 1)).toEqual({ year: 2027, month: 1 })
  })
  it('formats percentages and missing values', () => {
    expect(pct(12.345)).toBe('12.3%')
    expect(pct(null)).toBe('-')
  })
  it('builds query strings without empty values', () => {
    expect(query({ a: 1, b: '', c: undefined, d: 'x y' })).toBe('?a=1&d=x+y')
    expect(query({})).toBe('')
  })
})
