import { ChevronLeft, ChevronRight, Loader2, X } from 'lucide-react'
import { useEffect, type ButtonHTMLAttributes, type ReactNode } from 'react'
import { MONTHS, shiftMonth } from '../lib/format'
import { useStore } from '../lib/store'

export const cn = (...parts: (string | false | null | undefined)[]) => parts.filter(Boolean).join(' ')

export function Card({ title, subtitle, action, children, className }: {
  title?: string; subtitle?: string; action?: ReactNode; children: ReactNode; className?: string
}) {
  return (
    <section className={cn('rounded-2xl border border-line bg-card p-5 shadow-card', className)}>
      {(title || action) && (
        <header className="mb-4 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-sm font-semibold text-ink">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-xs text-muted">{subtitle}</p>}
          </div>
          {action}
        </header>
      )}
      {children}
    </section>
  )
}

const TONES = { income: 'text-income bg-income/10', expense: 'text-expense bg-expense/10', savings: 'text-savings bg-savings/10',
  budget: 'text-budget bg-budget/10', neutral: 'text-accent bg-accent/10' }
export type Tone = keyof typeof TONES

export function Stat({ label, value, hint, tone, icon }: { label: string; value: string; hint?: ReactNode; tone: Tone; icon: ReactNode }) {
  return (
    <div className="rounded-2xl border border-line bg-card p-4 shadow-card">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted">{label}</span>
        <span className={cn('grid h-8 w-8 place-items-center rounded-lg', TONES[tone])}>{icon}</span>
      </div>
      <div className="num mt-3 text-2xl font-semibold tracking-tight text-ink">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted">{hint}</div>}
    </div>
  )
}

const VARIANTS = {
  primary: 'bg-accent text-white dark:text-slate-950 hover:opacity-90',
  outline: 'border border-line bg-card text-ink hover:bg-bg',
  ghost: 'text-muted hover:bg-bg hover:text-ink',
  danger: 'bg-expense text-white dark:text-slate-950 hover:opacity-90',
}
export function Button({ variant = 'primary', busy, className, children, ...rest }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof VARIANTS; busy?: boolean }) {
  return (
    <button {...rest} disabled={rest.disabled || busy}
      className={cn('inline-flex items-center justify-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium transition',
        'disabled:cursor-not-allowed disabled:opacity-50', VARIANTS[variant], className)}>
      {busy && <Loader2 size={15} className="animate-spin" />}
      {children}
    </button>
  )
}

export function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return <label className={cn('block', className)}><span className="label">{label}</span>{children}</label>
}

export function Modal({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 grid place-items-end bg-slate-950/50 p-0 backdrop-blur-sm sm:place-items-center sm:p-4"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title}
        className="max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-line bg-card p-5 shadow-xl sm:max-w-lg sm:rounded-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-muted hover:bg-bg hover:text-ink"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  )
}

const BAR = { ok: 'bg-income', warning: 'bg-budget', critical: 'bg-budget', exceeded: 'bg-expense' }
export function Progress({ pct, status = 'ok' }: { pct: number; status?: string }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-line" role="progressbar" aria-valuenow={Math.round(pct)}
      aria-valuemin={0} aria-valuemax={100}>
      <div className={cn('h-full rounded-full transition-all', BAR[status as keyof typeof BAR] ?? 'bg-accent')}
        style={{ width: `${Math.min(Math.max(pct, 0), 100)}%` }} />
    </div>
  )
}

export function MonthPicker() {
  const { year, month, setPeriod } = useStore()
  const step = (delta: number) => { const n = shiftMonth(year, month, delta); setPeriod(n.year, n.month) }
  const thisYear = new Date().getFullYear()
  return (
    <div className="inline-flex items-center rounded-lg border border-line bg-card text-sm">
      <button onClick={() => step(-1)} aria-label="Previous month" className="p-2 text-muted hover:text-ink"><ChevronLeft size={16} /></button>
      <select aria-label="Month" value={month} onChange={(e) => setPeriod(year, Number(e.target.value))}
        className="cursor-pointer bg-transparent py-1.5 font-medium focus:outline-none">
        {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
      </select>
      <select aria-label="Year" value={year} onChange={(e) => setPeriod(Number(e.target.value), month)}
        className="cursor-pointer bg-transparent py-1.5 pl-1 font-medium focus:outline-none">
        {Array.from({ length: 12 }, (_, i) => thisYear + 1 - i).map((y) => <option key={y} value={y}>{y}</option>)}
      </select>
      <button onClick={() => step(1)} aria-label="Next month" className="p-2 text-muted hover:text-ink"><ChevronRight size={16} /></button>
    </div>
  )
}

export function Empty({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="grid place-items-center gap-2 py-10 text-center">
      <p className="text-sm font-medium text-ink">{title}</p>
      {hint && <p className="max-w-sm text-xs text-muted">{hint}</p>}
      {action}
    </div>
  )
}

export const Spinner = () => <div className="grid place-items-center py-16 text-muted"><Loader2 className="animate-spin" /></div>

export function ErrorNote({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex items-center justify-between gap-3 rounded-xl border border-expense/30 bg-expense/10 px-4 py-3 text-sm text-expense">
      <span>{message}</span>
      {onRetry && <button onClick={onRetry} className="font-medium underline">Retry</button>}
    </div>
  )
}

export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  )
}

/** Shared Recharts tooltip so every chart looks the same in both themes. */
export function ChartTooltip({ active, payload, label, format }: {
  active?: boolean; label?: string | number; format: (v: number) => string
  payload?: { name?: string; value?: number; color?: string; payload?: { fill?: string } }[]
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-line bg-card px-3 py-2 text-xs shadow-card">
      {label !== undefined && <div className="mb-1 font-medium text-ink">{label}</div>}
      {payload.map((p, i) => (
        <div key={i} className="flex items-center justify-between gap-4 text-muted">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ background: p.color ?? p.payload?.fill }} />{p.name}
          </span>
          <span className="num font-medium text-ink">{format(Number(p.value ?? 0))}</span>
        </div>
      ))}
    </div>
  )
}

export const C = { income: 'rgb(var(--income))', expense: 'rgb(var(--expense))', savings: 'rgb(var(--savings))',
  budget: 'rgb(var(--budget))', accent: 'rgb(var(--accent))', muted: 'rgb(var(--muted))' }
export const PALETTE = ['#0f766e', '#6366f1', '#f59e0b', '#e11d48', '#0ea5e9', '#a855f7', '#84cc16', '#f97316',
  '#14b8a6', '#ec4899', '#64748b', '#eab308']
