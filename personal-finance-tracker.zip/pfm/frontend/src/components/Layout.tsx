import { ArrowDownCircle, ArrowUpCircle, Bell, FileBarChart, LayoutDashboard, LogOut, Moon, PiggyBank, Settings,
  Sun, Target } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { api } from '../lib/api'
import { useFetch, useStore } from '../lib/store'
import type { Notice } from '../lib/types'
import { cn } from './ui'

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/expenses', label: 'Expenses', icon: ArrowUpCircle },
  { to: '/income', label: 'Income', icon: ArrowDownCircle },
  { to: '/budgets', label: 'Budgets', icon: Target },
  { to: '/savings', label: 'Savings', icon: PiggyBank },
  { to: '/reports', label: 'Reports', icon: FileBarChart },
  { to: '/settings', label: 'Settings', icon: Settings },
]

const DOT = { info: 'bg-accent', warning: 'bg-budget', critical: 'bg-expense' }

function Notifications() {
  const { data, reload } = useFetch<{ items: Notice[]; unread_count: number }>('/notifications?limit=15')
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => { const id = setInterval(reload, 60_000); return () => clearInterval(id) }, [reload])
  useEffect(() => {
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false) }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])
  const unread = data?.unread_count ?? 0
  const readAll = async () => { await api.post('/notifications/read-all'); reload() }
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((o) => !o)} aria-label={`Notifications (${unread} unread)`}
        className="relative rounded-lg p-2 text-muted hover:bg-bg hover:text-ink">
        <Bell size={18} />
        {unread > 0 && <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-expense px-1 text-[10px] font-semibold text-white">{unread > 9 ? '9+' : unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 z-40 mt-2 w-[min(22rem,calc(100vw-2rem))] rounded-2xl border border-line bg-card shadow-xl">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <span className="text-sm font-semibold">Notifications</span>
            {unread > 0 && <button onClick={readAll} className="text-xs font-medium text-accent">Mark all read</button>}
          </div>
          <ul className="max-h-96 overflow-y-auto">
            {data?.items.length ? data.items.map((n) => (
              <li key={n.id} className={cn('flex gap-3 border-b border-line/60 px-4 py-3 last:border-0', !n.is_read && 'bg-accent/5')}>
                <span className={cn('mt-1.5 h-2 w-2 shrink-0 rounded-full', DOT[n.severity])} />
                <div>
                  <p className="text-sm font-medium">{n.title}</p>
                  <p className="mt-0.5 text-xs text-muted">{n.message}</p>
                  <p className="mt-1 text-[11px] text-muted/80">{new Date(n.created_at).toLocaleString()}</p>
                </div>
              </li>
            )) : <li className="px-4 py-8 text-center text-sm text-muted">You are all caught up.</li>}
          </ul>
        </div>
      )}
    </div>
  )
}

export default function Layout() {
  const { profile, logout, theme, setTheme } = useStore()
  const dark = document.documentElement.classList.contains('dark')
  const link = ({ isActive }: { isActive: boolean }) => cn(
    'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition',
    isActive ? 'bg-accent/10 text-accent' : 'text-muted hover:bg-bg hover:text-ink')
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
      <aside className="sticky top-0 hidden h-screen border-r border-line bg-card lg:flex lg:flex-col">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-white dark:text-slate-950"><PiggyBank size={18} /></span>
          <span className="text-base font-semibold tracking-tight">Ledgerly</span>
        </div>
        <nav className="flex-1 space-y-1 px-3" aria-label="Main">
          {NAV.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === '/'} className={link}><Icon size={17} />{label}</NavLink>)}
        </nav>
        <div className="border-t border-line p-3">
          <div className="px-3 pb-2">
            <p className="truncate text-sm font-medium">{profile?.full_name || 'Account'}</p>
            <p className="truncate text-xs text-muted">{profile?.email}</p>
          </div>
          <button onClick={logout} className={link({ isActive: false }) + ' w-full'}><LogOut size={17} />Sign out</button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-bg/85 px-4 py-2.5 backdrop-blur sm:px-8">
          <span className="text-base font-semibold tracking-tight lg:hidden">Ledgerly</span>
          <span className="hidden text-sm text-muted lg:block">
            {new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </span>
          <div className="flex items-center gap-1">
            <button onClick={() => setTheme(dark ? 'light' : 'dark')} aria-label={`Switch to ${dark ? 'light' : 'dark'} theme`}
              title={`Theme: ${theme}`} className="rounded-lg p-2 text-muted hover:bg-bg hover:text-ink">
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <Notifications />
            <button onClick={logout} aria-label="Sign out" className="rounded-lg p-2 text-muted hover:text-ink lg:hidden"><LogOut size={18} /></button>
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 pb-24 pt-6 sm:px-8 lg:pb-10"><Outlet /></main>
      </div>

      <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-30 flex justify-around border-t border-line bg-card/95 px-1 py-1.5 backdrop-blur lg:hidden">
        {NAV.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => cn(
            'flex min-w-0 flex-1 flex-col items-center gap-0.5 rounded-lg py-1 text-[10px] font-medium', isActive ? 'text-accent' : 'text-muted')}>
            <Icon size={18} /><span className="truncate">{label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  )
}
