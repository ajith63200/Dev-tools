#!/usr/bin/env bash
# Build (and optionally push) every image as <REGISTRY>/pfm-<component>:<TAG>.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${REGISTRY:=pfm}" "${TAG:=dev}"
for dir in services/*/; do
  name=$(basename "$dir")
  [ -f "$dir/Dockerfile" ] || continue
  docker build -t "$REGISTRY/pfm-$name:$TAG" -f "$dir/Dockerfile" services
done
docker build -t "$REGISTRY/pfm-frontend:$TAG" frontend
docker build -t "$REGISTRY/pfm-seed:$TAG" database/seed
if [ "${1:-}" = "--push" ]; then
  docker images --format '{{.Repository}}:{{.Tag}}' | grep "^$REGISTRY/pfm-.*:$TAG$" | xargs -n1 docker push
fi
