#!/usr/bin/env python3
"""Writes docs/openapi/<service>.json and the endpoint tables in docs/api.md from the code (no running stack needed)."""
import importlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "common"))
SERVICES = ["auth", "user", "income", "expense", "budget", "savings", "analytics", "notification"]

HEADER = """# API reference

All requests go through the gateway: `http://localhost:8080` (Compose) or `https://<host>` (Kubernetes ingress).
Every route except register, login and refresh needs `Authorization: Bearer <access_token>`.

* Interactive OpenAPI documents per service: `GET /api/v1/openapi/{service}` on the gateway
  (`auth`, `user`, `income`, `expense`, `budget`, `savings`, `analytics`, `notification`); static copies are in
  [`docs/openapi/`](openapi/). Each service also serves Swagger UI at `/docs` on its own port.
* Errors: `{"detail": "..."}` with 400/401/403/404/409/422/429; validation errors (422) list the offending fields.
* Money is sent and returned as JSON numbers with two decimals; dates are `YYYY-MM-DD`.
* Gateway extras: `GET /api/v1/status` (readiness of every service), rate limits of 600 requests/min per user and
  20/min per IP on the public auth routes (HTTP 429 with `Retry-After`).

```bash
# Log in, then call any endpoint
TOKEN=$(curl -s localhost:8080/api/v1/auth/login -H 'Content-Type: application/json' \\
  -d '{"email":"demo@example.com","password":"Demo@12345"}' | python3 -c 'import sys,json; print(json.load(sys.stdin)["tokens"]["access_token"])')
curl -s "localhost:8080/api/v1/analytics/dashboard?year=2026&month=11" -H "Authorization: Bearer $TOKEN"
curl -s localhost:8080/api/v1/expenses -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \\
  -d '{"category_id":"<id from /api/v1/categories>","amount":450.00,"txn_date":"2026-11-14","payment_method":"upi","description":"Lunch"}'
```
"""


def load(name):
    pkg = f"pfm_{name}_app"
    init = ROOT / "services" / f"{name}-service" / "app" / "__init__.py"
    spec = importlib.util.spec_from_file_location(pkg, init, submodule_search_locations=[str(init.parent)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[pkg] = module
    spec.loader.exec_module(module)
    return importlib.import_module(f"{pkg}.main").app


out = [HEADER]
(ROOT / "docs" / "openapi").mkdir(parents=True, exist_ok=True)
for name in SERVICES:
    schema = load(name).openapi()
    (ROOT / "docs" / "openapi" / f"{name}.json").write_text(json.dumps(schema, indent=1) + "\n")
    out.append(f"\n## {schema['info']['title'].removeprefix('PFM ')}\n\n{schema['info'].get('description', '')}\n")
    out.append("| Method | Path | Description | Query parameters |\n|---|---|---|---|")
    for path, methods in schema["paths"].items():
        for method, op in methods.items():
            params = ", ".join(f"`{p['name']}`{'*' if p.get('required') else ''}" for p in op.get("parameters", [])
                               if p["in"] == "query")
            summary = (op.get("description") or op.get("summary") or "").split("\n")[0]
            out.append(f"| {method.upper()} | `{path}` | {summary} | {params} |")
out.append("\n`*` = required. Request and response schemas are in the OpenAPI documents.\n")
(ROOT / "docs" / "api.md").write_text("\n".join(out))
print("wrote docs/api.md and docs/openapi/*.json")
