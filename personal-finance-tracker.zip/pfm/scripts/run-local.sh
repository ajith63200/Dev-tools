#!/usr/bin/env bash
# Run the whole backend as local processes (no containers). Useful for debugging.
# Requires PostgreSQL, RabbitMQ and Redis reachable with the URLs below, and
#   pip install -e services/common -r services/*/requirements.txt
set -euo pipefail
cd "$(dirname "$0")/.."

: "${PG_ADMIN_URL:=postgresql://postgres:postgres@127.0.0.1:5432/postgres}"
: "${RABBITMQ_URL:=amqp://guest:guest@127.0.0.1:5672/}"
: "${REDIS_URL:=redis://127.0.0.1:6379/0}"
: "${JWT_SECRET:=local-development-secret-not-for-production}"
export RABBITMQ_URL REDIS_URL JWT_SECRET PYTHONPATH="$PWD/services/common"
PG_BASE="${PG_ADMIN_URL%/*}"
mkdir -p .run

port=8001
for svc in auth user income expense budget savings analytics notification; do
  psql "$PG_ADMIN_URL" -tc "SELECT 1 FROM pg_database WHERE datname='${svc}_db'" | grep -q 1 \
    || psql "$PG_ADMIN_URL" -qc "CREATE DATABASE ${svc}_db"
  upper=$(echo "$svc" | tr '[:lower:]' '[:upper:]')
  export "${upper}_SERVICE_URL=http://127.0.0.1:${port}"
  ( cd "services/${svc}-service" && DATABASE_URL="${PG_BASE}/${svc}_db" \
      exec uvicorn app.main:app --host 127.0.0.1 --port "$port" --no-access-log ) > ".run/${svc}.log" 2>&1 &
  echo $! > ".run/${svc}.pid"
  port=$((port + 1))
done
( cd services/api-gateway && exec uvicorn app.main:app --host 127.0.0.1 --port 8080 --no-access-log ) \
  > .run/gateway.log 2>&1 &
echo $! > .run/gateway.pid
echo "gateway: http://127.0.0.1:8080  (logs in .run/, stop with: kill \$(cat .run/*.pid))"
