#!/usr/bin/env bash
# Unit tests for every service + the whole-platform integration suite.
# Integration tests need PostgreSQL:  TEST_DATABASE_ADMIN_URL=postgresql://postgres:postgres@127.0.0.1:5432/postgres
set -euo pipefail
cd "$(dirname "$0")/.."
for dir in services/*/; do
  [ -d "$dir/tests" ] || continue
  echo "== $(basename "$dir")"
  ( cd "$dir" && python -m pytest -q -p no:cacheprovider )
done
echo "== integration"
python -m pytest tests/integration -q -p no:cacheprovider
