# Ledgerly - Personal Finance Management Platform

Track income, expenses, budgets and savings, and see them on an interactive dashboard with monthly,
quarterly and yearly reports. Built as nine independently deployable microservices, fully containerised and
free of cloud-provider dependencies.

```bash
docker compose up --build
# App  http://localhost:3000      sign in with  demo@example.com / Demo@12345
# API  http://localhost:8080      status: /api/v1/status
```

That single command builds the images, starts PostgreSQL, RabbitMQ, Redis, the nine services and the frontend,
applies the database migrations and loads eight months of demo data.

## What is in the box

| Area | Features |
|---|---|
| Income | Add / edit / delete, built-in and custom sources, date / source / text filters, monthly and yearly totals |
| Expenses | Add / edit / delete, 11 built-in plus custom categories, payment methods (cash, UPI, cards, bank transfer), notes, filters and search |
| Budgets | Overall monthly limit and per-category budgets, utilisation percentages, planned vs actual, alerts at 80 / 90 / 100 %, copy last month |
| Savings | Savings = income - expenses computed automatically, savings rate, trend, monthly and yearly goals with progress |
| Dashboard | Five summary cards, income vs expenses, savings trend, category donut, daily spending, budget utilisation, top five categories, recent transactions |
| Reports | Monthly report (totals, highest / lowest category, average daily spend, previous-month comparison, budget use, insights), quarterly and yearly reports, PDF and Excel export, any month or year |
| Platform | JWT auth with roles, per-user data isolation, rate limiting, in-app notifications and reminders, dark and light themes, responsive layout |

## Architecture at a glance

```mermaid
flowchart LR
    B([Browser]) --> FE[Frontend<br/>React + nginx] --> GW[API Gateway]
    GW --> AUTH[auth] & USER[user] & INC[income] & EXP[expense] & BUD[budget] & SAV[savings] & ANA[analytics] & NOTIF[notification]
    INC & EXP -- events --> MQ{{RabbitMQ}}
    MQ --> BUD & SAV & ANA
    BUD -- threshold events --> MQ --> NOTIF
    ANA -- REST --> BUD
    AUTH & USER & INC & EXP & BUD & SAV & ANA & NOTIF --- PG[(PostgreSQL<br/>database per service)]
    GW & ANA --- R[(Redis)]
```

* **Stack:** Python 3.12 / FastAPI, PostgreSQL 16, RabbitMQ, Redis, React 18 / TypeScript / Tailwind / Recharts.
* **Data ownership:** every service has its own database and role. Budgets, savings and analytics keep their own
  projections, built from events, and never read another service's tables.
* **Reliable events:** transactional outbox, idempotent consumers, dead-letter queues.

Details: [architecture](docs/architecture.md) · [database design](docs/database.md) · [API reference](docs/api.md) ·
[security](docs/security.md) · [deployment](docs/deployment.md) · [testing](docs/testing.md) ·
[troubleshooting](docs/troubleshooting.md)

## Repository layout

```
frontend/                 React dashboard (Vite), nginx image
services/
  common/                 shared library: config, DB + migrations, JWT, outbox/consumers, app factory
  api-gateway/            routing, token validation, rate limiting
  auth-service/ user-service/ income-service/ expense-service/
  budget-service/ savings-service/ analytics-service/ notification-service/
      app/  migrations/  tests/  Dockerfile  requirements.txt
database/                 per-service database bootstrap script, demo data loader
infrastructure/
  docker/                 HTTPS overlay, image notes
  kubernetes/             plain manifests (generated from the chart) + secret template
  helm/pfm/               Helm chart
  terraform/              EKS, AKS, GKE and on-premises examples
monitoring/               Prometheus config + alerts, Grafana dashboard, Promtail
ci-cd/                    Jenkinsfile and pipeline overview (GitHub Actions live in .github/workflows)
tests/                    whole-platform integration suite, end-to-end smoke test
docs/                     documentation and OpenAPI documents
scripts/                  build, test, render and local-run helpers
docker-compose.yml  .env.example  Makefile
```

## Deploy anywhere

| Target | How |
|---|---|
| Laptop / single host | `docker compose up --build` |
| Any Kubernetes (on-premises, EKS, AKS, GKE) | `helm upgrade --install pfm infrastructure/helm/pfm ...` or `kubectl apply -k infrastructure/kubernetes` |
| Provisioned from scratch | `infrastructure/terraform/{aws-eks,azure-aks,gcp-gke,on-premises}` |

See [docs/deployment.md](docs/deployment.md) for the exact commands, configuration reference and production notes.

## Development

```bash
pip install -r requirements-dev.txt
./scripts/run-tests.sh                  # unit + integration tests (needs PostgreSQL, see docs/testing.md)
python3 tests/e2e/smoke_test.py         # against a running stack
cd frontend && npm ci && npm run dev    # hot-reload UI on :5173, proxied to the gateway on :8080
./scripts/run-local.sh                  # run the backend without containers
```

Add a migration by creating `services/<name>/migrations/002_<what>.sql`; it is applied at the next start.

## Verification status

What was executed while building this repository, and what was not:

| Check | Status |
|---|---|
| 57 unit tests across the services and shared library | Passed |
| 15 integration tests: all services against PostgreSQL 16 (auth, CRUD, validation, events, alerts, reports, exports, isolation, gateway) | Passed |
| Full backend run as processes with real RabbitMQ and Redis, seeded, plus the 16-step end-to-end smoke test | Passed |
| Frontend typecheck, unit tests, production build; UI exercised in a browser against the live backend (desktop, mobile, both themes) | Passed |
| `ruff`, `docker compose config`, `helm lint`, `helm template` (development and production values) | Passed |
| Building the Docker images and `docker compose up` | **Not run** - the build environment could not pull base images from any registry |
| Installing the chart into a cluster; `terraform validate` / `apply` | **Not run** - no cluster or Terraform available |

The CI workflow runs all of these, including the image build and a containerised smoke test, on the first push.

## Known limitations

* Dashboards and projections are eventually consistent with transactions (normally under a second).
* Notifications are in-app only; there is no email or push delivery.
* A single currency per user; amounts are not converted when the currency setting changes.
* No password reset, email verification or MFA yet. See [docs/security.md](docs/security.md) for the full list.
