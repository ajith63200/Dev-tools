# Docker assets

| What | Where |
|---|---|
| Service images (multi-stage, non-root, health checks) | `services/<name>/Dockerfile`, build context `services/` |
| Frontend image (Node build -> unprivileged nginx) | `frontend/Dockerfile` |
| Demo data loader image | `database/seed/Dockerfile` |
| Local / single-host stack | `docker-compose.yml` (repository root) |
| HTTPS overlay for a single host | `docker-compose.tls.yml` (this folder) |

Build and push everything for a registry:

```bash
REGISTRY=ghcr.io/your-org TAG=1.0.0 ./scripts/build-images.sh --push
```
