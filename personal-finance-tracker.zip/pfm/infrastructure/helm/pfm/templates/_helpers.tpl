{{- define "pfm.labels" -}}
app.kubernetes.io/part-of: pfm
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{- define "pfm.image" -}}
{{- $root := index . 0 -}}{{- $name := index . 1 -}}
{{ $root.Values.image.registry }}/pfm-{{ $name }}:{{ $root.Values.image.tag | default $root.Chart.AppVersion }}
{{- end }}

{{- define "pfm.secretName" -}}
{{ .Values.secrets.existingSecret | default (printf "%s-secrets" .Release.Name) }}
{{- end }}

{{/* "auth-service" -> "auth" */}}
{{- define "pfm.short" -}}{{ . | trimSuffix "-service" }}{{- end }}

{{- define "pfm.databaseUrl" -}}
{{- $root := index . 0 -}}{{- $short := index . 1 -}}
{{- if $root.Values.postgresql.enabled -}}
{{- $pw := required (printf "postgresql.servicePasswords.%s is required" $short) (get $root.Values.postgresql.servicePasswords $short) -}}
postgresql://{{ $short }}_svc:{{ $pw | urlquery }}@{{ $root.Release.Name }}-postgres:5432/{{ $short }}_db
{{- else -}}
{{ required (printf "externalDatabase.urls.%s is required when postgresql.enabled=false" $short) (get $root.Values.externalDatabase.urls $short) }}
{{- end -}}
{{- end }}

{{- define "pfm.rabbitmqUrl" -}}
{{- if .Values.rabbitmq.enabled -}}
amqp://{{ .Values.rabbitmq.username }}:{{ required "rabbitmq.password is required" .Values.rabbitmq.password | urlquery }}@{{ .Release.Name }}-rabbitmq:5672/
{{- else -}}
{{ required "externalRabbitmqUrl is required when rabbitmq.enabled=false" .Values.externalRabbitmqUrl }}
{{- end -}}
{{- end }}

{{- define "pfm.redisUrl" -}}
{{- if .Values.redis.enabled -}}redis://{{ .Release.Name }}-redis:6379/0{{- else -}}{{ .Values.externalRedisUrl }}{{- end -}}
{{- end }}

{{- define "pfm.podSecurityContext" -}}
runAsNonRoot: true
seccompProfile: { type: RuntimeDefault }
{{- end }}

{{- define "pfm.containerSecurityContext" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities: { drop: [ALL] }
{{- end }}
