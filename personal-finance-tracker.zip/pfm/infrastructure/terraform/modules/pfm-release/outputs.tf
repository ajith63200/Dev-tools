output "url" {
  value = "${var.tls_enabled ? "https" : "http"}://${var.hostname}"
}
output "namespace" {
  value = kubernetes_namespace.pfm.metadata[0].name
}
