# Cloud-agnostic part: installs the Helm chart into whatever cluster the caller's providers point at.
# Every environment (EKS, AKS, GKE, on-premises) uses this same module, unchanged.
terraform {
  required_providers {
    helm       = { source = "hashicorp/helm", version = "~> 2.15" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.33" }
    random     = { source = "hashicorp/random", version = "~> 3.6" }
  }
}

locals {
  services = ["auth", "user", "income", "expense", "budget", "savings", "analytics", "notification"]
}

resource "kubernetes_namespace" "pfm" {
  metadata {
    name   = var.namespace
    labels = { "pod-security.kubernetes.io/enforce" = "baseline" }
  }
}

resource "random_password" "jwt" {
  length  = 64
  special = false
}

resource "random_password" "postgres_admin" {
  length  = 32
  special = false
}

resource "random_password" "rabbitmq" {
  length  = 32
  special = false
}

resource "random_password" "service_db" {
  for_each = toset(local.services)
  length   = 32
  special  = false
}

resource "helm_release" "pfm" {
  name      = "pfm"
  namespace = kubernetes_namespace.pfm.metadata[0].name
  chart     = "${path.module}/../../../helm/pfm"
  timeout   = 900
  wait      = true

  values = [yamlencode({
    image = { registry = var.image_registry, tag = var.image_tag }
    ingress = {
      enabled     = true
      className   = var.ingress_class
      host        = var.hostname
      annotations = var.ingress_annotations
      tls         = { enabled = var.tls_enabled, secretName = "pfm-tls" }
    }
    postgresql = { enabled = var.external_database_urls == null, storage = { size = var.postgres_storage_size, storageClassName = var.storage_class } }
    rabbitmq   = { storage = { size = "5Gi", storageClassName = var.storage_class } }
  })]

  # Sensitive values are passed separately so they never appear in plan output.
  set_sensitive {
    name  = "secrets.jwtSecret"
    value = random_password.jwt.result
  }
  set_sensitive {
    name  = "postgresql.adminPassword"
    value = random_password.postgres_admin.result
  }
  set_sensitive {
    name  = "rabbitmq.password"
    value = random_password.rabbitmq.result
  }
  dynamic "set_sensitive" {
    for_each = var.external_database_urls == null ? random_password.service_db : {}
    content {
      name  = "postgresql.servicePasswords.${set_sensitive.key}"
      value = set_sensitive.value.result
    }
  }
  dynamic "set_sensitive" {
    for_each = var.external_database_urls == null ? {} : var.external_database_urls
    content {
      name  = "externalDatabase.urls.${set_sensitive.key}"
      value = set_sensitive.value
    }
  }
}
