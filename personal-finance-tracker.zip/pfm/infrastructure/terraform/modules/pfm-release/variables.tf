variable "namespace" {
  type    = string
  default = "pfm"
}
variable "image_registry" {
  type        = string
  description = "Registry prefix that holds the pfm-* images, e.g. ghcr.io/your-org"
}
variable "image_tag" {
  type    = string
  default = "1.0.0"
}
variable "hostname" {
  type        = string
  description = "Public DNS name of the application"
}
variable "ingress_class" {
  type    = string
  default = "nginx"
}
variable "ingress_annotations" {
  type    = map(string)
  default = {}
}
variable "tls_enabled" {
  type    = bool
  default = true
}
variable "storage_class" {
  type        = string
  default     = ""
  description = "Empty string uses the cluster's default StorageClass"
}
variable "postgres_storage_size" {
  type    = string
  default = "20Gi"
}
variable "external_database_urls" {
  type        = map(string)
  default     = null
  sensitive   = true
  description = "Optional map service => postgresql:// URL for a managed database. When null, PostgreSQL runs in the cluster."
}
