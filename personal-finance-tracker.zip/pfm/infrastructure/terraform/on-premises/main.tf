# Example: any existing cluster (kubeadm, k3s, RKE2, OpenShift, kind...) reached through a kubeconfig.
# Prerequisites in the cluster: an ingress controller and a default StorageClass.
terraform {
  required_version = ">= 1.6"
  required_providers {
    helm       = { source = "hashicorp/helm", version = "~> 2.15" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.33" }
  }
}

variable "kubeconfig" {
  type    = string
  default = "~/.kube/config"
}
variable "kube_context" {
  type    = string
  default = null
}
variable "hostname" { type = string }
variable "image_registry" { type = string }
variable "image_tag" {
  type    = string
  default = "1.0.0"
}
variable "ingress_class" {
  type    = string
  default = "nginx"
}
variable "storage_class" {
  type    = string
  default = ""
}

provider "kubernetes" {
  config_path    = var.kubeconfig
  config_context = var.kube_context
}

provider "helm" {
  kubernetes {
    config_path    = var.kubeconfig
    config_context = var.kube_context
  }
}

module "pfm" {
  source         = "../modules/pfm-release"
  hostname       = var.hostname
  image_registry = var.image_registry
  image_tag      = var.image_tag
  ingress_class  = var.ingress_class
  storage_class  = var.storage_class
}

output "url" { value = module.pfm.url }
