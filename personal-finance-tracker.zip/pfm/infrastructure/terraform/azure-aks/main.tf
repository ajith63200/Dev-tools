# Example: Azure AKS + ingress-nginx + the PFM release.
terraform {
  required_version = ">= 1.6"
  required_providers {
    azurerm    = { source = "hashicorp/azurerm", version = "~> 4.8" }
    helm       = { source = "hashicorp/helm", version = "~> 2.15" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.33" }
  }
}

variable "subscription_id" { type = string }
variable "location" {
  type    = string
  default = "centralindia"
}
variable "cluster_name" {
  type    = string
  default = "pfm"
}
variable "hostname" { type = string }
variable "image_registry" { type = string }
variable "image_tag" {
  type    = string
  default = "1.0.0"
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

resource "azurerm_resource_group" "this" {
  name     = "${var.cluster_name}-rg"
  location = var.location
}

resource "azurerm_kubernetes_cluster" "this" {
  name                = var.cluster_name
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
  dns_prefix          = var.cluster_name
  kubernetes_version  = "1.30"

  default_node_pool {
    name                 = "default"
    vm_size              = "Standard_D2s_v5"
    auto_scaling_enabled = true
    min_count            = 2
    max_count            = 5
  }

  identity { type = "SystemAssigned" }

  network_profile {
    network_plugin = "azure"
    network_policy = "azure" # enforces the chart's NetworkPolicies
  }
}

locals {
  kube = azurerm_kubernetes_cluster.this.kube_config[0]
}

provider "kubernetes" {
  host                   = local.kube.host
  client_certificate     = base64decode(local.kube.client_certificate)
  client_key             = base64decode(local.kube.client_key)
  cluster_ca_certificate = base64decode(local.kube.cluster_ca_certificate)
}

provider "helm" {
  kubernetes {
    host                   = local.kube.host
    client_certificate     = base64decode(local.kube.client_certificate)
    client_key             = base64decode(local.kube.client_key)
    cluster_ca_certificate = base64decode(local.kube.cluster_ca_certificate)
  }
}

resource "helm_release" "ingress_nginx" {
  name             = "ingress-nginx"
  repository       = "https://kubernetes.github.io/ingress-nginx"
  chart            = "ingress-nginx"
  namespace        = "ingress-nginx"
  create_namespace = true

  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/azure-load-balancer-health-probe-request-path"
    value = "/healthz"
  }
}

module "pfm" {
  source         = "../modules/pfm-release"
  hostname       = var.hostname
  image_registry = var.image_registry
  image_tag      = var.image_tag
  storage_class  = "managed-csi"
  depends_on     = [helm_release.ingress_nginx]
}

output "url" { value = module.pfm.url }
output "kubeconfig_command" { value = "az aks get-credentials --resource-group ${azurerm_resource_group.this.name} --name ${var.cluster_name}" }
