# Example: Google GKE + ingress-nginx + the PFM release.
terraform {
  required_version = ">= 1.6"
  required_providers {
    google     = { source = "hashicorp/google", version = "~> 6.9" }
    helm       = { source = "hashicorp/helm", version = "~> 2.15" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.33" }
  }
}

variable "project" { type = string }
variable "region" {
  type    = string
  default = "asia-south1"
}
variable "cluster_name" {
  type    = string
  default = "pfm"
}
variable "hostname" { type = string }
variable "image_registry" { type = string }
variable "image_tag" {
  type    = string
  default = "1.0.0"
}

provider "google" {
  project = var.project
  region  = var.region
}

resource "google_container_cluster" "this" {
  name                     = var.cluster_name
  location                 = var.region
  remove_default_node_pool = true
  initial_node_count       = 1
  deletion_protection      = false

  network_policy { enabled = true } # enforces the chart's NetworkPolicies
  release_channel { channel = "REGULAR" }
}

resource "google_container_node_pool" "default" {
  name     = "default"
  cluster  = google_container_cluster.this.name
  location = var.region

  autoscaling {
    min_node_count = 1
    max_node_count = 3
  }

  node_config {
    machine_type = "e2-standard-2"
    oauth_scopes = ["https://www.googleapis.com/auth/cloud-platform"]
  }
}

data "google_client_config" "this" {}

provider "kubernetes" {
  host                   = "https://${google_container_cluster.this.endpoint}"
  token                  = data.google_client_config.this.access_token
  cluster_ca_certificate = base64decode(google_container_cluster.this.master_auth[0].cluster_ca_certificate)
}

provider "helm" {
  kubernetes {
    host                   = "https://${google_container_cluster.this.endpoint}"
    token                  = data.google_client_config.this.access_token
    cluster_ca_certificate = base64decode(google_container_cluster.this.master_auth[0].cluster_ca_certificate)
  }
}

resource "helm_release" "ingress_nginx" {
  name             = "ingress-nginx"
  repository       = "https://kubernetes.github.io/ingress-nginx"
  chart            = "ingress-nginx"
  namespace        = "ingress-nginx"
  create_namespace = true
  depends_on       = [google_container_node_pool.default]
}

module "pfm" {
  source         = "../modules/pfm-release"
  hostname       = var.hostname
  image_registry = var.image_registry
  image_tag      = var.image_tag
  storage_class  = "standard-rwo"
  depends_on     = [helm_release.ingress_nginx]
}

output "url" { value = module.pfm.url }
output "kubeconfig_command" { value = "gcloud container clusters get-credentials ${var.cluster_name} --region ${var.region} --project ${var.project}" }
