#!/usr/bin/env python3
"""Demo data loader. Talks to the public API through the gateway, so every record flows through
validation, the outbox and the event consumers exactly like real usage. Standard library only.

    GATEWAY_URL=http://localhost:8080 python database/seed/seed.py

Idempotent: exits quietly if the demo account already exists.
"""
import json
import os
import random
import sys
import time
import urllib.error
import urllib.request
from datetime import date

GATEWAY = os.environ.get("GATEWAY_URL", "http://localhost:8080").rstrip("/")
EMAIL = os.environ.get("DEMO_EMAIL", "demo@example.com")
PASSWORD = os.environ.get("DEMO_PASSWORD", "Demo@12345")
MONTHS = int(os.environ.get("DEMO_MONTHS", "8"))
TOKEN = None


def call(method: str, path: str, body: dict | None = None, ok=(200, 201, 204)):
    data = json.dumps(body).encode() if body is not None else None
    for _ in range(30):
        req = urllib.request.Request(f"{GATEWAY}{path}", data=data, method=method)
        req.add_header("Content-Type", "application/json")
        if TOKEN:
            req.add_header("Authorization", f"Bearer {TOKEN}")
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read()
                return resp.status, json.loads(raw) if raw else None
        except urllib.error.HTTPError as err:
            if err.code == 429:
                time.sleep(int(err.headers.get("Retry-After", "5")))
                continue
            if err.code in (502, 503, 504):
                time.sleep(3)
                continue
            return err.code, json.loads(err.read() or b"null")
        except (urllib.error.URLError, ConnectionError, TimeoutError):
            time.sleep(3)
    sys.exit(f"gateway not reachable at {GATEWAY}")


def months_back(today: date, count: int):
    index = today.year * 12 + today.month - 1
    return [((index - i) // 12, (index - i) % 12 + 1) for i in range(count - 1, -1, -1)]


def main() -> None:
    global TOKEN
    if os.environ.get("SEED_DEMO_DATA", "true").lower() in ("false", "0", "no"):
        print("SEED_DEMO_DATA is disabled; skipping")
        return
    status, body = call("POST", "/api/v1/auth/register",
                        {"email": EMAIL, "password": PASSWORD, "full_name": "Demo User"})
    if status == 409:
        print("demo data already present; nothing to do")
        return
    if status != 201:
        sys.exit(f"registration failed: {status} {body}")
    TOKEN = body["tokens"]["access_token"]

    cats = {c["name"]: c["id"] for c in call("GET", "/api/v1/categories")[1]}
    sources = {s["name"]: s["id"] for s in call("GET", "/api/v1/income-sources")[1]}
    cats["Pet care"] = call("POST", "/api/v1/categories", {"name": "Pet care", "color": "#22c55e"})[1]["id"]

    rng = random.Random(42)
    today = date.today()
    count = 0

    def income(y, m, d, source, amount, description):
        nonlocal count
        if date(y, m, d) <= today:
            call("POST", "/api/v1/incomes", {"source_id": sources[source], "amount": amount,
                                             "txn_date": date(y, m, d).isoformat(), "description": description})
            count += 1

    def expense(y, m, d, category, amount, method, description, notes=""):
        nonlocal count
        if date(y, m, d) <= today:
            call("POST", "/api/v1/expenses", {"category_id": cats[category], "amount": round(amount, 2),
                                              "txn_date": date(y, m, d).isoformat(), "payment_method": method,
                                              "description": description, "notes": notes})
            count += 1

    for i, (y, m) in enumerate(months_back(today, MONTHS)):
        income(y, m, 1, "Monthly salary", 95000, "Salary credit")
        if i % 2 == 0:
            income(y, m, 12, "Freelancing", rng.choice([12000, 18000, 22500]), "Consulting project")
        if m % 3 == 0:
            income(y, m, 20, "Investments", rng.choice([3200, 4100, 5650]), "Quarterly dividend")

        expense(y, m, 2, "Rent and accommodation", 26000, "bank_transfer", "Monthly rent")
        expense(y, m, 5, "EMI and loans", 11500, "bank_transfer", "Car loan EMI")
        expense(y, m, 3, "Subscriptions", 649, "credit_card", "Video streaming")
        expense(y, m, 3, "Subscriptions", 119, "credit_card", "Music streaming")
        expense(y, m, 7, "Utilities and bills", rng.uniform(1800, 3200), "upi", "Electricity bill")
        expense(y, m, 9, "Utilities and bills", 999, "upi", "Broadband")
        expense(y, m, 10, "Utilities and bills", 499, "upi", "Mobile recharge")
        for d in (4, 8, 13, 17, 22, 26):
            expense(y, m, d, "Food and groceries", rng.uniform(900, 2600), rng.choice(["upi", "credit_card"]),
                    rng.choice(["Supermarket", "Vegetable market", "Online groceries"]))
        for d in (6, 15, 21, 27):
            expense(y, m, d, "Food and groceries", rng.uniform(350, 1400), "upi", "Dining out")
        for d in (3, 11, 18, 24):
            expense(y, m, d, "Transportation", rng.uniform(250, 1900), rng.choice(["upi", "cash"]),
                    rng.choice(["Fuel", "Cab ride", "Metro card top-up"]))
        for d in rng.sample(range(5, 28), 2):
            expense(y, m, d, "Shopping", rng.uniform(1200, 6500), "credit_card",
                    rng.choice(["Clothing", "Electronics accessory", "Home essentials"]))
        expense(y, m, rng.randint(8, 25), "Entertainment", rng.uniform(400, 1800), "upi",
                rng.choice(["Movie tickets", "Concert", "Gaming"]))
        if i % 2 == 1:
            expense(y, m, 14, "Healthcare", rng.uniform(600, 3500), "upi", "Pharmacy and consultation")
        if i % 3 == 2:
            expense(y, m, 19, "Travel", rng.uniform(6000, 14000), "credit_card", "Weekend trip",
                    notes="Flights and hotel")
        expense(y, m, 16, "Pet care", rng.uniform(700, 1600), "cash", "Pet food and grooming")

        budgets = {"Food and groceries": 14000, "Transportation": 4500, "Shopping": 7000, "Entertainment": 2000,
                   "Utilities and bills": 6000, "Subscriptions": 900}
        call("PUT", "/api/v1/budgets", {"year": y, "month": m, "limit_amount": 80000})
        for name, limit in budgets.items():
            call("PUT", "/api/v1/budgets", {"year": y, "month": m, "category_id": cats[name],
                                            "category_name": name, "limit_amount": limit})

    call("POST", "/api/v1/savings/goals", {"name": "Emergency fund", "period": "yearly", "year": today.year,
                                           "target_amount": 300000})
    call("POST", "/api/v1/savings/goals", {"name": "Monthly savings target", "period": "monthly",
                                           "year": today.year, "month": today.month, "target_amount": 25000})
    call("POST", "/api/v1/reminders", {"title": "Pay credit card bill", "note": "Statement is due on the 5th.",
                                       "due_date": today.isoformat(), "recurrence": "monthly"})
    print(f"seeded {count} transactions over {MONTHS} months for {EMAIL} (password: {PASSWORD})")


if __name__ == "__main__":
    main()
