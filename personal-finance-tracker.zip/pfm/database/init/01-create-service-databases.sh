#!/bin/sh
# Runs once, on first start of the PostgreSQL container (docker-entrypoint-initdb.d).
# Creates one database and one least-privilege role per microservice. A service can
# only connect to its own database: CONNECT is revoked from PUBLIC everywhere.
set -eu

for svc in auth user income expense budget savings analytics notification; do
  upper=$(echo "$svc" | tr '[:lower:]' '[:upper:]')
  eval "password=\${${upper}_DB_PASSWORD:-${svc}_dev_password}"
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<SQL
CREATE ROLE ${svc}_svc LOGIN PASSWORD '${password}';
CREATE DATABASE ${svc}_db OWNER ${svc}_svc;
REVOKE CONNECT ON DATABASE ${svc}_db FROM PUBLIC;
GRANT CONNECT ON DATABASE ${svc}_db TO ${svc}_svc;
SQL
done
